-- Backup of realerp_flux on 2026-01-28_23-00-01

DROP TABLE IF EXISTS `account_masters`;
CREATE TABLE `account_masters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `opening_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `level2_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `account_masters` VALUES ('2','Allied Bank LTD','2025-09-17','0001','1','3','2025-09-18 00:58:29','2025-09-18 00:58:29');
INSERT INTO `account_masters` VALUES ('6','Sale debit ACCOUNT','2025-09-18','0001','1','7','2025-09-18 12:34:43','2025-09-18 12:34:43');
INSERT INTO `account_masters` VALUES ('9','Capital account','2025-09-21','0001','1','9','2025-09-22 01:06:20','2026-01-01 19:40:02');
INSERT INTO `account_masters` VALUES ('17','Stock Account','2025-10-15','0001','7','16','2025-10-15 12:12:56','2025-10-15 12:12:56');
INSERT INTO `account_masters` VALUES ('18','DONE Supplier','2025-10-17 17:25:24','0001','7','13','2025-10-17 12:25:24','2025-10-17 12:25:24');
INSERT INTO `account_masters` VALUES ('20','Expense Account','2025-10-18','0001','7','17','2025-10-18 07:09:51','2025-10-18 07:09:51');
INSERT INTO `account_masters` VALUES ('28','Talha','2025-10-27 19:35:13','0001','7','12','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `account_masters` VALUES ('29','MA Plastic','2025-11-01 15:00:50','0004','1','8','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `account_masters` VALUES ('30','Supplier ABC','2025-11-07 00:20:07','0002','1','6','2025-11-07 00:20:07','2025-11-07 00:20:07');
INSERT INTO `account_masters` VALUES ('32','Raw Material Inventory','2025-11-10','0001','8','19','2025-11-10 14:10:36','2025-11-10 14:10:36');
INSERT INTO `account_masters` VALUES ('33','Office Supply','2025-11-10','0001','8','18','2025-11-10 14:16:17','2025-11-10 21:24:28');
INSERT INTO `account_masters` VALUES ('34','Mirza Muhammad Wali Baig','2025-11-10 21:35:11','0002','8','19','2025-11-10 21:35:11','2025-11-10 21:35:11');
INSERT INTO `account_masters` VALUES ('35','Mirza Muhammad Wali Baig','2025-11-10 21:48:39','0002','8','18','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `account_masters` VALUES ('37','Hafiz & Tariq','2025-11-23 17:21:32','0005','1','8','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `account_masters` VALUES ('38','Lucky Plastic','2025-11-23 17:24:38','0006','1','8','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `account_masters` VALUES ('39','Baber Plastic','2025-11-23 17:26:13','0007','1','8','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `account_masters` VALUES ('40','Sultan Crockery','2025-11-23 17:30:15','0008','1','8','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `account_masters` VALUES ('41','Imran Shani Basement','2025-11-23 17:31:29','0009','1','8','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `account_masters` VALUES ('42','Aneeq Plastic','2025-11-23 17:32:05','0010','1','8','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `account_masters` VALUES ('43','MAI Plastic','2025-11-23 17:32:44','0011','1','8','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `account_masters` VALUES ('44','Sheikh Mushtaq Plastic','2025-11-23 17:34:41','0012','1','8','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `account_masters` VALUES ('45','Subhan Plastic','2025-11-23 17:36:06','0013','1','8','2025-11-23 17:36:06','2025-11-23 17:36:06');
INSERT INTO `account_masters` VALUES ('46','Nawab Plastic','2025-11-23 17:40:44','0014','1','8','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `account_masters` VALUES ('47','Punjab Traders','2025-11-23 17:41:43','0015','1','8','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `account_masters` VALUES ('48','Madni Traders','2025-11-23 17:42:23','0016','1','8','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `account_masters` VALUES ('49','Umar Plastic','2025-11-23 17:46:18','0017','1','8','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `account_masters` VALUES ('50','Sajjad & Sons','2025-11-23 17:51:23','0018','1','8','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `account_masters` VALUES ('51','Chacha Dori Wala','2025-11-23 17:55:45','0019','1','8','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `account_masters` VALUES ('52','Kashif Crockery','2025-11-23 17:58:11','0020','1','8','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `account_masters` VALUES ('53','Zia Plastic','2025-11-23 17:59:17','0021','1','8','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `account_masters` VALUES ('54','Haider Plastic','2025-11-23 18:00:54','0022','1','8','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `account_masters` VALUES ('56','Al-Madad Plastic','2025-11-23 18:04:08','0024','1','8','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `account_masters` VALUES ('57','Mubarak Plastic','2025-11-23 18:57:17','0025','1','8','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `account_masters` VALUES ('58','Malik Ehsan Plastic','2025-11-23 18:59:48','0026','1','8','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `account_masters` VALUES ('59','Noshahi Qadri','2025-12-01 18:18:47','0027','1','8','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `account_masters` VALUES ('60','Saddique Traders','2025-12-01 18:19:52','0028','1','8','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `account_masters` VALUES ('61','Rafaqat Plastic','2025-12-01 18:26:46','0029','1','8','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `account_masters` VALUES ('62','Muneer Sb','2025-12-01 18:27:34','0030','1','8','2025-12-01 18:27:34','2025-12-01 18:27:34');
INSERT INTO `account_masters` VALUES ('63','Asif Plastic','2025-12-01 18:28:48','0031','1','8','2025-12-01 18:28:48','2025-12-01 18:28:48');
INSERT INTO `account_masters` VALUES ('64','ABD Plastic','2025-12-01 18:44:17','0032','1','8','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `account_masters` VALUES ('65','Ghazi Plastic','2025-12-01 18:45:49','0033','1','8','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `account_masters` VALUES ('66','Azan Plastic','2025-12-01 18:52:20','0034','1','8','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `account_masters` VALUES ('67','Sulman Plastic','2025-12-02 18:18:36','0035','1','8','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `account_masters` VALUES ('68','Waqas Plastic','2025-12-02 18:22:00','0036','1','8','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `account_masters` VALUES ('69','Raza Kitchenware','2025-12-02 18:22:59','0037','1','8','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `account_masters` VALUES ('70','Bin Bashir Plastic','2025-12-02 18:24:15','0038','1','8','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `account_masters` VALUES ('71','Khan Plastic','2025-12-02 18:45:45','0039','1','8','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `account_masters` VALUES ('72','Nadeem Traders','2025-12-02 18:57:01','0040','1','8','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `account_masters` VALUES ('73','Fajar Plastic','2025-12-02 19:01:13','0041','1','8','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `account_masters` VALUES ('74','Latif Crockery','2025-12-02 19:02:41','0042','1','8','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `account_masters` VALUES ('75','Haji Akram Traders','2025-12-02 19:25:22','0043','1','8','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `account_masters` VALUES ('77','Talha Plastic','2025-12-02 19:35:16','0045','1','8','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `account_masters` VALUES ('78','Mansha Plastic','2025-12-02 19:38:33','0046','1','8','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `account_masters` VALUES ('79','Zameer Plastic','2025-12-02 19:39:19','0047','1','8','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `account_masters` VALUES ('80','Shan Traders','2025-12-03 18:02:46','0048','1','8','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `account_masters` VALUES ('81','Mubarak Sheesha','2025-12-03 18:04:07','0049','1','8','2025-12-03 18:04:07','2025-12-03 18:04:07');
INSERT INTO `account_masters` VALUES ('82','Hafiz Abdullah','2025-12-03 18:04:48','0050','1','8','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `account_masters` VALUES ('83','M Taha Plastic','2025-12-03 18:10:24','0051','1','8','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `account_masters` VALUES ('84','Irfan Sulman Plastic','2025-12-03 19:11:54','0052','1','8','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `account_masters` VALUES ('85','Ahsan Plastic','2025-12-03 19:12:39','0053','1','8','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `account_masters` VALUES ('86','Shakar Plastic','2025-12-03 19:13:29','0054','1','8','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `account_masters` VALUES ('87','Iqbal Shaker Plastic','2025-12-03 19:14:45','0055','1','8','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `account_masters` VALUES ('88','Shoaib Traders','2025-12-03 19:16:05','0056','1','8','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `account_masters` VALUES ('89','Itefaq Traders','2025-12-03 19:34:22','0057','1','8','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `account_masters` VALUES ('90','Sufiyan Al Fajar Plastic','2025-12-03 19:34:51','0058','1','8','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `account_masters` VALUES ('91','Farhan Al Fajar Plastic','2025-12-03 19:38:02','0059','1','8','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `account_masters` VALUES ('92','Chand Plastic','2025-12-03 19:38:40','0060','1','8','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `account_masters` VALUES ('94','Umar Bhai Bhai Plastic','2025-12-04 19:37:34','0061','1','8','2025-12-04 19:37:34','2025-12-04 19:37:34');
INSERT INTO `account_masters` VALUES ('96','Extra','2025-12-04 19:45:20','0063','1','8','2025-12-04 19:45:20','2025-12-04 19:45:20');
INSERT INTO `account_masters` VALUES ('97','Extra','2025-12-04 19:45:40','0064','1','8','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `account_masters` VALUES ('98','Bhai Bhai Plastic','2025-12-04 19:51:40','0065','1','8','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `account_masters` VALUES ('99','Nawab Bartan Store','2025-12-04 19:53:29','0066','1','8','2025-12-04 19:53:29','2025-12-04 19:53:29');
INSERT INTO `account_masters` VALUES ('100','Suleman Plastic','2025-12-04 19:55:32','0067','1','8','2025-12-04 19:55:32','2025-12-04 19:55:32');
INSERT INTO `account_masters` VALUES ('101','Hafiz Bilal','2025-12-04 19:55:53','0068','1','8','2025-12-04 19:55:53','2025-12-04 19:55:53');
INSERT INTO `account_masters` VALUES ('102','Arif AA Plastic','2025-12-04 20:06:06','0069','1','8','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `account_masters` VALUES ('103','Farhad Sb','2025-12-06 11:36:13','0070','1','8','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `account_masters` VALUES ('104','M Ashraf Plastic','2025-12-06 11:45:48','0071','1','8','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `account_masters` VALUES ('105','Al Khair Plastic','2025-12-06 11:46:35','0072','1','8','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `account_masters` VALUES ('106','Bajor Plastic','2025-12-06 11:47:54','0073','1','8','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `account_masters` VALUES ('107','Nazer Plastic','2025-12-06 11:48:42','0074','1','8','2025-12-06 11:48:42','2025-12-06 11:48:42');
INSERT INTO `account_masters` VALUES ('108','Plastic Point','2025-12-06 11:49:35','0075','1','8','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `account_masters` VALUES ('109','Zaheer Plastic','2025-12-06 11:50:31','0076','1','8','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `account_masters` VALUES ('110','Sheikh Imran Plastic','2025-12-06 11:51:19','0077','1','8','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `account_masters` VALUES ('111','Gulshan Plastic','2025-12-06 11:52:11','0078','1','8','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `account_masters` VALUES ('112','Dilawar Plastic','2025-12-06 12:04:43','0079','1','8','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `account_masters` VALUES ('113','Fahad Ashfaq','2025-12-06 18:55:45','0080','1','8','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `account_masters` VALUES ('114','Mian Shahid Plastic','2025-12-06 18:56:54','0081','1','8','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `account_masters` VALUES ('115','Mian Abdul Razaq','2025-12-06 18:59:22','0082','1','8','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `account_masters` VALUES ('116','Sajad Plastic','2025-12-06 19:00:26','0083','1','8','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `account_masters` VALUES ('117','Mushtaq Brothers','2025-12-06 19:08:41','0084','1','8','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `account_masters` VALUES ('118','Ishfaq Mushtaq Plastic','2025-12-06 19:10:20','0085','1','8','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `account_masters` VALUES ('119','Sartaj Plastic','2025-12-06 19:13:56','0086','1','8','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `account_masters` VALUES ('120','Arif Plastic','2025-12-06 19:14:31','0087','1','8','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `account_masters` VALUES ('121','Swabi Crockery','2025-12-06 19:15:16','0088','1','8','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `account_masters` VALUES ('122','Ali Plastic','2025-12-06 19:36:41','0089','1','8','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `account_masters` VALUES ('123','Amir Plastic','2025-12-06 19:37:44','0090','1','8','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `account_masters` VALUES ('124','Hafiz Plastic','2025-12-06 19:40:48','0091','1','8','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `account_masters` VALUES ('126','Fauji Bartan Store','2025-12-06 19:44:06','0093','1','8','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `account_masters` VALUES ('128','Naseer Plastic','2025-12-06 19:46:31','0095','1','8','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `account_masters` VALUES ('129','Azeem Atari','2025-12-06 19:51:03','0096','1','8','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `account_masters` VALUES ('130','A Tawakal Plastic','2025-12-09 18:45:46','0097','1','8','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `account_masters` VALUES ('131','Shabeer Plastic','2025-12-09 18:46:38','0098','1','8','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `account_masters` VALUES ('132','Bila Brothers','2025-12-09 18:47:36','0099','1','8','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `account_masters` VALUES ('133','Zaryab Bartan Store','2025-12-09 18:49:45','0100','1','8','2025-12-09 18:49:45','2025-12-09 18:49:45');
INSERT INTO `account_masters` VALUES ('134','Pak China Crockery','2025-12-09 18:50:55','0101','1','8','2025-12-09 18:50:55','2025-12-09 18:50:55');
INSERT INTO `account_masters` VALUES ('135','Zaryal Khan','2025-12-09 18:51:31','0102','1','8','2025-12-09 18:51:31','2025-12-09 18:51:31');
INSERT INTO `account_masters` VALUES ('136','China Sale Center','2025-12-09 18:52:35','0103','1','8','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `account_masters` VALUES ('137','Saleem Plastic','2025-12-09 18:53:14','0104','1','8','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `account_masters` VALUES ('138','Raza Plastic','2025-12-09 20:17:08','0105','1','8','2025-12-09 20:17:08','2025-12-09 20:17:08');
INSERT INTO `account_masters` VALUES ('139','Ameen Plastic','2025-12-11 19:30:28','0106','1','8','2025-12-11 19:30:28','2025-12-11 19:30:28');
INSERT INTO `account_masters` VALUES ('140','Stylo Plastic','2025-12-11 19:32:54','0107','1','8','2025-12-11 19:32:54','2025-12-11 19:32:54');
INSERT INTO `account_masters` VALUES ('141','Faisal Plastic','2025-12-11 19:35:06','0108','1','8','2025-12-11 19:35:06','2025-12-11 19:35:06');
INSERT INTO `account_masters` VALUES ('142','Yousaf Gul','2025-12-11 19:35:50','0109','1','8','2025-12-11 19:35:50','2025-12-11 19:35:50');
INSERT INTO `account_masters` VALUES ('143','Azam Plastic','2025-12-11 19:36:37','0110','1','8','2025-12-11 19:36:37','2025-12-11 19:36:37');
INSERT INTO `account_masters` VALUES ('144','Naeem Plastic','2025-12-11 19:38:17','0111','1','8','2025-12-11 19:38:17','2025-12-11 19:38:17');
INSERT INTO `account_masters` VALUES ('145','Mubarak Ibrahim','2025-12-11 19:39:33','0112','1','8','2025-12-11 19:39:33','2025-12-11 19:39:33');
INSERT INTO `account_masters` VALUES ('146','Imran Plastic','2025-12-11 19:44:34','0113','1','8','2025-12-11 19:44:34','2025-12-11 19:44:34');
INSERT INTO `account_masters` VALUES ('147','Ansar Plastic','2025-12-11 19:45:10','0114','1','8','2025-12-11 19:45:10','2025-12-11 19:45:10');
INSERT INTO `account_masters` VALUES ('148','Chaudhary Plastic','2025-12-11 19:46:03','0115','1','8','2025-12-11 19:46:03','2025-12-11 19:46:03');
INSERT INTO `account_masters` VALUES ('149','Abdul Manan','2025-12-11 19:47:06','0116','1','8','2025-12-11 19:47:06','2025-12-11 19:47:06');
INSERT INTO `account_masters` VALUES ('150','Chishti Plastic','2025-12-11 19:48:28','0117','1','8','2025-12-11 19:48:28','2025-12-11 19:48:28');
INSERT INTO `account_masters` VALUES ('151','Awais Plastic','2025-12-11 19:49:22','0118','1','8','2025-12-11 19:49:22','2025-12-11 19:49:22');
INSERT INTO `account_masters` VALUES ('152','HZ Plastic','2025-12-11 19:50:23','0119','1','8','2025-12-11 19:50:23','2025-12-11 19:50:23');
INSERT INTO `account_masters` VALUES ('153','Kashif Plastic','2025-12-11 19:51:08','0120','1','8','2025-12-11 19:51:08','2025-12-11 19:51:08');
INSERT INTO `account_masters` VALUES ('154','Mohsin Hassan','2025-12-11 19:51:53','0121','1','8','2025-12-11 19:51:53','2025-12-11 19:51:53');
INSERT INTO `account_masters` VALUES ('155','Qaiser Plastic','2025-12-11 19:58:08','0122','1','8','2025-12-11 19:58:08','2025-12-11 19:58:08');
INSERT INTO `account_masters` VALUES ('156','Sale Account','2025-12-19','0001','7','23','2025-12-19 16:20:09','2025-12-19 16:20:09');
INSERT INTO `account_masters` VALUES ('157','Cash Account','2026-01-01','0001','1','4','2026-01-04 20:00:49','2026-01-04 20:00:49');
INSERT INTO `account_masters` VALUES ('158','Master Plastic','2026-01-11 18:56:48','0123','1','8','2026-01-11 18:56:48','2026-01-11 18:56:48');
INSERT INTO `account_masters` VALUES ('159','Saadi Plastic','2026-01-11 20:49:45','0124','1','8','2026-01-11 20:49:45','2026-01-11 20:49:45');
INSERT INTO `account_masters` VALUES ('160','Hassan Steel','2026-01-11 23:31:48','0125','1','8','2026-01-11 23:31:48','2026-01-11 23:31:48');
INSERT INTO `account_masters` VALUES ('161','Farhan Al Fajar','2026-01-12 00:20:34','0126','1','8','2026-01-12 00:20:34','2026-01-12 00:20:34');
INSERT INTO `account_masters` VALUES ('163','Emaan Traders','2026-01-12 18:39:15','0127','1','8','2026-01-12 18:39:15','2026-01-12 18:39:15');
INSERT INTO `account_masters` VALUES ('164','Testing customer','2026-01-23 17:01:26','0128','1','8','2026-01-23 17:01:26','2026-01-23 17:01:26');
INSERT INTO `account_masters` VALUES ('165','Murtaza Plastic','2026-01-25 17:24:36','0129','1','8','2026-01-25 17:24:36','2026-01-25 17:24:36');
INSERT INTO `account_masters` VALUES ('166','Itehad Crockery','2026-01-25 17:26:26','0130','1','8','2026-01-25 17:26:26','2026-01-25 17:26:26');
INSERT INTO `account_masters` VALUES ('167','Shaker Plastic(M)','2026-01-26 21:29:17','0131','1','8','2026-01-26 21:29:17','2026-01-26 21:29:17');


DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` VALUES ('11','Talha','','','','Faizan','','','28','7','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `customers` VALUES ('12','MA Plastic','Gujranwala','Alam Chowk','','03446115519','','','29','1','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `customers` VALUES ('13','Mirza Muhammad Wali Baig','Gujranwala','Gujranwala, rahwali, Kashmir colony, house no.244/25','','03251568863','','','35','8','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `customers` VALUES ('15','Hafiz & Tariq','Lahore','','','03347022248','','','37','1','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `customers` VALUES ('16','Lucky Plastic','Lahore','','','03224252751','','','38','1','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `customers` VALUES ('17','Baber Plastic','Lahore','','','03214656210','','','39','1','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `customers` VALUES ('18','Sultan Crockery','Lahore','','','03224004826','','','40','1','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `customers` VALUES ('19','Imran Shani Basement','Lahore','','','03218894066','','','41','1','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `customers` VALUES ('20','Aneeq Plastic','Lahore','','','03024330398','','','42','1','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `customers` VALUES ('21','MAI Plastic','Lahore','','','03092232224','','','43','1','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `customers` VALUES ('22','Sheikh Mushtaq Plastic','Lahore','','','03099117726','','','44','1','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `customers` VALUES ('23','Subhan Plastic','Lahore','','','03014024432','','','45','1','2025-11-23 17:36:07','2025-11-23 17:36:07');
INSERT INTO `customers` VALUES ('24','Nawab Plastic','Lahore','','','03000432852','','','46','1','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `customers` VALUES ('25','Punjab Traders','Lahore','','','03084751026','','','47','1','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `customers` VALUES ('26','Madni Traders','Lahore','','','03034432896','','','48','1','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `customers` VALUES ('27','Umar Plastic','Lahore','','','03044018158','','','49','1','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `customers` VALUES ('28','Sajjad & Sons','Lahore','','','03234748194','','','50','1','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `customers` VALUES ('29','Chacha Dori Wala','Lahore','','','03244253653','','','51','1','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `customers` VALUES ('30','Kashif Crockery','Lahore','','','03054097607','','','52','1','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `customers` VALUES ('31','Zia Plastic','Lahore','','','03228007053','','','53','1','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `customers` VALUES ('32','Haider Plastic','Lahore','','','03334536476','','','54','1','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `customers` VALUES ('34','Al-Madad Plastic','Lahore','','','03214263909','','','56','1','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `customers` VALUES ('35','Mubarak Plastic','Lahore','','','03229486984','','','57','1','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `customers` VALUES ('36','Malik Ehsan Plastic','Lahore','','','03214655001','','','58','1','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `customers` VALUES ('37','Noshahi Qadri','Lahore','','','03096605105','','','59','1','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `customers` VALUES ('38','Saddique Traders','Lahore','','','03004255488','','','60','1','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `customers` VALUES ('39','Rafaqat Plastic','Lahore','','','03211671661','','','61','1','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `customers` VALUES ('40','Muneer Sb','Lahore','','','03004244186','','','62','1','2025-12-01 18:27:34','2025-12-01 18:35:58');
INSERT INTO `customers` VALUES ('41','Asif Plastic','Noor Gali, Lahore','','','03214260098','','','63','1','2025-12-01 18:28:48','2025-12-02 18:05:09');
INSERT INTO `customers` VALUES ('42','ABD Plastic','Alam Chowk, Gujranwala','','','03018838164','','','64','1','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `customers` VALUES ('43','Ghazi Plastic','Alam Chowk, Gujranwala','','','03456811257','','','65','1','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `customers` VALUES ('44','Azan Plastic','Alam Chowk, Gujranwala','','','03334697700','','','66','1','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `customers` VALUES ('45','Sulman Plastic','Alam Chowk, Gujranwala','','','03446575017','','','67','1','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `customers` VALUES ('46','Waqas Plastic','Alam Chowk, Gujranwala','','','03066401660','','','68','1','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `customers` VALUES ('47','Raza Kitchenware','Alam Chowk, Gujranwala','','','03126412995','','','69','1','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `customers` VALUES ('48','Bin Bashir Plastic','Alam Chowk, Gujranwala','','','03107345310','','','70','1','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `customers` VALUES ('49','Khan Plastic','Alam Chowk, Gujranwala','','','03216495351','','','71','1','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `customers` VALUES ('50','Nadeem Traders','Alam Chowk, Gujranwala','','','03421679610','','','72','1','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `customers` VALUES ('51','Fajar Plastic','Alam Chowk, Gujranwala','','','03480163684','','','73','1','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `customers` VALUES ('52','Latif Crockery','Alam Chowk, Gujranwala','','','03129647925','','','74','1','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `customers` VALUES ('53','Haji Akram Traders','Alam Chowk, Gujranwala','','','03005551741','','','75','1','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `customers` VALUES ('55','Talha Plastic','Alam Chowk, Gujranwala','','','03216492229','','','77','1','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `customers` VALUES ('56','Mansha Plastic','Alam Chowk, Gujranwala','','','03197181508','','','78','1','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `customers` VALUES ('57','Zameer Plastic','Alam Chowk, Gujranwala','','','03006460799','','','79','1','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `customers` VALUES ('58','Shan Traders','Alam Chowk, Gujranwala','','','03205436229','','','80','1','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `customers` VALUES ('59','Sheraz Traders','Alam Chowk, Gujranwala','','','03096710402','','','81','1','2025-12-03 18:04:07','2025-12-31 17:41:33');
INSERT INTO `customers` VALUES ('60','Hafiz Abdullah','Alam Chowk, Gujranwala','','','03496281208','','','82','1','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `customers` VALUES ('61','M Taha Plastic','Alam Chowk, Gujranwala','','','03200471840','','','83','1','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `customers` VALUES ('62','Irfan Sulman Plastic','Alam Chowk, Gujranwala','','','03144243128','','','84','1','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `customers` VALUES ('63','Ahsan Plastic','Alam Chowk, Gujranwala','','','03070183476','','','85','1','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `customers` VALUES ('64','Shakar Plastic','Alam Chowk, Gujranwala','','','03217150849','','','86','1','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `customers` VALUES ('65','Iqbal Shaker Plastic','Alam Chowk, Gujranwala','','','03280234237','','','87','1','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `customers` VALUES ('66','Shoaib Traders','Alam Chowk, Gujranwala','','','03005006478','','','88','1','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `customers` VALUES ('67','Itefaq Traders','Alam Chowk, Gujranwala','','','03004085189','','','89','1','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `customers` VALUES ('68','Sufiyan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03013182275','','','90','1','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `customers` VALUES ('69','Farhan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03227600077','','','91','1','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `customers` VALUES ('70','Chand Plastic','Alam Chowk, Gujranwala','','','03041241700','','','92','1','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `customers` VALUES ('72','Umar Bhai Bhai Plastic','Alam Chowk, Gujranwala','','','03426014070','','','94','1','2025-12-04 19:37:34','2025-12-09 19:58:20');
INSERT INTO `customers` VALUES ('74','Extra','Alam Chowk, Gujranwala','','','03707099846','','','96','1','2025-12-04 19:45:20','2026-01-04 17:17:41');
INSERT INTO `customers` VALUES ('75','Extra','Alam Chowk, Gujranwala','','','0332223','','','97','1','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `customers` VALUES ('76','Bhai Bhai Plastic','Khiali Darwaza, Gujranwala','','','03237486600','','','98','1','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `customers` VALUES ('77','Nawab Bartan Store','Khiali Darwaza, Gujranwala','','','03059999456','','','99','1','2025-12-04 19:53:29','2025-12-09 19:58:49');
INSERT INTO `customers` VALUES ('78','Suleman Plastic','Khiali Darwaza, Gujranwala','','','03082809552','','','100','1','2025-12-04 19:55:32','2025-12-09 19:59:34');
INSERT INTO `customers` VALUES ('79','Hafiz Bilal','Khiali Darwaza, Gujranwala','','','03060360126','','','101','1','2025-12-04 19:55:53','2025-12-09 20:00:04');
INSERT INTO `customers` VALUES ('80','Arif AA Plastic','Guranwala','','','03216405344','','','102','1','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `customers` VALUES ('81','Farhad Sb','Gujranwala','','','03217150849','','','103','1','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `customers` VALUES ('82','M Ashraf Plastic','Muslim Road, Gujranwala','','','03207835189','','','104','1','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `customers` VALUES ('83','Al Khair Plastic','Muslim Road, Gujranwala','','','03216400025','','','105','1','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `customers` VALUES ('84','Bajor Plastic','Karachi','','','03170805866','','','106','1','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `customers` VALUES ('85','Nazer Plastic','Landhi, Karachi','','','03332226851','','','107','1','2025-12-06 11:48:42','2025-12-09 20:00:50');
INSERT INTO `customers` VALUES ('86','Plastic Point','New, Karachi','','','03222030176','','','108','1','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `customers` VALUES ('87','Zaheer Plastic','Lee Market, Karachi','','','03332292780','','','109','1','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `customers` VALUES ('88','Sheikh Imran Plastic','Jona Market, Karachi','','','03333949228','','','110','1','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `customers` VALUES ('89','Gulshan Plastic','New Karachi','','','03158486252','','','111','1','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `customers` VALUES ('90','Dilawar Plastic','Landhi, Karachi','','','03332821426','','','112','1','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `customers` VALUES ('91','Fahad Ashfaq','Kotla','','','03245853791','','','113','1','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `customers` VALUES ('92','Mian Shahid Plastic','Lala Moosa','','','03478134855','','','114','1','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `customers` VALUES ('93','Mian Abdul Razaq','Lala Moosa','','','03144411341','','','115','1','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `customers` VALUES ('94','Sajad Plastic','Dinga','','','03456945048','','','116','1','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `customers` VALUES ('95','Mushtaq Brothers','Mardan','','','03321565300','','','117','1','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `customers` VALUES ('96','Ishfaq Mushtaq Plastic','Mardan','','','03149780127','','','118','1','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `customers` VALUES ('97','Sartaj Plastic','Mardan','','','03005725121','','','119','1','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `customers` VALUES ('98','Arif Plastic','Swabi','','','03120900981','','','120','1','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `customers` VALUES ('99','Swabi Crockery','Swabi','','','03471979388','','','121','1','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `customers` VALUES ('100','Ali Plastic','Shahdra','','','03004695613','','','122','1','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `customers` VALUES ('101','Amir Plastic','Baigham Kot','','','03214457644','','','123','1','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `customers` VALUES ('102','Hafiz Plastic','Raiwind','','','03014748132','','','124','1','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `customers` VALUES ('104','Fauji Bartan Store','Raiwind','','','03004058257','','','126','1','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `customers` VALUES ('106','Naseer Plastic','Raiwind','','','03069716413','','','128','1','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `customers` VALUES ('107','Azeem Atari','Raiwind','','','03234982902','','','129','1','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `customers` VALUES ('108','A Tawakal Plastic','Qainchi, Lahore','','','03084295626','','','130','1','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `customers` VALUES ('109','Shabeer Plastic','Qasoor','','','03236758687','','','131','1','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `customers` VALUES ('110','Bila Brothers','Rawalpindi','','','03005120936','','','132','1','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `customers` VALUES ('111','Zaryab Bartan Store','Rawalpindi','Rawalpindi','','03484582462','','','133','1','2025-12-09 18:49:45','2026-01-24 00:59:36');
INSERT INTO `customers` VALUES ('112','Pak China Crockery','Islamabad','','','03365069852','','','134','1','2025-12-09 18:50:55','2025-12-09 20:02:32');
INSERT INTO `customers` VALUES ('113','Zaryal Khan','Peshawar','','','03119012200','','','135','1','2025-12-09 18:51:31','2025-12-09 20:03:03');
INSERT INTO `customers` VALUES ('114','China Sale Center','Ahmadpur Sharkia','','','03062611675','','','136','1','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `customers` VALUES ('115','Saleem Plastic','Multan','','','03067845688','','','137','1','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `customers` VALUES ('116','Raza Plastic','Haroonabad','','','03009185706','','','138','1','2025-12-09 20:17:08','2025-12-09 20:17:08');
INSERT INTO `customers` VALUES ('117','Ameen Plastic','Mandi Madrasa','','','03054815662','','','139','1','2025-12-11 19:30:28','2025-12-11 19:30:28');
INSERT INTO `customers` VALUES ('118','Stylo Plastic','Chowk Azam','','','03013270485','','','140','1','2025-12-11 19:32:54','2025-12-11 19:32:54');
INSERT INTO `customers` VALUES ('119','Faisal Plastic','Shakargarh','','','03007762865','','','141','1','2025-12-11 19:35:06','2025-12-11 19:35:06');
INSERT INTO `customers` VALUES ('120','Yousaf Gul','Texla','','','03025320449','','','142','1','2025-12-11 19:35:50','2025-12-11 19:35:50');
INSERT INTO `customers` VALUES ('121','Azam Plastic','Hujra Shah Muqeem','','','03026816580','','','143','1','2025-12-11 19:36:37','2025-12-11 19:36:37');
INSERT INTO `customers` VALUES ('122','Naeem Plastic','Khanpur','','','03337471054','','','144','1','2025-12-11 19:38:17','2025-12-11 19:38:17');
INSERT INTO `customers` VALUES ('123','Mubarak Ibrahim','Shahdadpur','','','03453755133','','','145','1','2025-12-11 19:39:33','2025-12-11 19:39:33');
INSERT INTO `customers` VALUES ('124','Imran Plastic','Harapa','','','03015427534','','','146','1','2025-12-11 19:44:34','2025-12-11 19:44:34');
INSERT INTO `customers` VALUES ('125','Ansar Plastic','Bhalwal','','','03005671818','','','147','1','2025-12-11 19:45:10','2025-12-11 19:45:10');
INSERT INTO `customers` VALUES ('126','Chaudhary Plastic','Multan','','','03116893787','','','148','1','2025-12-11 19:46:03','2025-12-11 19:46:03');
INSERT INTO `customers` VALUES ('127','Abdul Manan','Pasheen','','','03108906520','','','149','1','2025-12-11 19:47:06','2025-12-11 19:47:06');
INSERT INTO `customers` VALUES ('128','Chishti Plastic','Dharanwala','','','03017250436','','','150','1','2025-12-11 19:48:28','2025-12-11 19:48:28');
INSERT INTO `customers` VALUES ('129','Awais Plastic','Dharanwala','','','03013664068','','','151','1','2025-12-11 19:49:22','2025-12-11 19:49:22');
INSERT INTO `customers` VALUES ('130','HZ Plastic','Sargodha','','','03046547252','','','152','1','2025-12-11 19:50:23','2025-12-11 19:50:23');
INSERT INTO `customers` VALUES ('131','Kashif Plastic','Shakargarh','','','03007778616','','','153','1','2025-12-11 19:51:08','2025-12-11 19:51:08');
INSERT INTO `customers` VALUES ('132','Mohsin Hassan','Karachi','','','03212979439','','','154','1','2025-12-11 19:51:53','2025-12-11 19:51:53');
INSERT INTO `customers` VALUES ('133','Qaiser Plastic','Piplan','','','03017761401','','','155','1','2025-12-11 19:58:08','2025-12-11 19:58:08');
INSERT INTO `customers` VALUES ('134','Master Plastic','Alam Chowk, Gujranwala','','','031313','','','158','1','2026-01-11 18:56:48','2026-01-11 18:56:48');
INSERT INTO `customers` VALUES ('135','Saadi Plastic','Alam Chowk, Gujranwala','','','03122','','','159','1','2026-01-11 20:49:45','2026-01-11 20:49:45');
INSERT INTO `customers` VALUES ('136','Hassan Steel','Alam Chowk, Gujranwala','','','030313','','','160','1','2026-01-11 23:31:48','2026-01-11 23:31:48');
INSERT INTO `customers` VALUES ('137','Farhan Al Fajar','Alam Chowk, Gujranwala','','','03121','','','161','1','2026-01-12 00:20:34','2026-01-12 00:20:34');
INSERT INTO `customers` VALUES ('139','Emaan Traders','Gujranwala','','','0311254613','','','163','1','2026-01-12 18:39:15','2026-01-12 18:39:15');
INSERT INTO `customers` VALUES ('140','Testing customer','Gujranwala','','','123456','thealiusman@hotmail.com','','164','1','2026-01-23 17:01:26','2026-01-23 17:01:26');
INSERT INTO `customers` VALUES ('141','Murtaza Plastic','Machiwaal','','','031631664664','','','165','1','2026-01-25 17:24:36','2026-01-25 17:24:36');
INSERT INTO `customers` VALUES ('142','Itehad Crockery','Manchinbad','','','02163546','','','166','1','2026-01-25 17:26:26','2026-01-25 17:26:26');
INSERT INTO `customers` VALUES ('143','Shaker Plastic(M)','Multan','','','033121','','','167','1','2026-01-26 21:29:17','2026-01-26 21:29:17');


DROP TABLE IF EXISTS `erp_params`;
CREATE TABLE `erp_params` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_level` bigint unsigned DEFAULT NULL,
  `employee_level` bigint DEFAULT NULL,
  `employee_advance` bigint DEFAULT NULL,
  `bank_level` bigint unsigned DEFAULT NULL,
  `supplier_level` bigint unsigned DEFAULT NULL,
  `purchase_account` bigint unsigned DEFAULT NULL,
  `purchase_return_account` int DEFAULT NULL,
  `sale_ac` bigint unsigned DEFAULT NULL,
  `customer_level` bigint unsigned DEFAULT NULL,
  `cash_acc` bigint unsigned DEFAULT NULL,
  `pur_freight` bigint unsigned DEFAULT NULL,
  `pur_freight_exp` int DEFAULT NULL,
  `sale_freight` int DEFAULT NULL,
  `sale_freight_exp` int DEFAULT NULL,
  `salary_level` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `purchase_debit_account` bigint unsigned DEFAULT NULL,
  `saleCreditAccount` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `erp_params_saledebitaccount_foreign` (`saleCreditAccount`),
  CONSTRAINT `erp_params_saledebitaccount_foreign` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sale_debit_account` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `erp_params` VALUES ('3','4','','','3','6','','','','8','2','','','','','','2025-09-18 00:51:19','2025-10-27 14:29:03','1','9','2');
INSERT INTO `erp_params` VALUES ('4','15','','','14','13','','','','12','','','','','','','2025-10-15 12:13:14','2025-12-19 16:20:40','7','17','156');
INSERT INTO `erp_params` VALUES ('5','18','','','18','19','','','','18','','','','','','','2025-11-10 14:15:38','2025-11-10 21:48:18','8','','');


DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `groups` VALUES ('1','Capital','01','','');
INSERT INTO `groups` VALUES ('2','Liabilities','02','','');
INSERT INTO `groups` VALUES ('3','Assets','03','','');
INSERT INTO `groups` VALUES ('4','Revenue','04','','');
INSERT INTO `groups` VALUES ('5','Expenses','05','','');


DROP TABLE IF EXISTS `item_detail`;
CREATE TABLE `item_detail` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `crt_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crt_qty` bigint unsigned DEFAULT NULL,
  `crt_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_detail` VALUES ('21','9','7','20x12 Tester','120','20000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('22','9','7','32x12','250','50000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('33','14','8','20x12','12','12','2025-11-10 21:39:53','2025-11-10 21:39:53');
INSERT INTO `item_detail` VALUES ('35','11','1','1*108','108','8964','2025-12-07 11:34:26','2025-12-07 11:34:26');
INSERT INTO `item_detail` VALUES ('36','12','1','1*72','72','0','2025-12-07 11:35:18','2025-12-07 11:35:18');
INSERT INTO `item_detail` VALUES ('38','16','1','1*72','72','7128','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_detail` VALUES ('39','17','1','1*72','72','10584','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_detail` VALUES ('40','18','1','1*72','72','0','2025-12-07 12:15:34','2025-12-07 12:15:34');
INSERT INTO `item_detail` VALUES ('42','20','1','1*40','40','5400','2025-12-11 18:31:38','2025-12-11 18:31:38');
INSERT INTO `item_detail` VALUES ('43','21','1','1*40','40','8000','2025-12-11 18:33:19','2025-12-11 18:33:19');
INSERT INTO `item_detail` VALUES ('44','22','1','1*40','40','0','2025-12-11 18:34:08','2025-12-11 18:34:08');
INSERT INTO `item_detail` VALUES ('46','24','1','1*40','40','7000','2025-12-11 18:37:18','2025-12-11 18:37:18');
INSERT INTO `item_detail` VALUES ('47','25','1','1*40','40','10800','2025-12-11 18:38:14','2025-12-11 18:38:14');
INSERT INTO `item_detail` VALUES ('48','26','1','1*40','40','0','2025-12-11 19:02:53','2025-12-11 19:02:53');
INSERT INTO `item_detail` VALUES ('50','28','1','1*35','35','8225','2025-12-11 19:25:53','2025-12-11 19:25:53');
INSERT INTO `item_detail` VALUES ('51','29','1','1*35','35','8925','2025-12-14 12:25:09','2025-12-14 12:25:09');
INSERT INTO `item_detail` VALUES ('52','30','1','1*40','40','12800','2025-12-14 12:32:03','2025-12-14 12:32:03');
INSERT INTO `item_detail` VALUES ('53','31','1','1*40','40','7600','2025-12-14 12:33:27','2025-12-14 12:33:27');
INSERT INTO `item_detail` VALUES ('54','32','1','1*40','40','8600','2025-12-14 12:35:00','2025-12-14 12:35:00');
INSERT INTO `item_detail` VALUES ('56','34','1','1*30','30','9600','2025-12-14 12:38:37','2025-12-14 12:38:37');
INSERT INTO `item_detail` VALUES ('57','35','1','1*30','30','11100','2025-12-14 12:43:17','2025-12-14 12:43:17');
INSERT INTO `item_detail` VALUES ('58','36','1','1*35','35','15575','2025-12-14 12:45:29','2025-12-14 12:45:29');
INSERT INTO `item_detail` VALUES ('59','37','1','1*35','35','9450','2025-12-14 12:51:17','2025-12-14 12:51:17');
INSERT INTO `item_detail` VALUES ('60','38','1','1*35','35','10500','2025-12-14 12:52:16','2025-12-14 12:52:16');
INSERT INTO `item_detail` VALUES ('62','40','1','1*30','30','10350','2025-12-14 12:56:18','2025-12-14 12:56:18');
INSERT INTO `item_detail` VALUES ('63','41','1','1*30','30','11700','2025-12-14 12:59:57','2025-12-14 12:59:57');
INSERT INTO `item_detail` VALUES ('64','42','1','1*35','35','16450','2025-12-14 13:06:36','2025-12-14 13:06:36');
INSERT INTO `item_detail` VALUES ('65','43','1','1*35','35','9800','2025-12-14 13:09:53','2025-12-14 13:09:53');
INSERT INTO `item_detail` VALUES ('66','44','1','1*35','35','11550','2025-12-14 13:29:09','2025-12-14 13:29:09');
INSERT INTO `item_detail` VALUES ('69','47','1','1*30','30','9360','2025-12-14 18:22:22','2025-12-14 18:22:22');
INSERT INTO `item_detail` VALUES ('71','49','1','0','0','0','2025-12-14 18:26:26','2025-12-14 18:26:26');
INSERT INTO `item_detail` VALUES ('72','50','1','1*360','360','11700','2025-12-14 18:37:34','2025-12-14 18:37:34');
INSERT INTO `item_detail` VALUES ('74','52','1','1*32','32','8640','2025-12-17 19:47:42','2025-12-17 19:47:42');
INSERT INTO `item_detail` VALUES ('78','56','1','0','0','0','2025-12-18 18:20:08','2025-12-18 18:20:08');
INSERT INTO `item_detail` VALUES ('83','61','1','1*36','36','9360','2025-12-18 18:35:18','2025-12-18 18:35:18');
INSERT INTO `item_detail` VALUES ('85','63','1','1*120','120','16800','2025-12-18 18:46:20','2025-12-18 18:46:20');
INSERT INTO `item_detail` VALUES ('87','65','1','1*36','36','10800','2025-12-18 18:58:02','2025-12-18 18:58:02');
INSERT INTO `item_detail` VALUES ('97','72','7','Sig 0W-20 12x 946mL','12','12000','2025-12-19 16:43:32','2025-12-19 16:43:32');
INSERT INTO `item_detail` VALUES ('98','72','7','Sig 0W20 Gal','4','16000','2025-12-19 16:43:32','2025-12-19 16:43:32');
INSERT INTO `item_detail` VALUES ('99','73','1','1*36','36','12960','2026-01-03 16:25:49','2026-01-03 16:25:49');
INSERT INTO `item_detail` VALUES ('100','74','1','0','0','0','2026-01-03 16:32:00','2026-01-03 16:32:00');
INSERT INTO `item_detail` VALUES ('101','75','1','1*48','48','16320','2026-01-03 16:34:00','2026-01-03 16:34:00');
INSERT INTO `item_detail` VALUES ('102','76','1','1*60','60','13200','2026-01-03 17:32:20','2026-01-03 17:32:20');
INSERT INTO `item_detail` VALUES ('103','77','1','1*64','64','14080','2026-01-03 17:33:50','2026-01-03 17:33:50');
INSERT INTO `item_detail` VALUES ('104','78','1','1*72','72','11520','2026-01-03 17:34:52','2026-01-03 17:34:52');
INSERT INTO `item_detail` VALUES ('105','79','1','1*64','64','9600','2026-01-03 17:44:34','2026-01-03 17:44:34');
INSERT INTO `item_detail` VALUES ('106','80','1','1*90','90','13500','2026-01-03 17:45:40','2026-01-03 17:45:40');
INSERT INTO `item_detail` VALUES ('107','81','1','1*60','60','8700','2026-01-03 17:50:09','2026-01-03 17:50:09');
INSERT INTO `item_detail` VALUES ('108','82','1','1*100','100','6500','2026-01-03 17:55:10','2026-01-03 17:55:10');
INSERT INTO `item_detail` VALUES ('109','83','1','1*72','72','5760','2026-01-03 17:56:48','2026-01-03 17:56:48');
INSERT INTO `item_detail` VALUES ('110','84','1','1*100','100','6500','2026-01-03 17:58:12','2026-01-03 17:58:12');
INSERT INTO `item_detail` VALUES ('112','86','1','1*200','200','13000','2026-01-03 18:01:34','2026-01-03 18:01:34');
INSERT INTO `item_detail` VALUES ('113','87','1','1*100','100','7500','2026-01-03 18:03:37','2026-01-03 18:03:37');
INSERT INTO `item_detail` VALUES ('114','88','1','1*99','99','8415','2026-01-03 18:05:08','2026-01-03 18:05:08');
INSERT INTO `item_detail` VALUES ('115','89','1','1*60','60','9600','2026-01-03 18:06:01','2026-01-03 18:06:01');
INSERT INTO `item_detail` VALUES ('116','90','1','1*100','100','7500','2026-01-03 18:09:07','2026-01-03 18:09:07');
INSERT INTO `item_detail` VALUES ('117','91','1','1*180','180','12600','2026-01-03 18:19:43','2026-01-03 18:19:43');
INSERT INTO `item_detail` VALUES ('118','92','1','1*72','72','5760','2026-01-03 18:20:32','2026-01-03 18:20:32');
INSERT INTO `item_detail` VALUES ('119','93','1','1*60','60','7800','2026-01-03 18:24:03','2026-01-03 18:24:03');
INSERT INTO `item_detail` VALUES ('120','94','1','1*50','50','8000','2026-01-10 17:01:15','2026-01-10 17:01:15');
INSERT INTO `item_detail` VALUES ('121','95','1','1*180','180','11700','2026-01-11 21:05:16','2026-01-11 21:05:16');
INSERT INTO `item_detail` VALUES ('122','96','1','1*70','70','5250','2026-01-11 21:53:18','2026-01-11 21:53:18');
INSERT INTO `item_detail` VALUES ('125','10','1','1*108','108','11664','2026-01-25 16:48:52','2026-01-25 16:48:52');
INSERT INTO `item_detail` VALUES ('126','13','1','1*72','72','12240','2026-01-25 16:49:26','2026-01-25 16:49:26');
INSERT INTO `item_detail` VALUES ('127','19','1','1*40','40','8880','2026-01-25 16:49:46','2026-01-25 16:49:46');
INSERT INTO `item_detail` VALUES ('128','23','1','1*40','40','12000','2026-01-25 16:50:07','2026-01-25 16:50:07');
INSERT INTO `item_detail` VALUES ('129','27','1','1*35','35','13300','2026-01-25 16:50:39','2026-01-25 16:50:39');
INSERT INTO `item_detail` VALUES ('130','33','1','1*30','30','15300','2026-01-25 16:51:06','2026-01-25 16:51:06');
INSERT INTO `item_detail` VALUES ('131','39','1','1*30','30','16200','2026-01-25 16:51:25','2026-01-25 16:51:25');
INSERT INTO `item_detail` VALUES ('136','66','1','1*360','360','13320','2026-01-26 19:43:49','2026-01-26 19:43:49');
INSERT INTO `item_detail` VALUES ('137','67','1','1*300','300','17100','2026-01-26 19:44:22','2026-01-26 19:44:22');
INSERT INTO `item_detail` VALUES ('138','68','1','1*192','192','15168','2026-01-26 19:44:48','2026-01-26 19:44:48');
INSERT INTO `item_detail` VALUES ('139','69','1','1*144','144','15840','2026-01-26 19:45:07','2026-01-26 19:45:07');
INSERT INTO `item_detail` VALUES ('140','70','1','1*90','90','13500','2026-01-26 19:48:36','2026-01-26 19:48:36');
INSERT INTO `item_detail` VALUES ('141','71','1','1*72','72','16200','2026-01-26 19:49:09','2026-01-26 19:49:09');
INSERT INTO `item_detail` VALUES ('143','46','1','1*30','30','14400','2026-01-27 19:43:59','2026-01-27 19:43:59');
INSERT INTO `item_detail` VALUES ('144','45','1','1*30','30','15600','2026-01-27 19:45:08','2026-01-27 19:45:08');
INSERT INTO `item_detail` VALUES ('145','48','1','1*192','192','13056','2026-01-27 19:45:34','2026-01-27 19:45:34');
INSERT INTO `item_detail` VALUES ('146','51','1','1*60','60','9900','2026-01-27 19:46:01','2026-01-27 19:46:01');
INSERT INTO `item_detail` VALUES ('147','53','1','1*56','56','8400','2026-01-27 19:46:32','2026-01-27 19:46:32');
INSERT INTO `item_detail` VALUES ('148','54','1','1*70','70','8050','2026-01-27 19:47:00','2026-01-27 19:47:00');
INSERT INTO `item_detail` VALUES ('149','55','1','1*96','96','15360','2026-01-27 19:47:31','2026-01-27 19:47:31');
INSERT INTO `item_detail` VALUES ('150','57','1','1*96','96','15840','2026-01-27 19:47:57','2026-01-27 19:47:57');
INSERT INTO `item_detail` VALUES ('151','58','1','1*90','90','13500','2026-01-27 19:48:24','2026-01-27 19:48:24');
INSERT INTO `item_detail` VALUES ('152','59','1','1*90','90','14400','2026-01-27 19:48:46','2026-01-27 19:48:46');
INSERT INTO `item_detail` VALUES ('153','85','1','1*100','100','8000','2026-01-27 19:49:20','2026-01-27 19:49:20');
INSERT INTO `item_detail` VALUES ('154','97','1','1*50','50','11000','2026-01-27 20:07:02','2026-01-27 20:07:02');
INSERT INTO `item_detail` VALUES ('155','62','1','1*100','100','16500','2026-01-27 20:08:58','2026-01-27 20:08:58');
INSERT INTO `item_detail` VALUES ('156','60','1','1*36','36','15480','2026-01-27 20:09:27','2026-01-27 20:09:27');
INSERT INTO `item_detail` VALUES ('157','64','1','1*36','36','17280','2026-01-27 20:09:56','2026-01-27 20:09:56');


DROP TABLE IF EXISTS `item_master`;
CREATE TABLE `item_master` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `purchase_rate` bigint unsigned DEFAULT NULL,
  `sale_rate` bigint unsigned DEFAULT NULL,
  `qty_pcs` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_master` VALUES ('9','TESTE ITEM','6','8','100','200','100','7','2025-10-27 19:13:27','2025-10-27 19:22:23');
INSERT INTO `item_master` VALUES ('10','3 Liter Pure','10','6','0','108','108','1','2025-10-27 19:43:14','2026-01-25 16:48:35');
INSERT INTO `item_master` VALUES ('11','3 Liter Semi','10','6','0','83','108','1','2025-10-27 19:44:21','2025-10-27 19:44:21');
INSERT INTO `item_master` VALUES ('12','3 Liter Silver','10','6','0','0','72','1','2025-10-27 20:13:12','2025-12-07 11:35:18');
INSERT INTO `item_master` VALUES ('13','6 Liter Pure','10','6','0','170','72','1','2025-11-08 16:10:29','2026-01-25 16:49:26');
INSERT INTO `item_master` VALUES ('14','DROSPA 25 X 2ml AMPOULES INJECTION','13','9','123','123','123','8','2025-11-10 21:39:11','2025-11-10 21:39:44');
INSERT INTO `item_master` VALUES ('16','6 Liter Semi','10','6','0','99','72','1','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_master` VALUES ('17','6 Liter Trim','10','6','0','147','72','1','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_master` VALUES ('18','6 Liter Silver','10','6','0','0','72','1','2025-12-07 12:15:34','2025-12-07 12:15:34');
INSERT INTO `item_master` VALUES ('19','9 Liter Pure','10','11','0','222','40','1','2025-12-11 18:29:32','2026-01-25 16:49:46');
INSERT INTO `item_master` VALUES ('20','9 Liter Semi','10','11','0','135','40','1','2025-12-11 18:31:38','2025-12-11 18:31:38');
INSERT INTO `item_master` VALUES ('21','9 Liter Trim','10','11','0','200','40','1','2025-12-11 18:33:19','2025-12-11 18:33:19');
INSERT INTO `item_master` VALUES ('22','9 Liter Silver','10','11','0','0','40','1','2025-12-11 18:34:08','2025-12-11 18:34:08');
INSERT INTO `item_master` VALUES ('23','14 Liter Pure','10','11','0','300','40','1','2025-12-11 18:36:17','2026-01-25 16:50:07');
INSERT INTO `item_master` VALUES ('24','14 Liter Semi','10','11','0','175','40','1','2025-12-11 18:37:18','2025-12-11 18:37:18');
INSERT INTO `item_master` VALUES ('25','14 Liter Trim','10','11','0','270','40','1','2025-12-11 18:38:14','2025-12-11 18:38:14');
INSERT INTO `item_master` VALUES ('26','14 Liter Silver','10','11','0','0','40','1','2025-12-11 19:02:53','2025-12-11 19:02:53');
INSERT INTO `item_master` VALUES ('27','17 Liter Pure','10','11','0','380','35','1','2025-12-11 19:04:58','2026-01-25 16:50:39');
INSERT INTO `item_master` VALUES ('28','17 Liter Semi','10','11','0','235','40','1','2025-12-11 19:25:53','2025-12-11 19:25:53');
INSERT INTO `item_master` VALUES ('29','17 Liter Silver','10','11','0','255','35','1','2025-12-14 12:25:09','2025-12-14 12:25:09');
INSERT INTO `item_master` VALUES ('30','17 Liter Pure BD','10','11','0','320','40','1','2025-12-14 12:32:03','2025-12-14 12:32:03');
INSERT INTO `item_master` VALUES ('31','17 Liter Semi BD','10','11','0','190','40','1','2025-12-14 12:33:27','2025-12-14 12:33:27');
INSERT INTO `item_master` VALUES ('32','17 Liter Silver BD','10','11','0','215','40','1','2025-12-14 12:35:00','2025-12-14 12:35:00');
INSERT INTO `item_master` VALUES ('33','20 Liter Pure','10','11','0','510','30','1','2025-12-14 12:36:43','2026-01-25 16:51:06');
INSERT INTO `item_master` VALUES ('34','20 Liter Semi','10','11','0','320','30','1','2025-12-14 12:38:37','2025-12-14 12:38:37');
INSERT INTO `item_master` VALUES ('35','20 Liter Silver','10','11','0','370','30','1','2025-12-14 12:43:17','2025-12-14 12:43:17');
INSERT INTO `item_master` VALUES ('36','20 Liter Pure BD','10','11','0','445','35','1','2025-12-14 12:45:29','2025-12-14 12:45:29');
INSERT INTO `item_master` VALUES ('37','20 Liter Semi BD','10','11','0','270','35','1','2025-12-14 12:51:17','2025-12-14 12:51:17');
INSERT INTO `item_master` VALUES ('38','20 Liter Silver BD','10','11','0','300','35','1','2025-12-14 12:52:16','2025-12-14 12:52:16');
INSERT INTO `item_master` VALUES ('39','27 Liter Pure','10','11','0','540','30','1','2025-12-14 12:54:06','2026-01-25 16:51:25');
INSERT INTO `item_master` VALUES ('40','27 Liter Semi','10','11','0','345','30','1','2025-12-14 12:56:17','2025-12-14 12:56:17');
INSERT INTO `item_master` VALUES ('41','27 Liter Silver','10','11','0','390','30','1','2025-12-14 12:59:57','2025-12-14 12:59:57');
INSERT INTO `item_master` VALUES ('42','27 Liter Pure BD','10','11','0','470','35','1','2025-12-14 13:06:36','2025-12-14 13:06:36');
INSERT INTO `item_master` VALUES ('43','27 Liter Semi BD','10','11','0','280','35','1','2025-12-14 13:09:53','2025-12-14 13:09:53');
INSERT INTO `item_master` VALUES ('44','27 Liter Silver BD','10','11','0','330','35','1','2025-12-14 13:29:09','2025-12-14 13:29:09');
INSERT INTO `item_master` VALUES ('45','Bath Mug Water Color','15','6','0','520','30','1','2025-12-14 18:19:11','2026-01-27 19:45:08');
INSERT INTO `item_master` VALUES ('46','Bath Mug Pure Band Color','15','6','0','480','30','1','2025-12-14 18:20:52','2026-01-27 19:43:37');
INSERT INTO `item_master` VALUES ('47','Bath Mug Semi','15','6','0','312','30','1','2025-12-14 18:22:22','2025-12-14 18:22:22');
INSERT INTO `item_master` VALUES ('48','Bath Mug Pure long Handle','15','6','0','68','192','1','2025-12-14 18:23:23','2026-01-27 19:45:34');
INSERT INTO `item_master` VALUES ('49','Bath Mug Pure IML','15','6','0','0','0','1','2025-12-14 18:26:26','2025-12-14 18:26:26');
INSERT INTO `item_master` VALUES ('50','Bath Mug Brown','15','6','0','33','360','1','2025-12-14 18:37:34','2025-12-14 18:37:34');
INSERT INTO `item_master` VALUES ('51','Jug Family Pure','16','6','0','165','60','1','2025-12-17 19:45:40','2026-01-27 19:46:01');
INSERT INTO `item_master` VALUES ('52','Jug Hot & Cool','15','6','0','270','32','1','2025-12-17 19:47:42','2025-12-17 19:47:42');
INSERT INTO `item_master` VALUES ('53','Jug Fridge Door','16','6','0','150','56','1','2025-12-17 19:48:31','2026-01-27 19:46:32');
INSERT INTO `item_master` VALUES ('54','Jug Flower','16','6','0','115','70','1','2025-12-17 19:49:25','2026-01-27 19:47:00');
INSERT INTO `item_master` VALUES ('55','Lunch Box Bounty','17','6','0','160','96','1','2025-12-17 20:00:40','2026-01-27 19:47:31');
INSERT INTO `item_master` VALUES ('56','Lunch Box Bounty Special','17','6','0','0','0','1','2025-12-18 18:20:08','2025-12-18 18:20:08');
INSERT INTO `item_master` VALUES ('57','Lunch Box Kitkat','17','6','0','165','96','1','2025-12-18 18:21:19','2026-01-27 19:47:57');
INSERT INTO `item_master` VALUES ('58','Lunch Box Subway','17','6','0','150','90','1','2025-12-18 18:22:19','2026-01-27 19:48:24');
INSERT INTO `item_master` VALUES ('59','Lunch Box Subway Special','17','6','0','160','90','1','2025-12-18 18:22:54','2026-01-27 19:48:46');
INSERT INTO `item_master` VALUES ('60','Chaba Gool Pure','18','12','0','430','36','1','2025-12-18 18:32:14','2026-01-27 20:09:27');
INSERT INTO `item_master` VALUES ('61','Chaba Gool Semi','18','12','0','260','36','1','2025-12-18 18:35:18','2025-12-18 18:35:18');
INSERT INTO `item_master` VALUES ('62','Chaba Afghan IML 2/P','18','12','0','165','100','1','2025-12-18 18:45:03','2026-01-27 20:08:58');
INSERT INTO `item_master` VALUES ('63','Chaba Afghan Semi 3/P','18','12','0','140','120','1','2025-12-18 18:46:20','2025-12-18 18:46:20');
INSERT INTO `item_master` VALUES ('64','Prime Chaba Pure','18','12','0','480','36','1','2025-12-18 18:50:22','2026-01-27 20:09:56');
INSERT INTO `item_master` VALUES ('65','Prime Chaba Semi','18','12','0','300','36','1','2025-12-18 18:58:02','2025-12-18 18:58:02');
INSERT INTO `item_master` VALUES ('66','Jar No. 3','19','6','0','37','360','1','2025-12-18 20:17:10','2026-01-26 19:42:00');
INSERT INTO `item_master` VALUES ('67','Jar No. 4','19','6','0','57','300','1','2025-12-18 20:20:26','2026-01-26 19:42:15');
INSERT INTO `item_master` VALUES ('68','Jar No. 5','19','6','0','79','192','1','2025-12-18 20:21:43','2026-01-26 19:42:46');
INSERT INTO `item_master` VALUES ('69','Jar No. 6','19','6','0','110','144','1','2025-12-18 20:24:25','2026-01-26 19:43:23');
INSERT INTO `item_master` VALUES ('70','Jar No. 7','19','6','0','150','90','1','2025-12-18 20:25:37','2026-01-26 19:48:36');
INSERT INTO `item_master` VALUES ('71','Jar No. 8','19','6','0','225','72','1','2025-12-18 20:26:48','2026-01-26 19:49:09');
INSERT INTO `item_master` VALUES ('72','Sig 0W-20','20','13','1000','1500','1200','7','2025-12-19 16:33:41','2025-12-19 16:35:25');
INSERT INTO `item_master` VALUES ('73','Soap Dish','21','6','','360','36','1','2026-01-03 16:25:49','2026-01-03 16:25:49');
INSERT INTO `item_master` VALUES ('74','Bowl Set 5/P','22','6','','420','0','1','2026-01-03 16:32:00','2026-01-03 16:32:00');
INSERT INTO `item_master` VALUES ('75','Bowl Set 3/P','22','6','','340','48','1','2026-01-03 16:34:00','2026-01-03 16:34:00');
INSERT INTO `item_master` VALUES ('76','Karhi Bowl 3/P','22','6','','220','60','1','2026-01-03 17:32:20','2026-01-03 17:32:20');
INSERT INTO `item_master` VALUES ('77','Karhi Bowl 2/P','22','6','','220','64','1','2026-01-03 17:33:50','2026-01-03 17:33:50');
INSERT INTO `item_master` VALUES ('78','Atta Bowl 1/P','22','6','','160','72','1','2026-01-03 17:34:52','2026-01-03 17:34:52');
INSERT INTO `item_master` VALUES ('79','Multi Purpose Rack 3/P','23','6','','150','64','1','2026-01-03 17:44:34','2026-01-03 17:44:34');
INSERT INTO `item_master` VALUES ('80','Office Rack','23','6','0','150','90','1','2026-01-03 17:45:40','2026-01-03 17:45:40');
INSERT INTO `item_master` VALUES ('81','Fruit Rack 3/P','23','12','','145','60','1','2026-01-03 17:50:09','2026-01-03 17:50:09');
INSERT INTO `item_master` VALUES ('82','3 Liter Semi Riyal','24','11','','65','100','1','2026-01-03 17:55:10','2026-01-03 17:55:10');
INSERT INTO `item_master` VALUES ('83','6 Liter Semi Riyal','24','11','','80','72','1','2026-01-03 17:56:48','2026-01-03 17:56:48');
INSERT INTO `item_master` VALUES ('84','Piyala','24','11','','65','100','1','2026-01-03 17:58:12','2026-01-03 17:58:12');
INSERT INTO `item_master` VALUES ('85','Piyala IML','24','11','','80','100','1','2026-01-03 18:00:44','2026-01-27 19:49:20');
INSERT INTO `item_master` VALUES ('86','Chaba Gool Semi Riyal','24','12','','65','200','1','2026-01-03 18:01:34','2026-01-03 18:01:34');
INSERT INTO `item_master` VALUES ('87','Gool Rack Silver Riyal 2/P','24','12','','75','100','1','2026-01-03 18:03:37','2026-01-03 18:03:37');
INSERT INTO `item_master` VALUES ('88','Choras Rack Silver Riyal 2/P','24','12','','85','99','1','2026-01-03 18:05:08','2026-01-03 18:05:08');
INSERT INTO `item_master` VALUES ('89','Corner Rack 3/P','23','6','','160','60','1','2026-01-03 18:06:01','2026-01-03 18:06:01');
INSERT INTO `item_master` VALUES ('90','Chaba Afghan Semi Riyal 2/P','24','12','','75','200','1','2026-01-03 18:09:07','2026-01-03 18:09:07');
INSERT INTO `item_master` VALUES ('91','Chaaye Poni','24','6','','70','180','1','2026-01-03 18:19:43','2026-01-03 18:19:43');
INSERT INTO `item_master` VALUES ('92','Laundry','24','11','','80','72','1','2026-01-03 18:20:32','2026-01-03 18:20:32');
INSERT INTO `item_master` VALUES ('93','Baby Pot Semi','25','11','','130','60','1','2026-01-03 18:24:03','2026-01-03 18:24:03');
INSERT INTO `item_master` VALUES ('94','Laundry Silver/Brown','26','11','','160','50','1','2026-01-10 17:01:15','2026-01-10 17:01:15');
INSERT INTO `item_master` VALUES ('95','Chaaye Poni New','24','6','0','65','180','1','2026-01-11 21:05:16','2026-01-11 21:05:16');
INSERT INTO `item_master` VALUES ('96','White Jug','24','12','','75','70','1','2026-01-11 21:53:18','2026-01-11 21:53:18');
INSERT INTO `item_master` VALUES ('97','Chaba Naan Semi','18','12','0','220','50','1','2026-01-27 20:07:02','2026-01-27 20:07:02');


DROP TABLE IF EXISTS `item_types`;
CREATE TABLE `item_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_types` VALUES ('1','','Shampoo','2025-09-17 18:33:21','2025-09-17 18:33:21','2');
INSERT INTO `item_types` VALUES ('5','fp','Shampo','2025-10-15 08:35:53','2025-10-15 08:38:30','7');
INSERT INTO `item_types` VALUES ('6','rp','ShampoRAW','2025-10-15 10:16:16','2025-10-15 10:16:16','7');
INSERT INTO `item_types` VALUES ('10','','Buckets','2025-10-25 18:54:20','2025-10-25 18:54:20','1');
INSERT INTO `item_types` VALUES ('13','','laminations','2025-11-10 21:36:03','2025-11-10 21:36:10','8');
INSERT INTO `item_types` VALUES ('15','','Bath Mug','2025-12-14 18:17:29','2025-12-14 18:17:29','1');
INSERT INTO `item_types` VALUES ('16','','Jug','2025-12-17 19:34:46','2025-12-17 19:34:46','1');
INSERT INTO `item_types` VALUES ('17','','Lunch Box','2025-12-17 19:51:58','2025-12-17 19:51:58','1');
INSERT INTO `item_types` VALUES ('18','','Chaba','2025-12-18 18:28:10','2025-12-18 18:28:10','1');
INSERT INTO `item_types` VALUES ('19','','Jar','2025-12-18 20:16:10','2025-12-18 20:16:10','1');
INSERT INTO `item_types` VALUES ('20','','Engine Oil','2025-12-19 16:22:54','2025-12-19 16:22:54','7');
INSERT INTO `item_types` VALUES ('21','','Soap','2026-01-03 16:22:58','2026-01-03 16:22:58','1');
INSERT INTO `item_types` VALUES ('22','','Bowl','2026-01-03 16:30:08','2026-01-03 16:30:08','1');
INSERT INTO `item_types` VALUES ('23','','Rack','2026-01-03 17:38:08','2026-01-03 17:38:08','1');
INSERT INTO `item_types` VALUES ('24','','Riyal','2026-01-03 17:42:35','2026-01-03 17:42:35','1');
INSERT INTO `item_types` VALUES ('25','','Baby Pot','2026-01-03 18:21:15','2026-01-03 18:21:15','1');
INSERT INTO `item_types` VALUES ('26','','Laundry','2026-01-03 18:22:14','2026-01-03 18:23:08','1');


DROP TABLE IF EXISTS `level1s`;
CREATE TABLE `level1s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level1s` VALUES ('2','Current Assets','01','3','2025-09-17 18:49:15','2025-09-17 18:49:15','2');
INSERT INTO `level1s` VALUES ('3','Current Assets','01','3','2025-09-18 00:40:07','2025-11-08 00:44:53','1');
INSERT INTO `level1s` VALUES ('4','Direct Expense','01','5','2025-09-18 00:55:45','2025-09-18 00:55:45','1');
INSERT INTO `level1s` VALUES ('5','Current Liabilities','01','2','2025-09-18 01:09:06','2025-09-18 01:09:06','1');
INSERT INTO `level1s` VALUES ('6','Current Revenue','01','4','2025-09-18 12:33:46','2025-09-18 12:33:46','1');
INSERT INTO `level1s` VALUES ('7','Current Assets','01','3','2025-09-20 14:32:26','2025-09-20 14:32:26','7');
INSERT INTO `level1s` VALUES ('8','Current Liabilities','01','2','2025-09-20 14:32:38','2025-09-20 14:32:38','7');
INSERT INTO `level1s` VALUES ('9','Capital','01','1','2025-09-22 01:03:53','2025-10-25 18:32:57','1');
INSERT INTO `level1s` VALUES ('11','Direct Expense','01','5','2025-10-15 12:12:20','2025-10-15 12:12:20','7');
INSERT INTO `level1s` VALUES ('12','Current Asset','01','3','2025-11-10 14:06:48','2025-11-10 14:09:09','8');
INSERT INTO `level1s` VALUES ('13','Long-Term Liabilities','01','2','2025-11-10 14:07:06','2025-11-10 14:07:06','8');
INSERT INTO `level1s` VALUES ('14','Sales Revenue','01','4','2025-11-10 14:07:21','2025-11-10 14:07:21','8');
INSERT INTO `level1s` VALUES ('15','Branch Revenue','01','4','2025-12-19 16:19:17','2025-12-19 16:19:17','7');


DROP TABLE IF EXISTS `level2s`;
CREATE TABLE `level2s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level2_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level2s` VALUES ('2','Bank Accounts','001','2','2025-09-17 18:50:09','2025-09-17 18:50:09','2');
INSERT INTO `level2s` VALUES ('3','Bank Accounts','001','3','2025-09-18 00:53:57','2025-09-18 00:53:57','1');
INSERT INTO `level2s` VALUES ('4','Cash Accounts','002','3','2025-09-18 00:54:07','2025-09-18 00:54:07','1');
INSERT INTO `level2s` VALUES ('5','Purchase Debit Level','001','4','2025-09-18 00:56:18','2025-09-18 00:56:18','1');
INSERT INTO `level2s` VALUES ('6','Suppliers','001','5','2025-09-18 01:09:20','2025-09-18 01:09:20','1');
INSERT INTO `level2s` VALUES ('7','Sale Credit Accunts','001','6','2025-09-18 12:34:10','2025-09-22 10:44:03','1');
INSERT INTO `level2s` VALUES ('8','Customer','002','5','2025-09-18 16:21:49','2025-09-18 16:21:49','1');
INSERT INTO `level2s` VALUES ('9','Caiptal Account','001','9','2025-09-22 01:05:14','2025-10-25 18:33:23','1');
INSERT INTO `level2s` VALUES ('11','Employees','003','5','2025-10-01 14:43:39','2025-10-01 14:43:39','1');
INSERT INTO `level2s` VALUES ('12','Customers','001','7','2025-10-15 12:10:40','2025-10-15 12:10:59','7');
INSERT INTO `level2s` VALUES ('13','Supplier','002','8','2025-10-15 12:10:51','2025-10-15 12:10:51','7');
INSERT INTO `level2s` VALUES ('14','Bank Accounts','002','7','2025-10-15 12:11:30','2025-10-15 12:11:30','7');
INSERT INTO `level2s` VALUES ('15','Cash Accounts','003','7','2025-10-15 12:11:44','2025-10-15 12:11:44','7');
INSERT INTO `level2s` VALUES ('16','Purchase Accounts','001','11','2025-10-15 12:12:39','2025-10-15 12:12:39','7');
INSERT INTO `level2s` VALUES ('17','Expense','002','11','2025-10-18 07:09:16','2025-10-18 07:09:16','7');
INSERT INTO `level2s` VALUES ('18','Cash & Banks','001','12','2025-11-10 14:09:33','2025-11-10 21:23:02','8');
INSERT INTO `level2s` VALUES ('19','Inventory','002','12','2025-11-10 14:09:50','2025-11-10 14:09:50','8');
INSERT INTO `level2s` VALUES ('22','Stock Account','004','7','2025-12-19 16:18:40','2025-12-19 16:18:40','7');
INSERT INTO `level2s` VALUES ('23','Revenue from Sales','001','15','2025-12-19 16:19:33','2025-12-19 16:19:33','7');


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1','2019_12_14_000001_create_personal_access_tokens_table','1');
INSERT INTO `migrations` VALUES ('2','2025_09_18_120600_create_purchase_return_masters_table','2');
INSERT INTO `migrations` VALUES ('3','2025_09_18_120750_create_purchase_return_invoices_table','2');
INSERT INTO `migrations` VALUES ('4','2025_09_18_134602_create_customers_table','3');
INSERT INTO `migrations` VALUES ('5','2025_09_18_135718_create_sale_invoice_table','4');
INSERT INTO `migrations` VALUES ('6','2025_09_18_140058_create_sale_invoice_return_table','4');
INSERT INTO `migrations` VALUES ('7','2025_09_19_172738_create_sale_return_masters_table','5');
INSERT INTO `migrations` VALUES ('8','2025_09_19_184055_create_sale_return_invoices_table','5');
INSERT INTO `migrations` VALUES ('9','2025_09_20_155910_add_cid_to_item_logs_table','6');
INSERT INTO `migrations` VALUES ('10','2025_10_15_133111_add_item_type_to_item_type_table','7');
INSERT INTO `migrations` VALUES ('11','2025_10_15_151806_add_col_to_item_masters_table','8');
INSERT INTO `migrations` VALUES ('16','2025_10_15_152737_create_production_master_table','9');
INSERT INTO `migrations` VALUES ('17','2025_10_15_153012_create_production_detail_table','9');
INSERT INTO `migrations` VALUES ('20','2025_10_15_170406_create_consumption_masters_table','10');
INSERT INTO `migrations` VALUES ('21','2025_10_15_170412_create_consumption_details_table','10');
INSERT INTO `migrations` VALUES ('22','2025_10_16_003713_create_stock_adj_master_table','11');
INSERT INTO `migrations` VALUES ('23','2025_10_16_003734_create_stock_adj_table','11');
INSERT INTO `migrations` VALUES ('24','2025_10_16_005456_add_col_open_qty_to_item_masters_table','12');
INSERT INTO `migrations` VALUES ('27','2025_10_16_123138_create_production_consumed_table','13');
INSERT INTO `migrations` VALUES ('28','2025_10_17_191353_update_col_supplier_table','14');
INSERT INTO `migrations` VALUES ('29','2025_10_18_102053_add_col_to_production_master_table','15');
INSERT INTO `migrations` VALUES ('30','2025_10_18_115508_create_expense_detail_table','16');
INSERT INTO `migrations` VALUES ('31','2025_10_18_115646_create_expense_masters_table','16');
INSERT INTO `migrations` VALUES ('32','2025_10_22_011511_create_store_table','17');
INSERT INTO `migrations` VALUES ('34','2025_10_22_012808_create_item_master_table','18');
INSERT INTO `migrations` VALUES ('35','2025_10_22_013455_item_detail_table','19');
INSERT INTO `migrations` VALUES ('36','2025_10_22_023123_add_col_crt_qty_to_item_detail_table','20');
INSERT INTO `migrations` VALUES ('37','2025_10_22_125703_create_sale_invoices_table','21');
INSERT INTO `migrations` VALUES ('38','2025_10_22_125729_create_sale_invoice_items_table','22');
INSERT INTO `migrations` VALUES ('39','2025_10_22_130403_add_col_to_sale_invoice_items_table','23');
INSERT INTO `migrations` VALUES ('40','2025_10_22_130431_add_col_to_sale_invoices_table','23');
INSERT INTO `migrations` VALUES ('41','2025_10_22_140206_add_col_to_sale_invoices_table','24');
INSERT INTO `migrations` VALUES ('42','2025_10_22_140302_add_col_to_sale_invoice_items_table','25');
INSERT INTO `migrations` VALUES ('43','2025_10_22_170145_drop_col_to_sale_invoice_items_table','26');
INSERT INTO `migrations` VALUES ('44','2025_10_22_185204_add_col_to_sale_invoice_items_table','27');
INSERT INTO `migrations` VALUES ('45','2025_10_22_185548_drop_col_to_sale_invoice_items_table','28');
INSERT INTO `migrations` VALUES ('46','2025_10_22_192840_add_col_to_sale_invoice_table','29');
INSERT INTO `migrations` VALUES ('47','2025_10_22_200851_create_purchase_invoice_table','30');
INSERT INTO `migrations` VALUES ('48','2025_10_22_201052_create_purchase_invoice_item_table','31');
INSERT INTO `migrations` VALUES ('49','2025_10_23_000629_create_sale_return_invoice_table','32');
INSERT INTO `migrations` VALUES ('50','2025_10_23_000716_create_sale_return_invoice_item_table','32');
INSERT INTO `migrations` VALUES ('51','2025_10_23_015807_create_purchase_return_invoice_table','33');
INSERT INTO `migrations` VALUES ('52','2025_10_23_015816_create_purchase_return_invoice_item_table','33');
INSERT INTO `migrations` VALUES ('53','2025_10_23_170510_create_opening_stocks_table','34');
INSERT INTO `migrations` VALUES ('54','2025_10_23_181824_create_stock_adjustment_table','35');
INSERT INTO `migrations` VALUES ('55','2025_10_23_183745_add_col_to_sale_return_details_table','35');
INSERT INTO `migrations` VALUES ('56','2025_10_23_183950_add_col_to_purchase_invoice_details_table','35');
INSERT INTO `migrations` VALUES ('57','2025_10_23_184021_add_col_to_purchase_return_details_table','35');
INSERT INTO `migrations` VALUES ('58','2025_10_24_121456_add_p_qty_to_sale_invoice_details','36');
INSERT INTO `migrations` VALUES ('59','2025_10_24_121534_add_p_qty_to_purchase_invoice_details','36');
INSERT INTO `migrations` VALUES ('60','2025_10_24_121613_add_p_qty_to_purchase_return_details','36');
INSERT INTO `migrations` VALUES ('61','2025_10_24_121620_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('62','2025_10_24_125612_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('63','2025_10_24_144509_add_p_qty_to_opening_stocks_table','36');
INSERT INTO `migrations` VALUES ('64','2025_10_24_144607_add_p_qty_to_stock_adjustment_table','36');
INSERT INTO `migrations` VALUES ('65','2025_11_05_011214_add_col_to_purchase_invoice_masters_table','37');
INSERT INTO `migrations` VALUES ('66','2025_11_05_011427_add_col_to_sale_invoices_masters_table','37');
INSERT INTO `migrations` VALUES ('67','2026_01_06_123922_add_col_to_sale_invoice_detail_table','38');
INSERT INTO `migrations` VALUES ('68','2026_01_17_141924_add_col_to_workspace_table','39');
INSERT INTO `migrations` VALUES ('69','2026_01_24_001819_add_col_to_workspace_table','40');


DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `module` VALUES ('1','Level1','','');
INSERT INTO `module` VALUES ('2','Level2','','');
INSERT INTO `module` VALUES ('3','Chart Of Account','','');
INSERT INTO `module` VALUES ('4','Cash Payment','','');
INSERT INTO `module` VALUES ('5','Cash Receipt','','');
INSERT INTO `module` VALUES ('6','Bank Payment','','');
INSERT INTO `module` VALUES ('7','Bank Receipt','','');
INSERT INTO `module` VALUES ('8','Journal Voucher','','');
INSERT INTO `module` VALUES ('9','Opening Balance','','');
INSERT INTO `module` VALUES ('10','Ledger','','');
INSERT INTO `module` VALUES ('11','Cash Book','','');
INSERT INTO `module` VALUES ('12','Payables','','');
INSERT INTO `module` VALUES ('13','Recieveable','','');
INSERT INTO `module` VALUES ('14','Trial Balance','','');
INSERT INTO `module` VALUES ('15','Purchase Invoice','','');
INSERT INTO `module` VALUES ('16','Purchase Return Invoice','','');
INSERT INTO `module` VALUES ('17','Supplier','','');
INSERT INTO `module` VALUES ('18','Sale Invoice','','');
INSERT INTO `module` VALUES ('19','Sale Return Invoice','','');
INSERT INTO `module` VALUES ('20','Customer','','');
INSERT INTO `module` VALUES ('21','Item Category','','');
INSERT INTO `module` VALUES ('22','Units','','');
INSERT INTO `module` VALUES ('23','Store','','');
INSERT INTO `module` VALUES ('24','Item Registration','','');
INSERT INTO `module` VALUES ('25','Stock Adjustment','','');
INSERT INTO `module` VALUES ('26','Stock Report','','');
INSERT INTO `module` VALUES ('27','ERP Parameters','','');
INSERT INTO `module` VALUES ('28','Item Registration Log','','');
INSERT INTO `module` VALUES ('29','App Module','','');
INSERT INTO `module` VALUES ('30','View Company','','');
INSERT INTO `module` VALUES ('36','Store Wise Report','2025-10-05 22:18:19','2025-10-05 22:18:19');
INSERT INTO `module` VALUES ('37','Brand Name','','');
INSERT INTO `module` VALUES ('39','Opening Stock','','');


DROP TABLE IF EXISTS `opening_stocks`;
CREATE TABLE `opening_stocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `opening_stocks` VALUES ('2','7','9','22','3','2025-10-27','1.00','0.00','50000.00','100.00','50000.00','','2025-10-27 19:23:27','2025-10-27 19:23:27','250');
INSERT INTO `opening_stocks` VALUES ('4','7','72','97','7','2025-12-19','100.00','6.00','12000.00','1000.00','1206000.00','','2025-12-19 16:45:33','2025-12-19 16:45:33','12');
INSERT INTO `opening_stocks` VALUES ('5','7','72','98','7','2025-12-19','50.00','2.00','16000.00','1000.00','802000.00','','2025-12-19 16:48:39','2025-12-19 16:48:39','4');


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_details`;
CREATE TABLE `purchase_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_masters`;
CREATE TABLE `purchase_invoice_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_return_details`;
CREATE TABLE `purchase_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_details` VALUES ('11','1','1','11','1','7','24','0.00','0.00','0.00','1.00','83.00','83.00','0.00','83.00','2025-11-10 23:14:24','2025-11-10 23:14:24','2025-11-10','108');


DROP TABLE IF EXISTS `purchase_return_masters`;
CREATE TABLE `purchase_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_masters` VALUES ('11','1','2025-11-10','7','','0.00','0.00','0.00','83.00','-3358.00','1','2025-11-10 23:14:24','2025-11-10 23:14:24');


DROP TABLE IF EXISTS `purchase_returns`;
CREATE TABLE `purchase_returns` (
  `id` bigint unsigned NOT NULL,
  `vorcher_no` int NOT NULL,
  `width` float NOT NULL,
  `lenght` float NOT NULL,
  `grammage` float NOT NULL,
  `qty` float NOT NULL,
  `rate` float NOT NULL,
  `total_wt` float NOT NULL,
  `amount` float NOT NULL,
  `item_code` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `freight` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `rights`;
CREATE TABLE `rights` (
  `id` int NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `app_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add` tinyint(1) DEFAULT '0',
  `del` tinyint(1) DEFAULT '0',
  `edit` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_invoice_details`;
CREATE TABLE `sale_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoice_details` VALUES ('51','1','3','9','21','100.00','200.00','20000.00','12.00','20000.00','240000.00','0.00','260000.00','2025-11-05 02:02:24','2025-11-05 02:02:24','7','11','2025-10-28','120');
INSERT INTO `sale_invoice_details` VALUES ('54','2','3','9','21','0.00','200.00','0.00','10.00','20000.00','200000.00','0.00','200000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','11','2025-11-05','120');
INSERT INTO `sale_invoice_details` VALUES ('57','1','4','14','33','11.00','123.00','1353.00','1.00','12.00','12.00','1.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','13','2025-11-10','12');
INSERT INTO `sale_invoice_details` VALUES ('65','3','3','9','21','0.00','200.00','0.00','1.00','20000.00','20000.00','0.00','20000.00','2025-12-19 16:21:31','2025-12-19 16:21:31','7','11','2025-12-19','120');
INSERT INTO `sale_invoice_details` VALUES ('72','1','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-03 16:53:15','2026-01-03 16:53:15','1','92','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('73','1','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-03 16:53:15','2026-01-03 16:53:15','1','92','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('74','2','6','87','113','0.00','75.00','0.00','5.00','7500.00','37500.00','0.00','37500.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('75','2','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('76','2','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('77','2','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('78','2','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('79','3','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:52:31','2026-01-04 16:52:31','1','42','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('80','4','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('81','4','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('82','4','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('83','4','1','83','109','0.00','80.00','0.00','3.00','5760.00','17280.00','0.00','17280.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('84','5','2','40','62','0.00','345.00','0.00','2.00','10350.00','20700.00','10.00','18630.00','2026-01-04 17:02:32','2026-01-04 17:02:32','1','51','2026-01-03','30');
INSERT INTO `sale_invoice_details` VALUES ('85','6','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-03','90');
INSERT INTO `sale_invoice_details` VALUES ('86','6','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('87','6','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('88','6','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('89','6','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','10.00','11340.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','180');
INSERT INTO `sale_invoice_details` VALUES ('97','9','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-04 17:29:31','2026-01-04 17:29:31','1','47','2026-01-03','35');
INSERT INTO `sale_invoice_details` VALUES ('98','10','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('99','10','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('100','10','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('101','10','6','86','112','0.00','65.00','0.00','1.00','13000.00','13000.00','0.00','13000.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','200');
INSERT INTO `sale_invoice_details` VALUES ('102','10','2','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('103','10','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('104','10','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('105','10','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('112','11','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:20:53','2026-01-04 20:20:53','1','60','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('113','12','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','78','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('114','12','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','78','2026-01-04','99');
INSERT INTO `sale_invoice_details` VALUES ('122','14','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 20:55:13','2026-01-04 20:55:13','1','46','2026-01-04','90');
INSERT INTO `sale_invoice_details` VALUES ('123','14','1','13','37','500.00','115.00','57500.00','0.00','13320.00','0.00','0.00','57500.00','2026-01-04 20:55:13','2026-01-04 20:55:13','1','46','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('124','13','6','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-04 20:57:12','2026-01-04 20:57:12','1','45','2026-01-04','40');
INSERT INTO `sale_invoice_details` VALUES ('129','16','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('130','16','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('131','16','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','108');
INSERT INTO `sale_invoice_details` VALUES ('132','15','6','61','83','0.00','260.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-06 19:58:41','2026-01-06 19:58:41','1','114','2026-01-04','36');
INSERT INTO `sale_invoice_details` VALUES ('137','17','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('138','17','1','82','108','0.00','65.00','0.00','1.00','6500.00','6500.00','0.00','6500.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('139','17','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('140','18','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 19:09:15','2026-01-07 19:09:15','1','30','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('141','18','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 19:09:15','2026-01-07 19:09:15','1','30','2026-01-05','30');
INSERT INTO `sale_invoice_details` VALUES ('142','19','1','51','73','0.00','175.00','0.00','1.00','10500.00','10500.00','10.00','9450.00','2026-01-07 19:22:41','2026-01-07 19:22:41','1','100','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('148','21','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 19:49:07','2026-01-07 19:49:07','1','25','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('149','21','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-07 19:49:07','2026-01-07 19:49:07','1','25','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('151','23','2','25','47','0.00','270.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-07 20:03:38','2026-01-07 20:03:38','1','19','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('152','24','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('153','24','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('154','24','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('155','24','1','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('156','25','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-07 21:37:45','2026-01-07 21:37:45','1','31','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('161','26','6','68','90','0.00','83.00','0.00','2.00','15936.00','31872.00','10.00','28684.80','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','192');
INSERT INTO `sale_invoice_details` VALUES ('162','26','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','144');
INSERT INTO `sale_invoice_details` VALUES ('163','26','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('164','26','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('165','27','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 21:47:07','2026-01-07 21:47:07','1','16','2025-12-25','90');
INSERT INTO `sale_invoice_details` VALUES ('166','20','1','61','83','0.00','260.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','36');
INSERT INTO `sale_invoice_details` VALUES ('167','20','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('168','20','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('169','20','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','108');
INSERT INTO `sale_invoice_details` VALUES ('170','20','1','11','35','0.00','83.00','0.00','1.00','8964.00','8964.00','10.00','8067.60','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','108');
INSERT INTO `sale_invoice_details` VALUES ('171','28','2','21','43','0.00','200.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('172','28','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('173','28','2','25','47','0.00','270.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('174','28','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('175','28','6','66','88','0.00','39.00','0.00','1.00','14040.00','14040.00','10.00','12636.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','360');
INSERT INTO `sale_invoice_details` VALUES ('176','28','2','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('177','28','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','144');
INSERT INTO `sale_invoice_details` VALUES ('178','28','2','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('180','30','1','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('181','30','2','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('182','30','2','28','50','0.00','235.00','0.00','2.00','8225.00','16450.00','10.00','14805.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('183','30','2','34','56','0.00','320.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','30');
INSERT INTO `sale_invoice_details` VALUES ('184','30','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('185','30','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('186','30','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('195','33','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','134','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('196','33','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','134','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('206','35','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('207','35','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('208','35','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','60');
INSERT INTO `sale_invoice_details` VALUES ('209','35','6','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('210','35','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('211','35','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','64');
INSERT INTO `sale_invoice_details` VALUES ('212','35','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('213','35','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('214','36','1','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('215','36','6','24','42','0.00','175.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('216','36','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('217','37','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('218','37','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('219','37','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('220','37','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-10','100');
INSERT INTO `sale_invoice_details` VALUES ('221','38','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','90');
INSERT INTO `sale_invoice_details` VALUES ('222','38','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('223','38','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('224','38','2','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('225','38','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','192');
INSERT INTO `sale_invoice_details` VALUES ('235','39','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('236','39','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('237','39','1','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','90');
INSERT INTO `sale_invoice_details` VALUES ('238','39','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','72');
INSERT INTO `sale_invoice_details` VALUES ('239','39','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','64');
INSERT INTO `sale_invoice_details` VALUES ('240','39','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-06','192');
INSERT INTO `sale_invoice_details` VALUES ('241','39','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('242','39','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','90');
INSERT INTO `sale_invoice_details` VALUES ('243','39','6','79','105','0.00','150.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','64');
INSERT INTO `sale_invoice_details` VALUES ('244','39','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('262','41','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 22:21:51','2026-01-11 22:21:51','1','68','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('263','42','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('264','42','6','90','116','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('265','42','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','72');
INSERT INTO `sale_invoice_details` VALUES ('266','42','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','100');
INSERT INTO `sale_invoice_details` VALUES ('267','42','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','99');
INSERT INTO `sale_invoice_details` VALUES ('268','43','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','57','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('269','43','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','57','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('276','45','2','42','64','0.00','470.00','0.00','1.00','16450.00','16450.00','10.00','14805.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('277','45','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('278','45','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('279','45','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('280','45','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('281','45','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('282','45','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('283','45','6','64','86','0.00','500.00','0.00','2.00','18000.00','36000.00','10.00','32400.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','36');
INSERT INTO `sale_invoice_details` VALUES ('284','45','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('285','45','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('286','45','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('287','45','2','29','51','0.00','255.00','0.00','1.00','8925.00','8925.00','10.00','8032.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('288','45','1','11','35','0.00','83.00','0.00','1.00','8964.00','8964.00','10.00','8067.60','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','108');
INSERT INTO `sale_invoice_details` VALUES ('289','45','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','100');
INSERT INTO `sale_invoice_details` VALUES ('290','46','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 22:55:45','2026-01-11 22:55:45','1','67','2026-01-06','99');
INSERT INTO `sale_invoice_details` VALUES ('291','44','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('292','44','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('293','44','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('294','44','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('295','44','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('296','44','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('297','47','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('298','47','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('299','47','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-11','99');
INSERT INTO `sale_invoice_details` VALUES ('300','48','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','77','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('301','48','2','59','123','0.00','165.00','0.00','1.00','14850.00','14850.00','10.00','13365.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','77','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('315','50','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('316','50','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('317','50','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('318','51','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 23:30:31','2026-01-11 23:30:31','1','70','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('319','52','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','136','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('320','52','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','136','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('322','54','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('323','54','1','83','109','0.00','80.00','0.00','3.00','5760.00','17280.00','0.00','17280.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('324','54','1','94','120','0.00','160.00','0.00','5.00','8000.00','40000.00','10.00','36000.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','50');
INSERT INTO `sale_invoice_details` VALUES ('325','54','1','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('326','54','6','63','85','0.00','140.00','0.00','2.00','16800.00','33600.00','10.00','30240.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','120');
INSERT INTO `sale_invoice_details` VALUES ('327','54','6','81','107','0.00','145.00','0.00','3.00','8700.00','26100.00','10.00','23490.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('328','54','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','90');
INSERT INTO `sale_invoice_details` VALUES ('329','55','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('330','55','6','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('331','55','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','30');
INSERT INTO `sale_invoice_details` VALUES ('332','55','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','72');
INSERT INTO `sale_invoice_details` VALUES ('333','55','1','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','100');
INSERT INTO `sale_invoice_details` VALUES ('340','57','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-11 23:54:27','2026-01-11 23:54:27','1','78','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('345','59','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','108');
INSERT INTO `sale_invoice_details` VALUES ('346','59','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('347','59','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('348','59','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('349','60','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-12 00:03:06','2026-01-12 00:03:06','1','48','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('351','61','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('352','61','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','64');
INSERT INTO `sale_invoice_details` VALUES ('353','61','6','89','115','0.00','160.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('354','61','6','80','106','0.00','150.00','0.00','3.00','13500.00','40500.00','0.00','40500.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','90');
INSERT INTO `sale_invoice_details` VALUES ('355','62','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('356','62','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('357','62','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('358','62','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('359','63','6','64','86','0.00','500.00','0.00','2.00','18000.00','36000.00','10.00','32400.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('360','63','1','79','105','0.00','150.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('361','63','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','90');
INSERT INTO `sale_invoice_details` VALUES ('362','63','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('363','64','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('364','64','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('365','64','2','65','87','0.00','300.00','0.00','3.00','10800.00','32400.00','10.00','29160.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('366','64','6','64','86','0.00','500.00','0.00','1.00','18000.00','18000.00','10.00','16200.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('367','64','6','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','70');
INSERT INTO `sale_invoice_details` VALUES ('368','65','6','81','107','0.00','115.00','0.00','5.00','6900.00','34500.00','0.00','34500.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('369','65','1','80','106','0.00','120.00','0.00','3.00','10800.00','32400.00','0.00','32400.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('370','65','6','79','105','0.00','120.00','0.00','5.00','7680.00','38400.00','0.00','38400.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('371','40','2','95','121','0.00','65.00','0.00','2.00','11700.00','23400.00','0.00','23400.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('372','40','1','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','70');
INSERT INTO `sale_invoice_details` VALUES ('373','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','72');
INSERT INTO `sale_invoice_details` VALUES ('374','40','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('375','40','6','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('376','40','2','77','103','0.00','220.00','0.00','1.00','14080.00','14080.00','10.00','12672.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('377','40','2','76','102','0.00','220.00','0.00','1.00','13200.00','13200.00','10.00','11880.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('378','40','2','96','122','0.00','75.00','0.00','1.00','5250.00','5250.00','0.00','5250.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','70');
INSERT INTO `sale_invoice_details` VALUES ('379','40','6','90','116','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('380','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-07','72');
INSERT INTO `sale_invoice_details` VALUES ('381','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('382','40','1','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-08','70');
INSERT INTO `sale_invoice_details` VALUES ('383','40','1','83','109','0.00','80.00','0.00','10.00','5760.00','57600.00','0.00','57600.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','72');
INSERT INTO `sale_invoice_details` VALUES ('384','40','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','50');
INSERT INTO `sale_invoice_details` VALUES ('385','40','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('386','40','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','192');
INSERT INTO `sale_invoice_details` VALUES ('387','40','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','144');
INSERT INTO `sale_invoice_details` VALUES ('388','49','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('389','49','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('390','49','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('391','49','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','192');
INSERT INTO `sale_invoice_details` VALUES ('392','49','6','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('393','49','1','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('394','49','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('395','49','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('396','49','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('397','49','6','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('398','49','6','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('399','49','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','108');
INSERT INTO `sale_invoice_details` VALUES ('400','56','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','50');
INSERT INTO `sale_invoice_details` VALUES ('401','56','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('402','56','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('403','56','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-09','60');
INSERT INTO `sale_invoice_details` VALUES ('404','56','2','28','50','0.00','235.00','0.00','2.00','8225.00','16450.00','10.00','14805.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-09','35');
INSERT INTO `sale_invoice_details` VALUES ('405','58','1','71','93','0.00','237.00','0.00','3.00','17064.00','51192.00','10.00','46072.80','2026-01-12 11:29:24','2026-01-12 11:29:24','1','58','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('406','58','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:29:24','2026-01-12 11:29:24','1','58','2026-01-10','64');
INSERT INTO `sale_invoice_details` VALUES ('407','66','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','139','2026-01-12','60');
INSERT INTO `sale_invoice_details` VALUES ('408','66','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','139','2026-01-12','64');
INSERT INTO `sale_invoice_details` VALUES ('409','67','6','24','46','0.00','175.00','0.00','3.00','7000.00','21000.00','10.00','18900.00','2026-01-12 20:21:18','2026-01-12 20:21:18','1','130','2026-01-12','40');
INSERT INTO `sale_invoice_details` VALUES ('410','67','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-12 20:21:18','2026-01-12 20:21:18','1','130','2026-01-12','72');
INSERT INTO `sale_invoice_details` VALUES ('411','68','6','66','88','0.00','39.00','0.00','1.00','14040.00','14040.00','10.00','12636.00','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-13','360');
INSERT INTO `sale_invoice_details` VALUES ('412','68','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('413','68','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('414','68','6','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-11','30');
INSERT INTO `sale_invoice_details` VALUES ('415','68','6','61','83','0.00','260.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-13','36');
INSERT INTO `sale_invoice_details` VALUES ('416','68','6','60','82','0.00','480.00','0.00','1.00','17280.00','17280.00','10.00','15552.00','2026-01-13 21:24:51','2026-01-13 21:24:51','1','97','2026-01-13','36');
INSERT INTO `sale_invoice_details` VALUES ('433','70','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('434','70','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-11','30');
INSERT INTO `sale_invoice_details` VALUES ('435','70','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-12','30');
INSERT INTO `sale_invoice_details` VALUES ('436','70','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-12','40');
INSERT INTO `sale_invoice_details` VALUES ('437','70','2','65','87','0.00','300.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-12','36');
INSERT INTO `sale_invoice_details` VALUES ('438','70','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-14 19:21:29','2026-01-14 19:21:29','1','15','2026-01-13','40');
INSERT INTO `sale_invoice_details` VALUES ('439','71','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-14 19:25:46','2026-01-14 19:25:46','1','16','2026-01-14','30');
INSERT INTO `sale_invoice_details` VALUES ('441','72','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-14 19:27:59','2026-01-14 19:27:59','1','30','2026-01-13','30');
INSERT INTO `sale_invoice_details` VALUES ('444','74','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-14 19:36:57','2026-01-14 19:36:57','1','27','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('445','74','1','51','73','0.00','175.00','0.00','1.00','10500.00','10500.00','10.00','9450.00','2026-01-14 19:36:57','2026-01-14 19:36:57','1','27','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('446','75','6','62','84','0.00','175.00','0.00','2.00','17500.00','35000.00','10.00','31500.00','2026-01-14 19:39:31','2026-01-14 19:39:31','1','21','2026-01-08','100');
INSERT INTO `sale_invoice_details` VALUES ('447','75','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-14 19:39:31','2026-01-14 19:39:31','1','21','2026-01-08','90');
INSERT INTO `sale_invoice_details` VALUES ('448','76','6','64','86','0.00','500.00','0.00','1.00','18000.00','18000.00','10.00','16200.00','2026-01-14 19:42:02','2026-01-14 19:42:02','1','28','2026-01-08','36');
INSERT INTO `sale_invoice_details` VALUES ('454','78','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-14 19:53:34','2026-01-14 19:53:34','1','31','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('455','78','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-14 19:53:34','2026-01-14 19:53:34','1','31','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('456','77','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-14 19:54:50','2026-01-14 19:54:50','1','18','2026-01-08','108');
INSERT INTO `sale_invoice_details` VALUES ('457','77','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-14 19:54:50','2026-01-14 19:54:50','1','18','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('458','79','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-14 20:01:11','2026-01-14 20:01:11','1','19','2026-01-08','50');
INSERT INTO `sale_invoice_details` VALUES ('461','69','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('462','69','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('463','69','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','40');
INSERT INTO `sale_invoice_details` VALUES ('464','69','6','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','300');
INSERT INTO `sale_invoice_details` VALUES ('465','69','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','192');
INSERT INTO `sale_invoice_details` VALUES ('466','69','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-14 20:05:34','2026-01-14 20:05:34','1','125','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('467','81','6','79','105','64.00','132.00','8448.00','0.00','9600.00','0.00','0.00','8448.00','2026-01-14 20:18:44','2026-01-14 20:18:44','1','37','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('469','82','1','83','109','0.00','80.00','0.00','10.00','5760.00','57600.00','0.00','57600.00','2026-01-18 18:33:20','2026-01-18 18:33:20','1','50','2026-01-12','72');
INSERT INTO `sale_invoice_details` VALUES ('479','84','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-12','144');
INSERT INTO `sale_invoice_details` VALUES ('480','84','2','39','61','0.00','560.00','0.00','2.00','16800.00','33600.00','10.00','30240.00','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-13','30');
INSERT INTO `sale_invoice_details` VALUES ('481','84','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-15','72');
INSERT INTO `sale_invoice_details` VALUES ('482','84','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-15','72');
INSERT INTO `sale_invoice_details` VALUES ('483','84','1','21','43','0.00','200.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('484','84','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-18 18:57:21','2026-01-18 18:57:21','1','53','2026-01-15','108');
INSERT INTO `sale_invoice_details` VALUES ('485','85','2','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-18 19:03:34','2026-01-18 19:03:34','1','48','2026-01-12','180');
INSERT INTO `sale_invoice_details` VALUES ('486','85','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-18 19:03:34','2026-01-18 19:03:34','1','48','2026-01-12','180');
INSERT INTO `sale_invoice_details` VALUES ('487','86','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-18 19:08:58','2026-01-18 19:08:58','1','51','2026-01-12','100');
INSERT INTO `sale_invoice_details` VALUES ('488','86','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-18 19:08:58','2026-01-18 19:08:58','1','51','2026-01-12','35');
INSERT INTO `sale_invoice_details` VALUES ('489','87','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-18 19:17:39','2026-01-18 19:17:39','1','70','2026-01-12','50');
INSERT INTO `sale_invoice_details` VALUES ('490','87','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-18 19:17:39','2026-01-18 19:17:39','1','70','2026-01-15','100');
INSERT INTO `sale_invoice_details` VALUES ('491','88','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-12','72');
INSERT INTO `sale_invoice_details` VALUES ('492','88','6','94','120','0.00','160.00','0.00','3.00','8000.00','24000.00','10.00','21600.00','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-13','50');
INSERT INTO `sale_invoice_details` VALUES ('493','88','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-17','192');
INSERT INTO `sale_invoice_details` VALUES ('494','88','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-17','144');
INSERT INTO `sale_invoice_details` VALUES ('495','88','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-17','90');
INSERT INTO `sale_invoice_details` VALUES ('496','88','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-18 19:24:56','2026-01-18 19:24:56','1','59','2026-01-17','72');
INSERT INTO `sale_invoice_details` VALUES ('497','89','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','44','2026-01-13','180');
INSERT INTO `sale_invoice_details` VALUES ('498','89','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','44','2026-01-13','40');
INSERT INTO `sale_invoice_details` VALUES ('499','89','1','59','123','0.00','165.00','0.00','2.00','14850.00','29700.00','10.00','26730.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','44','2026-01-14','90');
INSERT INTO `sale_invoice_details` VALUES ('500','89','6','58','80','0.00','155.00','0.00','2.00','13950.00','27900.00','10.00','25110.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','44','2026-01-14','90');
INSERT INTO `sale_invoice_details` VALUES ('501','89','2','57','79','0.00','170.00','0.00','2.00','16320.00','32640.00','10.00','29376.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','44','2026-01-14','96');
INSERT INTO `sale_invoice_details` VALUES ('505','90','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-18 19:40:34','2026-01-18 19:40:34','1','56','2026-01-13','180');
INSERT INTO `sale_invoice_details` VALUES ('506','90','1','58','80','0.00','155.00','0.00','1.00','13950.00','13950.00','10.00','12555.00','2026-01-18 19:40:34','2026-01-18 19:40:34','1','56','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('507','90','1','59','123','0.00','165.00','0.00','1.00','14850.00','14850.00','10.00','13365.00','2026-01-18 19:40:34','2026-01-18 19:40:34','1','56','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('508','91','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-18 19:46:19','2026-01-18 19:46:19','1','83','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('509','91','6','67','89','90.00','59.00','5310.00','0.00','17700.00','0.00','10.00','4779.00','2026-01-18 19:46:19','2026-01-18 19:46:19','1','83','2026-01-13','300');
INSERT INTO `sale_invoice_details` VALUES ('510','91','6','68','90','90.00','83.00','7470.00','0.00','15936.00','0.00','10.00','6723.00','2026-01-18 19:46:19','2026-01-18 19:46:19','1','83','2026-01-13','192');
INSERT INTO `sale_invoice_details` VALUES ('511','91','6','69','91','90.00','116.00','10440.00','0.00','16704.00','0.00','10.00','9396.00','2026-01-18 19:46:19','2026-01-18 19:46:19','1','83','2026-01-13','144');
INSERT INTO `sale_invoice_details` VALUES ('512','92','6','66','88','84.00','39.00','3276.00','0.00','14040.00','0.00','10.00','2948.40','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','360');
INSERT INTO `sale_invoice_details` VALUES ('513','92','6','67','89','96.00','59.00','5664.00','0.00','17700.00','0.00','10.00','5097.60','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','300');
INSERT INTO `sale_invoice_details` VALUES ('514','92','6','68','90','96.00','83.00','7968.00','0.00','15936.00','0.00','10.00','7171.20','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','192');
INSERT INTO `sale_invoice_details` VALUES ('515','92','6','69','91','72.00','116.00','8352.00','0.00','16704.00','0.00','10.00','7516.80','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','144');
INSERT INTO `sale_invoice_details` VALUES ('516','92','6','70','92','60.00','158.00','9480.00','0.00','14220.00','0.00','10.00','8532.00','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('517','92','1','71','93','48.00','237.00','11376.00','0.00','17064.00','0.00','10.00','10238.40','2026-01-18 19:53:59','2026-01-18 19:53:59','1','79','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('520','93','2','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-18 20:01:27','2026-01-18 20:01:27','1','76','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('521','93','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-18 20:01:27','2026-01-18 20:01:27','1','76','2026-01-18','60');
INSERT INTO `sale_invoice_details` VALUES ('522','94','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','68','2026-01-13','30');
INSERT INTO `sale_invoice_details` VALUES ('523','94','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','68','2026-01-13','99');
INSERT INTO `sale_invoice_details` VALUES ('524','94','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','68','2026-01-13','100');
INSERT INTO `sale_invoice_details` VALUES ('525','94','1','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','68','2026-01-13','64');
INSERT INTO `sale_invoice_details` VALUES ('526','94','2','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','68','2026-01-13','100');
INSERT INTO `sale_invoice_details` VALUES ('527','95','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-18 20:09:22','2026-01-18 20:09:22','1','64','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('529','96','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-18 20:11:22','2026-01-18 20:11:22','1','45','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('530','96','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-18 20:11:22','2026-01-18 20:11:22','1','45','2026-01-13','64');
INSERT INTO `sale_invoice_details` VALUES ('539','8','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-03','64');
INSERT INTO `sale_invoice_details` VALUES ('540','8','6','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-03','30');
INSERT INTO `sale_invoice_details` VALUES ('541','8','6','42','64','0.00','470.00','0.00','1.00','16450.00','16450.00','10.00','14805.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-03','35');
INSERT INTO `sale_invoice_details` VALUES ('542','8','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('543','8','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('544','8','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','65','2026-01-04','30');
INSERT INTO `sale_invoice_details` VALUES ('545','98','6','94','120','0.00','160.00','0.00','5.00','8000.00','40000.00','10.00','36000.00','2026-01-18 20:23:52','2026-01-18 20:23:52','1','65','2026-01-13','50');
INSERT INTO `sale_invoice_details` VALUES ('546','98','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-18 20:23:52','2026-01-18 20:23:52','1','65','2026-01-13','100');
INSERT INTO `sale_invoice_details` VALUES ('547','98','2','93','119','0.00','130.00','0.00','1.00','7800.00','7800.00','10.00','7020.00','2026-01-18 20:23:52','2026-01-18 20:23:52','1','65','2026-01-13','60');
INSERT INTO `sale_invoice_details` VALUES ('548','99','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-13','30');
INSERT INTO `sale_invoice_details` VALUES ('549','99','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-13','35');
INSERT INTO `sale_invoice_details` VALUES ('550','99','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-13','50');
INSERT INTO `sale_invoice_details` VALUES ('551','99','2','90','116','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-15','100');
INSERT INTO `sale_invoice_details` VALUES ('552','99','2','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-15','70');
INSERT INTO `sale_invoice_details` VALUES ('553','99','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-15','72');
INSERT INTO `sale_invoice_details` VALUES ('554','99','2','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-18','100');
INSERT INTO `sale_invoice_details` VALUES ('555','99','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','60','2026-01-18','99');
INSERT INTO `sale_invoice_details` VALUES ('579','101','6','88','114','0.00','85.00','0.00','3.00','8415.00','25245.00','0.00','25245.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','99');
INSERT INTO `sale_invoice_details` VALUES ('580','101','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','60');
INSERT INTO `sale_invoice_details` VALUES ('581','101','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','64');
INSERT INTO `sale_invoice_details` VALUES ('582','101','6','89','115','0.00','160.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','60');
INSERT INTO `sale_invoice_details` VALUES ('583','101','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','100');
INSERT INTO `sale_invoice_details` VALUES ('584','101','1','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','192');
INSERT INTO `sale_invoice_details` VALUES ('585','101','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','144');
INSERT INTO `sale_invoice_details` VALUES ('586','101','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','90');
INSERT INTO `sale_invoice_details` VALUES ('587','101','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('588','101','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-18 20:55:58','2026-01-18 20:55:58','1','78','2026-01-13','180');
INSERT INTO `sale_invoice_details` VALUES ('597','102','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-13','72');
INSERT INTO `sale_invoice_details` VALUES ('598','102','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-13','60');
INSERT INTO `sale_invoice_details` VALUES ('599','102','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-13','64');
INSERT INTO `sale_invoice_details` VALUES ('600','102','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-13','60');
INSERT INTO `sale_invoice_details` VALUES ('601','102','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-13','40');
INSERT INTO `sale_invoice_details` VALUES ('602','102','1','51','73','0.00','175.00','0.00','5.00','10500.00','52500.00','10.00','47250.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-17','60');
INSERT INTO `sale_invoice_details` VALUES ('603','102','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-17','72');
INSERT INTO `sale_invoice_details` VALUES ('604','102','1','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-18 23:39:12','2026-01-18 23:39:12','1','55','2026-01-17','40');
INSERT INTO `sale_invoice_details` VALUES ('605','83','6','87','113','0.00','75.00','0.00','4.00','7500.00','30000.00','0.00','30000.00','2026-01-18 23:40:13','2026-01-18 23:40:13','1','63','2026-01-12','100');
INSERT INTO `sale_invoice_details` VALUES ('606','83','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-18 23:40:13','2026-01-18 23:40:13','1','63','2026-01-12','50');
INSERT INTO `sale_invoice_details` VALUES ('607','83','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-18 23:40:13','2026-01-18 23:40:13','1','63','2026-01-14','90');
INSERT INTO `sale_invoice_details` VALUES ('608','83','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-18 23:40:13','2026-01-18 23:40:13','1','63','2026-01-18','72');
INSERT INTO `sale_invoice_details` VALUES ('609','103','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-18 23:46:13','2026-01-18 23:46:13','1','46','2026-01-14','35');
INSERT INTO `sale_invoice_details` VALUES ('610','103','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-18 23:46:13','2026-01-18 23:46:13','1','46','2026-01-17','40');
INSERT INTO `sale_invoice_details` VALUES ('611','103','2','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-18 23:46:13','2026-01-18 23:46:13','1','46','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('612','103','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-18 23:46:13','2026-01-18 23:46:13','1','46','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('613','103','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-18 23:46:13','2026-01-18 23:46:13','1','46','2026-01-18','50');
INSERT INTO `sale_invoice_details` VALUES ('614','104','6','71','93','0.00','237.00','0.00','3.00','17064.00','51192.00','10.00','46072.80','2026-01-18 23:50:34','2026-01-18 23:50:34','1','58','2026-01-14','72');
INSERT INTO `sale_invoice_details` VALUES ('615','104','2','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-18 23:50:34','2026-01-18 23:50:34','1','58','2026-01-14','90');
INSERT INTO `sale_invoice_details` VALUES ('616','104','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-18 23:50:34','2026-01-18 23:50:34','1','58','2026-01-14','64');
INSERT INTO `sale_invoice_details` VALUES ('617','104','6','71','93','0.00','237.00','0.00','2.00','17064.00','34128.00','10.00','30715.20','2026-01-18 23:50:34','2026-01-18 23:50:34','1','58','2026-01-15','72');
INSERT INTO `sale_invoice_details` VALUES ('618','105','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-18 23:54:17','2026-01-18 23:54:17','1','47','2026-01-14','100');
INSERT INTO `sale_invoice_details` VALUES ('619','105','6','88','114','0.00','85.00','0.00','3.00','8415.00','25245.00','0.00','25245.00','2026-01-18 23:54:17','2026-01-18 23:54:17','1','47','2026-01-14','99');
INSERT INTO `sale_invoice_details` VALUES ('620','106','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-18 23:58:30','2026-01-18 23:58:30','1','72','2026-01-15','50');
INSERT INTO `sale_invoice_details` VALUES ('621','107','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-19 00:01:03','2026-01-19 00:01:03','1','12','2026-01-15','90');
INSERT INTO `sale_invoice_details` VALUES ('622','107','2','41','63','0.00','390.00','0.00','1.00','11700.00','11700.00','10.00','10530.00','2026-01-19 00:01:03','2026-01-19 00:01:03','1','12','2026-01-15','30');
INSERT INTO `sale_invoice_details` VALUES ('623','107','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-19 00:01:03','2026-01-19 00:01:03','1','12','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('624','108','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-19 00:04:57','2026-01-19 00:04:57','1','49','2026-01-15','90');
INSERT INTO `sale_invoice_details` VALUES ('627','110','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-19 00:13:23','2026-01-19 00:13:23','1','42','2026-01-17','60');
INSERT INTO `sale_invoice_details` VALUES ('628','111','6','94','120','144.00','100.00','14400.00','0.00','8000.00','0.00','0.00','14400.00','2026-01-19 00:19:07','2026-01-19 00:19:07','1','67','2026-01-17','50');
INSERT INTO `sale_invoice_details` VALUES ('629','111','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-19 00:19:07','2026-01-19 00:19:07','1','67','2026-01-17','99');
INSERT INTO `sale_invoice_details` VALUES ('630','112','1','46','68','0.00','510.00','0.00','2.00','15300.00','30600.00','10.00','27540.00','2026-01-19 00:21:38','2026-01-19 00:21:38','1','114','2026-01-17','30');
INSERT INTO `sale_invoice_details` VALUES ('631','112','1','47','69','0.00','312.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-19 00:21:38','2026-01-19 00:21:38','1','114','2026-01-17','30');
INSERT INTO `sale_invoice_details` VALUES ('632','112','6','61','83','0.00','260.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-19 00:21:38','2026-01-19 00:21:38','1','114','2026-01-17','36');
INSERT INTO `sale_invoice_details` VALUES ('633','112','2','93','119','0.00','130.00','0.00','2.00','7800.00','15600.00','10.00','14040.00','2026-01-19 00:21:38','2026-01-19 00:21:38','1','114','2026-01-17','60');
INSERT INTO `sale_invoice_details` VALUES ('638','109','1','80','106','0.00','125.00','0.00','5.00','11250.00','56250.00','0.00','56250.00','2026-01-19 00:29:31','2026-01-19 00:29:31','1','66','2026-01-15','90');
INSERT INTO `sale_invoice_details` VALUES ('639','109','6','88','114','0.00','80.00','0.00','12.00','7920.00','95040.00','0.00','95040.00','2026-01-19 00:29:31','2026-01-19 00:29:31','1','66','2026-01-15','99');
INSERT INTO `sale_invoice_details` VALUES ('643','73','1','51','73','0.00','175.00','0.00','1.00','10500.00','10500.00','10.00','9450.00','2026-01-19 19:58:29','2026-01-19 19:58:29','1','23','2026-01-12','60');
INSERT INTO `sale_invoice_details` VALUES ('644','73','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-19 19:58:29','2026-01-19 19:58:29','1','23','2026-01-12','40');
INSERT INTO `sale_invoice_details` VALUES ('645','73','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-19 19:58:29','2026-01-19 19:58:29','1','23','2026-01-14','90');
INSERT INTO `sale_invoice_details` VALUES ('646','113','2','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-19 20:17:49','2026-01-19 20:17:49','1','115','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('647','113','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-19 20:17:49','2026-01-19 20:17:49','1','115','2026-01-18','64');
INSERT INTO `sale_invoice_details` VALUES ('655','115','6','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-21 19:15:20','2026-01-21 19:15:20','1','23','2026-01-19','100');
INSERT INTO `sale_invoice_details` VALUES ('656','115','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-21 19:15:20','2026-01-21 19:15:20','1','23','2026-01-20','40');
INSERT INTO `sale_invoice_details` VALUES ('657','116','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-21 19:24:42','2026-01-21 19:24:42','1','100','2026-01-18','72');
INSERT INTO `sale_invoice_details` VALUES ('658','116','2','21','43','0.00','200.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-21 19:24:42','2026-01-21 19:24:42','1','100','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('659','116','1','57','79','0.00','170.00','0.00','1.00','16320.00','16320.00','10.00','14688.00','2026-01-21 19:24:42','2026-01-21 19:24:42','1','100','2026-01-18','96');
INSERT INTO `sale_invoice_details` VALUES ('660','116','1','59','123','0.00','165.00','0.00','1.00','14850.00','14850.00','10.00','13365.00','2026-01-21 19:24:42','2026-01-21 19:24:42','1','100','2026-01-18','90');
INSERT INTO `sale_invoice_details` VALUES ('661','114','2','24','46','0.00','175.00','0.00','3.00','7000.00','21000.00','10.00','18900.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('662','114','2','28','50','0.00','235.00','0.00','2.00','8225.00','16450.00','10.00','14805.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','35');
INSERT INTO `sale_invoice_details` VALUES ('663','114','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','64');
INSERT INTO `sale_invoice_details` VALUES ('664','114','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','60');
INSERT INTO `sale_invoice_details` VALUES ('665','114','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','60');
INSERT INTO `sale_invoice_details` VALUES ('666','114','1','94','120','0.00','160.00','0.00','3.00','8000.00','24000.00','10.00','21600.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','50');
INSERT INTO `sale_invoice_details` VALUES ('667','114','6','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','10.00','9450.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-15','70');
INSERT INTO `sale_invoice_details` VALUES ('668','114','6','90','116','0.00','75.00','0.00','10.00','7500.00','75000.00','0.00','75000.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-18','100');
INSERT INTO `sale_invoice_details` VALUES ('669','114','6','88','114','0.00','85.00','0.00','5.00','8415.00','42075.00','0.00','42075.00','2026-01-21 19:26:36','2026-01-21 19:26:36','1','21','2026-01-18','99');
INSERT INTO `sale_invoice_details` VALUES ('670','117','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-21 19:29:51','2026-01-21 19:29:51','1','19','2026-01-15','108');
INSERT INTO `sale_invoice_details` VALUES ('671','117','2','21','43','0.00','200.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-21 19:29:51','2026-01-21 19:29:51','1','19','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('672','118','1','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-21 19:31:14','2026-01-21 19:31:14','1','18','2026-01-15','180');
INSERT INTO `sale_invoice_details` VALUES ('673','118','1','51','73','0.00','175.00','0.00','1.00','10500.00','10500.00','10.00','9450.00','2026-01-21 19:31:14','2026-01-21 19:31:14','1','18','2026-01-15','60');
INSERT INTO `sale_invoice_details` VALUES ('674','119','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-21 19:32:24','2026-01-21 19:32:24','1','27','2026-01-21','90');
INSERT INTO `sale_invoice_details` VALUES ('675','120','6','87','113','0.00','75.00','0.00','5.00','7500.00','37500.00','0.00','37500.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','100');
INSERT INTO `sale_invoice_details` VALUES ('676','120','6','88','114','0.00','85.00','0.00','5.00','8415.00','42075.00','0.00','42075.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','99');
INSERT INTO `sale_invoice_details` VALUES ('677','120','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','72');
INSERT INTO `sale_invoice_details` VALUES ('678','120','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('679','120','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','35');
INSERT INTO `sale_invoice_details` VALUES ('680','120','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','40');
INSERT INTO `sale_invoice_details` VALUES ('681','120','6','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','30');
INSERT INTO `sale_invoice_details` VALUES ('682','120','2','34','56','0.00','320.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','30');
INSERT INTO `sale_invoice_details` VALUES ('683','120','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','30');
INSERT INTO `sale_invoice_details` VALUES ('684','120','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','30');
INSERT INTO `sale_invoice_details` VALUES ('685','120','2','95','121','0.00','65.00','0.00','2.00','11700.00','23400.00','0.00','23400.00','2026-01-21 19:41:10','2026-01-21 19:41:10','1','22','2026-01-15','180');
INSERT INTO `sale_invoice_details` VALUES ('686','121','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','30');
INSERT INTO `sale_invoice_details` VALUES ('687','121','2','41','63','0.00','390.00','0.00','1.00','11700.00','11700.00','10.00','10530.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','30');
INSERT INTO `sale_invoice_details` VALUES ('688','121','2','27','49','0.00','410.00','0.00','2.00','14350.00','28700.00','10.00','25830.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','35');
INSERT INTO `sale_invoice_details` VALUES ('689','121','2','29','51','0.00','255.00','0.00','2.00','8925.00','17850.00','10.00','16065.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','35');
INSERT INTO `sale_invoice_details` VALUES ('690','121','2','23','45','0.00','325.00','0.00','2.00','13000.00','26000.00','10.00','23400.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('691','121','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('692','121','2','19','41','0.00','238.00','0.00','2.00','9520.00','19040.00','10.00','17136.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('693','121','1','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','40');
INSERT INTO `sale_invoice_details` VALUES ('694','121','1','13','37','0.00','185.00','0.00','2.00','13320.00','26640.00','10.00','23976.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','72');
INSERT INTO `sale_invoice_details` VALUES ('695','121','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','72');
INSERT INTO `sale_invoice_details` VALUES ('696','121','2','93','119','0.00','130.00','0.00','1.00','7800.00','7800.00','10.00','7020.00','2026-01-21 19:54:32','2026-01-21 19:54:32','1','36','2026-01-18','60');
INSERT INTO `sale_invoice_details` VALUES ('709','32','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','7.00','25110.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','90');
INSERT INTO `sale_invoice_details` VALUES ('710','32','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','64');
INSERT INTO `sale_invoice_details` VALUES ('711','32','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('712','32','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','7.00','13020.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('713','32','6','94','120','0.00','145.00','0.00','2.00','7250.00','14500.00','0.00','14500.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','50');
INSERT INTO `sale_invoice_details` VALUES ('714','32','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','7.00','8091.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','111','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('715','122','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','64');
INSERT INTO `sale_invoice_details` VALUES ('716','122','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','60');
INSERT INTO `sale_invoice_details` VALUES ('717','122','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','7.00','13020.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','40');
INSERT INTO `sale_invoice_details` VALUES ('718','122','6','94','120','0.00','145.00','0.00','2.00','7250.00','14500.00','0.00','14500.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','50');
INSERT INTO `sale_invoice_details` VALUES ('719','122','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','7.00','8091.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','60');
INSERT INTO `sale_invoice_details` VALUES ('720','122','2','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','7.00','25110.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','111','2026-01-21','90');
INSERT INTO `sale_invoice_details` VALUES ('721','123','1','11','35','0.00','83.00','0.00','2.00','8964.00','17928.00','0.00','17928.00','2026-01-23 17:07:44','2026-01-23 17:07:44','1','140','2026-01-23','108');
INSERT INTO `sale_invoice_details` VALUES ('722','22','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-24 12:21:42','2026-01-24 12:21:42','1','17','2026-01-07 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('730','124','2','34','56','0.00','320.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-19 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('731','124','2','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('732','124','2','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('733','124','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('734','124','2','34','56','0.00','320.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('735','124','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('736','124','6','88','114','0.00','85.00','0.00','3.00','8415.00','25245.00','0.00','25245.00','2026-01-24 15:56:29','2026-01-24 15:56:29','1','46','2026-01-20 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('737','125','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-24 16:04:11','2026-01-24 16:04:11','1','70','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('738','125','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-24 16:04:11','2026-01-24 16:04:11','1','70','2026-01-19 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('741','126','6','87','113','0.00','75.00','0.00','5.00','7500.00','37500.00','0.00','37500.00','2026-01-24 16:10:12','2026-01-24 16:10:12','1','61','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('742','126','6','88','114','0.00','85.00','0.00','5.00','8415.00','42075.00','0.00','42075.00','2026-01-24 16:10:12','2026-01-24 16:10:12','1','61','2026-01-19 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('751','127','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('752','127','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('753','127','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('754','127','6','89','115','0.00','160.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('755','127','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('756','127','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('757','127','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','10.00','10530.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-19 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('758','127','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-21 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('759','127','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-24 16:16:50','2026-01-24 16:16:50','1','42','2026-01-21 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('767','129','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-24 16:25:39','2026-01-24 16:25:39','1','44','2026-01-19 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('772','130','2','39','61','0.00','560.00','0.00','2.00','16800.00','33600.00','10.00','30240.00','2026-01-24 16:28:30','2026-01-24 16:28:30','1','72','2026-01-19 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('773','130','1','27','49','0.00','410.00','0.00','2.00','14350.00','28700.00','10.00','25830.00','2026-01-24 16:28:30','2026-01-24 16:28:30','1','72','2026-01-19 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('774','130','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-24 16:28:30','2026-01-24 16:28:30','1','72','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('775','130','6','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-24 16:28:30','2026-01-24 16:28:30','1','72','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('776','131','6','87','113','0.00','75.00','0.00','10.00','7500.00','75000.00','0.00','75000.00','2026-01-25 15:34:40','2026-01-25 15:34:40','1','50','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('777','131','6','88','114','0.00','85.00','0.00','5.00','8415.00','42075.00','0.00','42075.00','2026-01-25 15:34:40','2026-01-25 15:34:40','1','50','2026-01-19 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('778','132','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-25 15:37:14','2026-01-25 15:37:14','1','58','2026-01-19 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('779','132','6','71','93','0.00','237.00','0.00','2.00','17064.00','34128.00','10.00','30715.20','2026-01-25 15:37:14','2026-01-25 15:37:14','1','58','2026-01-19 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('780','132','6','71','93','0.00','237.00','0.00','3.00','17064.00','51192.00','10.00','46072.80','2026-01-25 15:37:14','2026-01-25 15:37:14','1','58','2026-01-19 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('781','133','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-25 15:41:55','2026-01-25 15:41:55','1','51','2026-01-19 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('782','133','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 15:41:55','2026-01-25 15:41:55','1','51','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('783','133','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-25 15:41:55','2026-01-25 15:41:55','1','51','2026-01-21 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('784','134','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-25 15:46:02','2026-01-25 15:46:02','1','67','2026-01-19 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('785','135','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 15:48:44','2026-01-25 15:48:44','1','53','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('786','136','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-25 15:56:08','2026-01-25 15:56:08','1','64','2026-01-25 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('787','137','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-25 16:04:08','2026-01-25 16:04:08','1','76','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('788','137','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-25 16:04:08','2026-01-25 16:04:08','1','76','2026-01-20 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('789','137','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 16:04:08','2026-01-25 16:04:08','1','76','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('790','138','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 16:06:47','2026-01-25 16:06:47','1','83','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('791','139','6','65','87','0.00','300.00','0.00','2.00','10800.00','21600.00','10.00','19440.00','2026-01-25 16:19:42','2026-01-25 16:19:42','1','47','2026-01-20 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('792','139','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-25 16:19:42','2026-01-25 16:19:42','1','47','2026-01-20 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('793','139','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-25 16:19:42','2026-01-25 16:19:42','1','47','2026-01-20 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('794','140','1','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-25 16:26:18','2026-01-25 16:26:18','1','68','2026-01-20 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('795','140','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-25 16:26:18','2026-01-25 16:26:18','1','68','2026-01-20 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('796','141','6','81','107','0.00','145.00','0.00','5.00','8700.00','43500.00','10.00','39150.00','2026-01-25 16:32:23','2026-01-25 16:32:23','1','49','2026-01-20 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('797','141','2','80','106','0.00','150.00','0.00','3.00','13500.00','40500.00','10.00','36450.00','2026-01-25 16:32:23','2026-01-25 16:32:23','1','49','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('798','141','2','79','105','0.00','150.00','0.00','5.00','9600.00','48000.00','10.00','43200.00','2026-01-25 16:32:23','2026-01-25 16:32:23','1','49','2026-01-20 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('799','141','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 16:32:23','2026-01-25 16:32:23','1','49','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('800','142','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('801','142','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('802','142','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('803','142','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('804','142','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('805','142','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','45','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('806','143','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 16:36:56','2026-01-25 16:36:56','1','134','2026-01-20 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('807','144','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('808','144','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('809','144','1','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','70');
INSERT INTO `sale_invoice_details` VALUES ('810','144','2','77','103','0.00','220.00','0.00','1.00','14080.00','14080.00','10.00','12672.00','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('811','144','1','76','102','0.00','220.00','0.00','1.00','13200.00','13200.00','10.00','11880.00','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('812','144','1','16','38','0.00','99.00','0.00','3.00','7128.00','21384.00','10.00','19245.60','2026-01-25 16:39:42','2026-01-25 16:39:42','1','60','2026-01-20 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('813','145','2','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','12','2026-01-21 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('814','145','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','12','2026-01-21 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('815','145','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','12','2026-01-21 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('816','145','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','12','2026-01-21 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('817','145','1','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','12','2026-01-21 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('818','146','1','83','109','0.00','80.00','0.00','20.00','5760.00','115200.00','0.00','115200.00','2026-01-25 16:46:23','2026-01-25 16:46:23','1','62','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('819','147','2','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('820','147','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('821','147','2','29','51','0.00','250.00','0.00','1.00','8750.00','8750.00','10.00','7875.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('822','147','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','10.00','9315.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('823','147','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('824','147','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('825','147','2','41','63','0.00','390.00','0.00','1.00','11700.00','11700.00','10.00','10530.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-22 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('826','147','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-25 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('827','147','2','29','51','0.00','250.00','0.00','1.00','8750.00','8750.00','10.00','7875.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-25 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('828','147','2','39','131','0.00','540.00','0.00','1.00','16200.00','16200.00','10.00','14580.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('829','147','2','80','106','0.00','145.00','0.00','1.00','13050.00','13050.00','10.00','11745.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-25 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('830','147','2','64','86','0.00','480.00','0.00','2.00','17280.00','34560.00','10.00','31104.00','2026-01-25 16:58:32','2026-01-25 16:58:32','1','12','2026-01-25 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('839','149','1','83','109','0.00','80.00','0.00','10.00','5760.00','57600.00','0.00','57600.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('840','149','2','70','92','0.00','155.00','0.00','1.00','13950.00','13950.00','10.00','12555.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('841','149','6','71','93','0.00','230.00','0.00','1.00','16560.00','16560.00','10.00','14904.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('842','149','1','77','103','0.00','220.00','0.00','1.00','14080.00','14080.00','10.00','12672.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('843','149','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('844','149','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('845','149','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','60','2026-01-24 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('853','151','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-25 17:11:05','2026-01-25 17:11:05','1','70','2026-01-24 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('854','152','1','83','109','0.00','80.00','0.00','30.00','5760.00','172800.00','0.00','172800.00','2026-01-25 17:12:38','2026-01-25 17:12:38','1','62','2026-01-24 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('855','153','2','41','63','0.00','390.00','0.00','1.00','11700.00','11700.00','10.00','10530.00','2026-01-25 17:13:35','2026-01-25 17:13:35','1','68','2026-01-24 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('856','153','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-25 17:13:35','2026-01-25 17:13:35','1','68','2026-01-24 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('857','154','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-25 17:15:38','2026-01-25 17:15:38','1','63','2026-01-24 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('858','154','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-25 17:15:38','2026-01-25 17:15:38','1','63','2026-01-24 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('859','155','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-25 17:23:06','2026-01-25 17:23:06','1','131','2026-01-25 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('860','155','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-25 17:23:06','2026-01-25 17:23:06','1','131','2026-01-22 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('872','157','2','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-25 17:30:27','2026-01-25 17:30:27','1','142','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('873','157','1','46','68','0.00','480.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-25 17:30:27','2026-01-25 17:30:27','1','142','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('874','157','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-25 17:30:27','2026-01-25 17:30:27','1','142','2026-01-25 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('875','157','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-25 17:30:27','2026-01-25 17:30:27','1','142','2026-01-25 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('876','158','6','89','115','0.00','130.00','0.00','3.00','7800.00','23400.00','0.00','23400.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-12 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('877','158','6','87','113','0.00','70.00','0.00','3.00','7000.00','21000.00','0.00','21000.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-14 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('878','158','6','79','105','0.00','120.00','0.00','5.00','7680.00','38400.00','0.00','38400.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-17 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('879','158','6','87','113','0.00','70.00','0.00','6.00','7000.00','42000.00','0.00','42000.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-24 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('880','158','6','88','114','0.00','80.00','0.00','6.00','7920.00','47520.00','0.00','47520.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-24 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('881','158','6','87','113','0.00','70.00','0.00','5.00','7000.00','35000.00','0.00','35000.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-25 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('882','158','6','88','114','0.00','80.00','0.00','5.00','7920.00','39600.00','0.00','39600.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','69','2026-01-25 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('883','156','2','80','106','0.00','145.00','0.00','2.00','13050.00','26100.00','7.00','24273.00','2026-01-25 18:49:20','2026-01-25 18:49:20','1','141','2026-01-25 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('884','150','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-25 22:40:08','2026-01-25 22:40:08','1','50','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('885','150','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-25 22:40:08','2026-01-25 22:40:08','1','50','2026-01-22 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('886','150','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-25 22:40:08','2026-01-25 22:40:08','1','50','2026-01-25 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('887','150','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-25 22:40:08','2026-01-25 22:40:08','1','50','2026-11-25 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('888','128','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-19 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('889','128','6','24','46','0.00','175.00','0.00','2.00','7000.00','14000.00','10.00','12600.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-19 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('890','128','6','65','87','0.00','300.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-19 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('891','128','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-19 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('892','128','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-19 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('893','128','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-21 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('894','128','2','36','58','16.00','445.00','7120.00','0.00','15575.00','0.00','10.00','6408.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-21 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('895','128','2','93','119','0.00','130.00','0.00','1.00','7800.00','7800.00','10.00','7020.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','65','2026-01-25 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('896','31','1','47','69','0.00','312.00','0.00','4.00','9360.00','37440.00','10.00','33696.00','2026-01-25 22:52:45','2026-01-25 22:52:45','1','87','2026-01-08 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('897','31','1','61','83','50.00','260.00','13000.00','0.00','9360.00','0.00','10.00','11700.00','2026-01-25 22:52:45','2026-01-25 22:52:45','1','87','2026-01-08 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('898','159','2','34','56','0.00','320.00','0.00','6.00','9600.00','57600.00','10.00','51840.00','2026-01-26 12:16:06','2026-01-26 12:16:06','1','59','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('899','159','6','94','120','0.00','160.00','0.00','3.00','8000.00','24000.00','10.00','21600.00','2026-01-26 12:16:06','2026-01-26 12:16:06','1','59','2026-01-25 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('900','159','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-26 12:16:06','2026-01-26 12:16:06','1','59','2026-01-25 00:00:00','64');
INSERT INTO `sale_invoice_details` VALUES ('902','160','6','66','136','36.00','37.00','1332.00','0.00','13320.00','0.00','10.00','1198.80','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','360');
INSERT INTO `sale_invoice_details` VALUES ('903','160','6','67','137','36.00','57.00','2052.00','0.00','17100.00','0.00','10.00','1846.80','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','300');
INSERT INTO `sale_invoice_details` VALUES ('904','160','6','68','138','36.00','79.00','2844.00','0.00','15168.00','0.00','10.00','2559.60','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','192');
INSERT INTO `sale_invoice_details` VALUES ('905','160','6','69','139','36.00','110.00','3960.00','0.00','15840.00','0.00','10.00','3564.00','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','144');
INSERT INTO `sale_invoice_details` VALUES ('906','160','6','70','140','36.00','150.00','5400.00','0.00','13500.00','0.00','10.00','4860.00','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('907','160','6','71','141','36.00','225.00','8100.00','0.00','16200.00','0.00','10.00','7290.00','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('908','160','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-26 19:54:25','2026-01-26 19:54:25','1','123','2026-01-26 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('909','161','6','16','38','0.00','85.00','0.00','1.00','6120.00','6120.00','0.00','6120.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-03 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('910','161','2','24','46','0.00','151.00','0.00','1.00','6040.00','6040.00','0.00','6040.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-03 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('911','161','2','28','50','0.00','200.00','0.00','1.00','7000.00','7000.00','0.00','7000.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-03 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('912','161','1','46','68','0.00','447.00','0.00','1.00','13410.00','13410.00','0.00','13410.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-03 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('913','161','1','47','69','0.00','275.00','0.00','1.00','8250.00','8250.00','0.00','8250.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-03 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('914','161','1','11','35','0.00','70.00','0.00','1.00','7560.00','7560.00','0.00','7560.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-06 00:00:00','108');
INSERT INTO `sale_invoice_details` VALUES ('915','161','1','16','38','0.00','85.00','0.00','1.00','6120.00','6120.00','0.00','6120.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-06 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('916','161','2','24','46','0.00','151.00','0.00','4.00','6040.00','24160.00','0.00','24160.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-06 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('917','161','2','34','56','0.00','269.00','0.00','2.00','8070.00','16140.00','0.00','16140.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-06 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('918','161','2','80','106','0.00','127.00','0.00','1.00','11430.00','11430.00','0.00','11430.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-08 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('919','161','1','47','69','0.00','275.00','0.00','1.00','8250.00','8250.00','0.00','8250.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('920','161','2','80','106','0.00','127.00','0.00','1.00','11430.00','11430.00','0.00','11430.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('921','161','2','25','47','0.00','229.00','0.00','1.00','9160.00','9160.00','0.00','9160.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('922','161','2','24','46','0.00','151.00','0.00','1.00','6040.00','6040.00','0.00','6040.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('923','161','1','17','39','0.00','124.00','0.00','1.00','8928.00','8928.00','0.00','8928.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('924','161','1','16','38','0.00','85.00','0.00','1.00','6120.00','6120.00','0.00','6120.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','81','2026-01-10 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('925','162','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('926','162','2','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('927','162','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('928','162','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('929','162','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('930','162','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','10.00','7573.50','2026-01-26 21:38:14','2026-01-26 21:38:14','1','143','2026-01-26 00:00:00','99');
INSERT INTO `sale_invoice_details` VALUES ('931','163','1','51','73','0.00','165.00','0.00','4.00','10500.00','42000.00','10.00','37800.00','2026-01-27 19:34:44','2026-01-27 19:34:44','1','87','2026-01-26 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('932','163','1','47','69','0.00','312.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-27 19:34:44','2026-01-27 19:34:44','1','87','2026-01-26 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('933','163','6','61','83','50.00','260.00','13000.00','0.00','9360.00','0.00','10.00','11700.00','2026-01-27 19:34:44','2026-01-27 19:34:44','1','87','2026-01-26 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('997','164','1','11','35','0.00','83.00','0.00','5.00','8964.00','44820.00','10.00','40338.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','108');
INSERT INTO `sale_invoice_details` VALUES ('998','164','1','16','38','0.00','99.00','0.00','10.00','7128.00','71280.00','10.00','64152.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('999','164','2','20','42','0.00','135.00','0.00','10.00','5400.00','54000.00','10.00','48600.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1000','164','2','24','46','0.00','175.00','0.00','8.00','7000.00','56000.00','10.00','50400.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1001','164','1','10','125','0.00','108.00','0.00','3.00','11664.00','34992.00','10.00','31492.80','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','108');
INSERT INTO `sale_invoice_details` VALUES ('1002','164','1','13','126','0.00','170.00','0.00','8.00','12240.00','97920.00','10.00','88128.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('1003','164','2','19','127','0.00','222.00','0.00','6.00','8880.00','53280.00','10.00','47952.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1004','164','2','23','128','0.00','300.00','0.00','6.00','12000.00','72000.00','10.00','64800.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1005','164','2','27','129','0.00','380.00','0.00','3.00','13300.00','39900.00','10.00','35910.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','35');
INSERT INTO `sale_invoice_details` VALUES ('1006','164','2','55','149','0.00','160.00','0.00','2.00','15360.00','30720.00','10.00','27648.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1007','164','2','57','150','0.00','165.00','0.00','2.00','15840.00','31680.00','10.00','28512.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1008','164','2','58','151','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1009','164','1','59','152','0.00','160.00','0.00','2.00','14400.00','28800.00','10.00','25920.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1010','164','1','46','143','0.00','480.00','0.00','15.00','14400.00','216000.00','10.00','194400.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1011','164','1','47','69','0.00','312.00','0.00','20.00','9360.00','187200.00','10.00','168480.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1012','164','1','48','145','0.00','68.00','0.00','5.00','13056.00','65280.00','10.00','58752.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','192');
INSERT INTO `sale_invoice_details` VALUES ('1013','164','6','63','85','0.00','140.00','0.00','2.00','16800.00','33600.00','10.00','30240.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','120');
INSERT INTO `sale_invoice_details` VALUES ('1014','164','6','62','','0.00','165.00','0.00','2.00','16500.00','33000.00','10.00','29700.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('1015','164','6','61','83','1000.00','260.00','260000.00','0.00','9360.00','0.00','10.00','234000.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('1016','164','6','65','87','0.00','300.00','0.00','10.00','10800.00','108000.00','10.00','97200.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('1017','164','6','64','','0.00','480.00','0.00','3.00','17280.00','51840.00','10.00','46656.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('1018','164','2','93','119','0.00','130.00','0.00','2.00','7800.00','15600.00','10.00','14040.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1019','164','1','51','146','0.00','165.00','0.00','15.00','9900.00','148500.00','10.00','133650.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1020','164','6','66','136','0.00','37.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','360');
INSERT INTO `sale_invoice_details` VALUES ('1021','164','6','67','137','0.00','57.00','0.00','1.00','17100.00','17100.00','10.00','15390.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','300');
INSERT INTO `sale_invoice_details` VALUES ('1022','164','6','68','138','0.00','79.00','0.00','1.00','15168.00','15168.00','10.00','13651.20','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','192');
INSERT INTO `sale_invoice_details` VALUES ('1023','164','2','69','139','0.00','110.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','144');
INSERT INTO `sale_invoice_details` VALUES ('1024','164','6','70','140','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1025','164','6','71','141','0.00','225.00','0.00','1.00','16200.00','16200.00','10.00','14580.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('1026','164','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('1027','164','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('1028','164','6','97','154','0.00','220.00','0.00','5.00','11000.00','55000.00','10.00','49500.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','88','2026-01-20 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('1029','165','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-28 13:02:52','2026-01-28 13:02:52','1','139','2026-01-28 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1030','165','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-28 13:02:52','2026-01-28 13:02:52','1','139','2026-01-28 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1035','166','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-28 19:48:50','2026-01-28 19:48:50','1','28','2026-01-22 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('1036','166','2','55','149','0.00','160.00','0.00','1.00','15360.00','15360.00','10.00','13824.00','2026-01-28 19:48:50','2026-01-28 19:48:50','1','28','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1037','166','2','57','150','0.00','165.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 19:48:50','2026-01-28 19:48:50','1','28','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1038','166','1','51','146','0.00','165.00','0.00','1.00','9900.00','9900.00','10.00','8910.00','2026-01-28 19:48:50','2026-01-28 19:48:50','1','28','2026-01-22 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1039','167','1','11','35','0.00','83.00','0.00','1.00','8964.00','8964.00','10.00','8067.60','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-22 00:00:00','108');
INSERT INTO `sale_invoice_details` VALUES ('1040','167','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1041','167','1','13','126','0.00','170.00','0.00','1.00','12240.00','12240.00','10.00','11016.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('1042','167','2','19','127','0.00','222.00','0.00','1.00','8880.00','8880.00','10.00','7992.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1043','167','2','23','128','0.00','300.00','0.00','1.00','12000.00','12000.00','10.00','10800.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1044','167','1','61','83','0.00','260.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('1045','167','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-28 20:06:51','2026-01-28 20:06:51','1','15','2026-01-25 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('1049','168','1','47','69','0.00','312.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-28 20:17:08','2026-01-28 20:17:08','1','29','2026-01-22 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1050','168','1','46','143','0.00','480.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:17:08','2026-01-28 20:17:08','1','29','2026-01-22 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1051','168','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-28 20:17:08','2026-01-28 20:17:08','1','29','2026-01-25 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1052','169','1','13','126','0.00','170.00','0.00','1.00','12240.00','12240.00','10.00','11016.00','2026-01-28 20:24:42','2026-01-28 20:24:42','1','24','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('1053','169','2','19','127','0.00','222.00','0.00','1.00','8880.00','8880.00','10.00','7992.00','2026-01-28 20:24:42','2026-01-28 20:24:42','1','24','2026-01-22 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1054','169','2','23','128','0.00','300.00','0.00','1.00','12000.00','12000.00','10.00','10800.00','2026-01-28 20:24:42','2026-01-28 20:24:42','1','24','2026-01-22 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1058','170','6','69','139','0.00','110.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 20:30:17','2026-01-28 20:30:17','1','18','2026-01-22 00:00:00','144');
INSERT INTO `sale_invoice_details` VALUES ('1059','170','6','70','140','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 20:30:17','2026-01-28 20:30:17','1','18','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1060','170','1','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:30:17','2026-01-28 20:30:17','1','18','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1061','171','1','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-28 20:33:03','2026-01-28 20:33:03','1','27','2026-01-22 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('1062','171','6','68','138','0.00','79.00','0.00','1.00','15168.00','15168.00','10.00','13651.20','2026-01-28 20:33:03','2026-01-28 20:33:03','1','27','2026-01-22 00:00:00','192');
INSERT INTO `sale_invoice_details` VALUES ('1063','171','2','96','122','0.00','75.00','0.00','1.00','5250.00','5250.00','0.00','5250.00','2026-01-28 20:33:03','2026-01-28 20:33:03','1','27','2026-01-22 00:00:00','70');
INSERT INTO `sale_invoice_details` VALUES ('1064','171','1','51','146','0.00','165.00','0.00','1.00','9900.00','9900.00','10.00','8910.00','2026-01-28 20:33:03','2026-01-28 20:33:03','1','27','2026-01-28 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1065','171','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-28 20:33:03','2026-01-28 20:33:03','1','27','2026-01-22 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('1070','172','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-28 20:43:35','2026-01-28 20:43:35','1','38','2026-01-28 00:00:00','180');
INSERT INTO `sale_invoice_details` VALUES ('1071','172','1','57','150','0.00','165.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 20:43:35','2026-01-28 20:43:35','1','38','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1072','172','1','55','149','0.00','160.00','0.00','1.00','15360.00','15360.00','10.00','13824.00','2026-01-28 20:43:35','2026-01-28 20:43:35','1','38','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1073','172','2','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:43:35','2026-01-28 20:43:35','1','38','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1074','173','1','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:45:11','2026-01-28 20:45:11','1','25','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1075','174','1','55','149','0.00','160.00','0.00','1.00','15360.00','15360.00','10.00','13824.00','2026-01-28 20:52:54','2026-01-28 20:52:54','1','31','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1076','174','1','57','150','0.00','165.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 20:52:54','2026-01-28 20:52:54','1','31','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1077','174','1','58','151','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 20:52:54','2026-01-28 20:52:54','1','31','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1078','174','1','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:52:54','2026-01-28 20:52:54','1','31','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1079','174','2','23','128','0.00','300.00','0.00','1.00','12000.00','12000.00','10.00','10800.00','2026-01-28 20:52:54','2026-01-28 20:52:54','1','31','2026-01-22 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1080','175','1','55','149','0.00','160.00','0.00','1.00','15360.00','15360.00','10.00','13824.00','2026-01-28 20:57:31','2026-01-28 20:57:31','1','35','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1081','175','1','57','150','0.00','165.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 20:57:31','2026-01-28 20:57:31','1','35','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1082','175','1','58','151','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 20:57:31','2026-01-28 20:57:31','1','35','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1083','175','1','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 20:57:31','2026-01-28 20:57:31','1','35','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1084','176','1','57','150','0.00','165.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 21:00:45','2026-01-28 21:00:45','1','21','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1085','176','1','55','149','0.00','160.00','0.00','1.00','15360.00','15360.00','10.00','13824.00','2026-01-28 21:00:45','2026-01-28 21:00:45','1','21','2026-01-22 00:00:00','96');
INSERT INTO `sale_invoice_details` VALUES ('1086','176','1','59','152','0.00','160.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 21:00:45','2026-01-28 21:00:45','1','21','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1087','176','1','96','122','0.00','75.00','0.00','5.00','5250.00','26250.00','0.00','26250.00','2026-01-28 21:00:45','2026-01-28 21:00:45','1','21','2026-01-22 00:00:00','70');
INSERT INTO `sale_invoice_details` VALUES ('1088','176','1','83','109','0.00','80.00','0.00','10.00','5760.00','57600.00','0.00','57600.00','2026-01-28 21:00:45','2026-01-28 21:00:45','1','21','2026-01-22 00:00:00','72');
INSERT INTO `sale_invoice_details` VALUES ('1089','177','1','51','146','0.00','165.00','0.00','1.00','9900.00','9900.00','10.00','8910.00','2026-01-28 21:04:28','2026-01-28 21:04:28','1','17','2026-01-22 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1090','177','1','68','138','0.00','79.00','0.00','1.00','15168.00','15168.00','10.00','13651.20','2026-01-28 21:04:28','2026-01-28 21:04:28','1','17','2026-01-22 00:00:00','192');
INSERT INTO `sale_invoice_details` VALUES ('1091','177','1','69','139','0.00','110.00','0.00','1.00','15840.00','15840.00','10.00','14256.00','2026-01-28 21:04:28','2026-01-28 21:04:28','1','17','2026-01-22 00:00:00','144');
INSERT INTO `sale_invoice_details` VALUES ('1092','177','6','70','140','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 21:04:28','2026-01-28 21:04:28','1','17','2026-01-22 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1093','178','1','51','146','0.00','165.00','0.00','2.00','9900.00','19800.00','10.00','17820.00','2026-01-28 21:06:53','2026-01-28 21:06:53','1','23','2026-01-25 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1094','179','1','51','146','0.00','165.00','0.00','1.00','9900.00','9900.00','10.00','8910.00','2026-01-28 21:10:25','2026-01-28 21:10:25','1','16','2026-01-25 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1098','181','1','73','99','0.00','340.00','0.00','1.00','12240.00','12240.00','10.00','11016.00','2026-01-28 21:33:54','2026-01-28 21:33:54','1','131','2026-01-27 00:00:00','36');
INSERT INTO `sale_invoice_details` VALUES ('1099','181','2','85','153','0.00','80.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-28 21:33:54','2026-01-28 21:33:54','1','131','2026-01-27 00:00:00','100');
INSERT INTO `sale_invoice_details` VALUES ('1100','181','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-28 21:33:54','2026-01-28 21:33:54','1','131','2026-01-27 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1101','181','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 21:33:54','2026-01-28 21:33:54','1','131','2026-01-27 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1102','182','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-28 21:36:15','2026-01-28 21:36:15','1','117','2026-01-27 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1103','182','1','46','143','0.00','480.00','0.00','1.00','14400.00','14400.00','10.00','12960.00','2026-01-28 21:36:15','2026-01-28 21:36:15','1','117','2026-01-27 00:00:00','30');
INSERT INTO `sale_invoice_details` VALUES ('1104','182','6','67','137','0.00','57.00','0.00','1.00','17100.00','17100.00','10.00','15390.00','2026-01-28 21:36:15','2026-01-28 21:36:15','1','117','2026-01-27 00:00:00','300');
INSERT INTO `sale_invoice_details` VALUES ('1105','180','1','51','146','0.00','165.00','0.00','2.00','9900.00','19800.00','10.00','17820.00','2026-01-28 21:40:38','2026-01-28 21:40:38','1','100','2026-01-25 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1106','180','2','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-28 21:40:38','2026-01-28 21:40:38','1','100','2026-01-25 00:00:00','90');
INSERT INTO `sale_invoice_details` VALUES ('1107','180','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-28 21:40:38','2026-01-28 21:40:38','1','100','2026-01-25 00:00:00','60');
INSERT INTO `sale_invoice_details` VALUES ('1108','29','2','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-28 21:45:35','2026-01-28 21:45:35','1','96','2026-01-06 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1109','183','2','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-28 21:49:57','2026-01-28 21:49:57','1','96','2026-01-13 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1110','183','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-28 21:49:57','2026-01-28 21:49:57','1','96','2026-01-13 00:00:00','50');
INSERT INTO `sale_invoice_details` VALUES ('1111','184','2','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-28 21:51:48','2026-01-28 21:51:48','1','96','2026-01-27 00:00:00','40');
INSERT INTO `sale_invoice_details` VALUES ('1112','184','6','94','120','0.00','160.00','0.00','5.00','8000.00','40000.00','10.00','36000.00','2026-01-28 21:51:48','2026-01-28 21:51:48','1','96','2026-01-27 00:00:00','50');


DROP TABLE IF EXISTS `sale_invoices_masters`;
CREATE TABLE `sale_invoices_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) DEFAULT NULL,
  `grand_crt_total` decimal(16,2) DEFAULT NULL,
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_balance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_amount` decimal(16,2) DEFAULT NULL,
  `received_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoices_masters` VALUES ('26','1','2025-10-28','11','','','','0.00','260000.00','2025-10-28 19:43:09','2025-11-05 02:02:24','7','0','1000','','');
INSERT INTO `sale_invoices_masters` VALUES ('33','2','2025-11-05','11','','','','0.00','202000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','261000','2000','','');
INSERT INTO `sale_invoices_masters` VALUES ('36','1','2025-11-10','13','red','','','0.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('41','3','2025-12-19','11','','','','','20000.00','2025-12-19 16:21:31','2025-12-19 16:21:31','7','463000','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('46','1','2026-01-03','92','','','','','19130.40','2026-01-03 16:53:15','2026-01-03 16:53:15','1','22106','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('47','2','2026-01-04','63','','','','','74760.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','114304','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('48','3','2026-01-04','42','','','','','7830.00','2026-01-04 16:52:31','2026-01-04 16:52:31','1','459343','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('49','4','2026-01-04','53','','','','','45900.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','605118','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('50','5','2026-01-04','51','','','','','18630.00','2026-01-04 17:02:32','2026-01-04 17:02:32','1','197168','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('51','6','2026-01-04','55','','','','','48600.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','85143','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('54','9','2026-01-04','47','','','','','12915.00','2026-01-04 17:29:31','2026-01-04 17:29:31','1','332903','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('55','10','2026-01-04','50','','','','','83785.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','156022','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('57','11','2026-01-04','60','','','','','7500.00','2026-01-04 20:20:53','2026-01-04 20:20:53','1','1072290','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('58','12','2026-01-04','78','','','','','15915.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','88668','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('63','14','2026-01-04','46','','','','0.38','69380.20','2026-01-04 20:55:13','2026-01-04 20:55:13','1','689487','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('64','13','2026-01-04','45','','','','0.00','6300.00','2026-01-04 20:57:12','2026-01-04 20:57:12','1','347332','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('68','16','2026-01-06','109','','','','2.00','32037.77','2026-01-06 19:41:52','2026-01-06 19:41:52','1','5612','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('69','15','2026-01-06','114','','','','0.00','16848.00','2026-01-06 19:58:41','2026-01-06 19:58:41','1','39600','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('72','17','2026-01-07','29','','','','2.00','19364.80','2026-01-07 19:00:24','2026-01-07 19:00:24','1','128670','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('73','18','2026-01-07','30','','','','2.00','16511.04','2026-01-07 19:09:15','2026-01-07 19:09:15','1','55','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('74','19','2026-01-01','100','','','','2.00','9261.00','2026-01-07 19:22:41','2026-01-07 19:22:41','1','71213','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('76','21','2026-01-07','25','','','','2.00','21242.09','2026-01-07 19:49:07','2026-01-07 19:49:07','1','110515','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('78','23','2026-01-07','19','','','','','9720.00','2026-01-07 20:03:38','2026-01-07 20:03:38','1','140979','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('79','24','2026-01-07','18','','','','','48423.60','2026-01-07 21:34:13','2026-01-07 21:34:13','1','154701','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('80','25','2026-01-01','31','','','','','8568.00','2026-01-07 21:37:45','2026-01-07 21:37:45','1','287647','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('82','26','2026-01-07','21','','','','2.00','70436.52','2026-01-07 21:41:45','2026-01-07 21:41:45','1','1453069','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('83','27','2026-01-07','16','','','','2.00','11907.00','2026-01-07 21:47:07','2026-01-07 21:47:07','1','31471','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('84','20','2026-01-07','15','','','','2.00','48866.33','2026-01-07 21:53:20','2026-01-07 21:53:20','1','469253','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('85','28','2026-01-07','101','','','','2.00','90681.95','2026-01-07 21:59:38','2026-01-07 21:59:38','1','141050','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('87','30','2026-01-07','110','','','','','111375.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('90','33','2026-01-03','134','','','','','15915.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('93','35','2026-01-11','72','','','','0.00','92475.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','137363','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('94','36','2026-01-11','44','','','','','21420.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','172654','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('95','37','2026-01-11','51','','','','','40500.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','175798','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('96','38','2026-01-11','134','','','','','58292.40','2026-01-11 21:31:39','2026-01-11 21:31:39','1','28638','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('98','39','2026-01-11','53','','','','0.00','165618.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','651018','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('100','41','2026-01-11','68','','','','','6300.00','2026-01-11 22:21:51','2026-01-11 22:21:51','1','90181','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('101','42','2026-01-11','50','','','','','66765.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','189807','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('102','43','2026-01-11','57','','','','','24300.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','41461','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('105','45','2026-01-11','65','','','','','157685.10','2026-01-11 22:51:27','2026-01-11 22:51:27','1','125582','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('106','46','2026-01-11','67','','','','','16830.00','2026-01-11 22:55:45','2026-01-11 22:55:45','1','39575','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('107','44','2026-01-11','63','','','','0.00','78210.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','129064','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('108','47','2026-01-11','47','','','','','43530.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','285818','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('109','48','2026-01-11','77','','','','','37665.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','33566','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('111','50','2026-01-11','82','','','','','40305.60','2026-01-11 23:23:47','2026-01-11 23:23:47','1','172039','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('112','51','2026-01-11','70','','','','','7500.00','2026-01-11 23:30:31','2026-01-11 23:30:31','1','43020','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('113','52','2026-01-11','136','','','','','24300.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('115','54','2026-01-11','59','','','','','157068.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','778626','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('116','55','2026-01-11','83','','','','','70842.60','2026-01-11 23:45:14','2026-01-11 23:45:14','1','176957','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('119','57','2026-01-11','78','','','','','17280.00','2026-01-11 23:54:27','2026-01-11 23:54:27','1','104583','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('123','59','2026-01-11','12','','','','0.00','44436.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','607451','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('124','60','2026-01-12','48','','','','','6415.20','2026-01-12 00:03:06','2026-01-12 00:03:06','1','82662','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('126','61','2026-01-12','52','','','','0.00','99360.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','67307','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('127','62','2026-01-12','45','Alam Chowk','','','','27382.50','2026-01-12 00:09:16','2026-01-12 00:09:16','1','313632','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('128','63','2026-01-12','42','','','','','78300.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','417173','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('129','64','2026-01-12','135','','','','','87000.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','46303','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('130','65','2026-01-11','69','','','','','105300.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','204100','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('131','40','2026-01-11','60','','','','0.00','308208.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','779790','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('132','49','2026-01-06','76','','','','0.00','141298.50','2026-01-12 11:28:09','2026-01-12 11:28:09','1','467418','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('133','56','2026-01-11','46','','','','2.00','50516.55','2026-01-12 11:28:59','2026-01-12 11:28:59','1','658867.2','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('134','58','2026-01-11','58','','','','0.00','54712.80','2026-01-12 11:29:24','2026-01-12 11:29:24','1','527697','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('135','66','2026-01-12','139','','','','','16470.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('136','67','2026-01-12','130','','','','','31730.40','2026-01-12 20:21:18','2026-01-12 20:21:18','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('137','68','2026-01-13','97','','','','','73191.60','2026-01-13 21:24:51','2026-01-13 21:24:51','1','188711','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('141','70','2026-01-14','15','','','','2.00','52690.68','2026-01-14 19:21:29','2026-01-14 19:21:29','1','483119.32999999996','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('142','71','2026-01-14','16','','','','2.00','13494.60','2026-01-14 19:25:46','2026-01-14 19:25:46','1','43378','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('144','72','2026-01-14','30','','','','2.00','13494.60','2026-01-14 19:27:59','2026-01-14 19:27:59','1','66.04000000000087','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('146','74','2026-01-14','27','','','','2.00','22755.60','2026-01-14 19:36:57','2026-01-14 19:36:57','1','179033','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('147','75','2026-01-14','21','','','','2.00','42777.00','2026-01-14 19:39:31','2026-01-14 19:39:31','1','1323505.52','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('148','76','2026-01-14','28','','','','2.00','15876.00','2026-01-14 19:42:02','2026-01-14 19:42:02','1','55561','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('151','78','2026-01-14','31','','','','2.00','24152.69','2026-01-14 19:53:34','2026-01-14 19:53:34','1','276215','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('152','77','2026-01-14','18','','','','0.00','23166.00','2026-01-14 19:54:50','2026-01-14 19:54:50','1','173124.6','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('153','79','2026-01-14','19','','','','','7200.00','2026-01-14 20:01:11','2026-01-14 20:01:11','1','130699','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('155','69','2026-01-13','125','','','','0.00','80240.80','2026-01-14 20:05:34','2026-01-14 20:05:34','1','29494','400','','');
INSERT INTO `sale_invoices_masters` VALUES ('156','81','2026-01-14','37','','','','2.00','8279.04','2026-01-14 20:18:44','2026-01-14 20:18:44','1','30839','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('158','82','2026-01-18','50','','','','','57600.00','2026-01-18 18:33:20','2026-01-18 18:33:20','1','186572','0','','157');
INSERT INTO `sale_invoices_masters` VALUES ('162','84','2026-01-12','53','','','','','78937.20','2026-01-18 18:57:21','2026-01-18 18:57:21','1','716636','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('163','85','2026-01-18','48','','','','','24300.00','2026-01-18 19:03:34','2026-01-18 19:03:34','1','74077.2','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('164','86','2026-01-18','51','','','','','22402.50','2026-01-18 19:08:58','2026-01-18 19:08:58','1','186298','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('165','87','2026-01-18','70','','','','','14700.00','2026-01-18 19:17:39','2026-01-18 19:17:39','1','35520','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('166','88','2026-01-18','59','','','','','107931.60','2026-01-18 19:24:56','2026-01-18 19:24:56','1','805694','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('167','89','2026-01-18','44','','','','','105516.00','2026-01-18 19:29:26','2026-01-18 19:29:26','1','164074','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('169','90','2026-01-18','56','','','','0.00','37620.00','2026-01-18 19:40:34','2026-01-18 19:40:34','1','65590','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('170','91','2026-01-18','83','','','','','33696.00','2026-01-18 19:46:19','2026-01-18 19:46:19','1','217799.59999999998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('171','92','2026-01-18','79','','','','','41504.40','2026-01-18 19:53:59','2026-01-18 19:53:59','1','20917.8','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('173','93','2026-01-18','76','','','','','32130.00','2026-01-18 20:01:27','2026-01-18 20:01:27','1','554776.5','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('174','94','2026-01-18','68','','','','','48870.00','2026-01-18 20:05:44','2026-01-18 20:05:44','1','71481','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('175','95','2026-01-18','64','','','','','12150.00','2026-01-18 20:09:22','2026-01-18 20:09:22','1','15440','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('177','96','2026-01-18','45','','','','0.00','20790.00','2026-01-18 20:11:22','2026-01-18 20:11:22','1','341014.5','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('179','8','2026-01-04','65','','','','0.00','63795.00','2026-01-18 20:22:11','2026-01-18 20:22:11','1','110752','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('180','98','2026-01-18','65','','','','','50520.00','2026-01-18 20:23:52','2026-01-18 20:23:52','1','197232.09999999998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('181','99','2026-01-18','60','','','','','101685.00','2026-01-18 20:34:08','2026-01-18 20:34:08','1','1087998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('186','101','2026-01-13','78','','','','','167196.60','2026-01-18 20:55:58','2026-01-18 20:55:58','1','41863','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('188','102','2026-01-18','55','','','','0.00','107625.60','2026-01-18 23:39:12','2026-01-18 23:39:12','1','103743','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('189','83','2026-01-18','63','','','','0.00','69380.40','2026-01-18 23:40:13','2026-01-18 23:40:13','1','157274','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('190','103','2026-01-18','46','','','','2.00','54816.30','2026-01-18 23:46:13','2026-01-18 23:46:13','1','709383.75','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('191','104','2026-01-18','58','','','','','118368.00','2026-01-18 23:50:34','2026-01-18 23:50:34','1','529047.8','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('192','105','2026-01-18','47','','','','','47745.00','2026-01-18 23:54:17','2026-01-18 23:54:17','1','289348','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('193','106','2026-01-18','72','','','','','14400.00','2026-01-18 23:58:30','2026-01-18 23:58:30','1','179838','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('194','107','2026-01-18','12','','','','','31248.00','2026-01-19 00:01:03','2026-01-19 00:01:03','1','651887','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('195','108','2026-01-18','49','','','','2.00','23814.00','2026-01-19 00:04:57','2026-01-19 00:04:57','1','96441','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('197','110','2026-01-19','42','','','','','7830.00','2026-01-19 00:13:23','2026-01-19 00:13:23','1','445473','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('198','111','2026-01-17','67','','','','','22815.00','2026-01-19 00:19:07','2026-01-19 00:19:07','1','26405','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('199','112','2026-01-19','114','','','','','75276.00','2026-01-19 00:21:38','2026-01-19 00:21:38','1','56448','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('202','109','2026-01-19','66','','','','2.00','148809.20','2026-01-19 00:29:31','2026-01-19 00:29:31','1','0','500','','');
INSERT INTO `sale_invoices_masters` VALUES ('204','73','2026-01-14','23','','','','2.00','27323.10','2026-01-19 19:58:29','2026-01-19 19:58:29','1','151041','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('205','113','2026-01-19','115','','','','','18360.00','2026-01-19 20:17:49','2026-01-19 20:17:49','1','-148','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('207','115','2026-01-21','23','','','','2.00','21609.00','2026-01-21 19:15:20','2026-01-21 19:15:20','1','178364.1','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('208','116','2026-01-21','100','','','','','51978.60','2026-01-21 19:24:42','2026-01-21 19:24:42','1','30474','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('209','114','2026-01-21','21','','','','2.00','202801.20','2026-01-21 19:26:36','2026-01-21 19:26:36','1','1216282.52','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('210','117','2026-01-21','19','','','','','18378.00','2026-01-21 19:29:51','2026-01-21 19:29:51','1','117899','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('211','118','2026-01-21','18','','','','','21150.00','2026-01-21 19:31:14','2026-01-21 19:31:14','1','171290.6','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('212','119','2026-01-21','27','','','','2.00','11907.00','2026-01-21 19:32:24','2026-01-21 19:32:24','1','191788.6','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('213','120','2026-01-21','22','','','','2.00','191091.18','2026-01-21 19:41:10','2026-01-21 19:41:10','1','950635','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('214','121','2026-01-21','36','','','','2.00','170742.85','2026-01-21 19:54:32','2026-01-21 19:54:32','1','128699','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('217','32','2026-01-10','111','','','','0.00','78577.00','2026-01-21 20:18:52','2026-01-21 20:18:52','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('218','122','2026-01-21','111','','','','','78577.00','2026-01-21 20:22:01','2026-01-21 20:22:01','1','-10923','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('219','123','2026-01-23','140','test','','','','17928.00','2026-01-23 17:07:44','2026-01-23 17:07:44','1','50000','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('220','22','2026-01-07','17','','','','2.00','9335.09','2026-01-24 12:21:42','2026-01-24 12:21:42','1','144862','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('222','124','2026-01-24','46','','','','2.00','98254.80','2026-01-24 15:56:29','2026-01-24 15:56:29','1','664200.05','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('223','125','2026-01-24','70','','','','','15915.00','2026-01-24 16:04:11','2026-01-24 16:04:11','1','30220','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('225','126','2026-01-24','61','','','','0.00','79575.00','2026-01-24 16:10:12','2026-01-24 16:10:12','1','123204','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('227','127','2026-01-19','42','','','','0.00','124405.20','2026-01-24 16:16:50','2026-01-24 16:16:50','1','383303','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('229','129','2026-01-19','44','','','','','12150.00','2026-01-24 16:25:39','2026-01-24 16:25:39','1','269590','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('231','130','2026-01-24','72','','','','0.00','79320.00','2026-01-24 16:28:30','2026-01-24 16:28:30','1','164238','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('232','131','2026-01-25','50','','','','','117075.00','2026-01-25 15:34:40','2026-01-25 15:34:40','1','144172','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('233','132','2026-01-25','58','','','','','94068.00','2026-01-25 15:37:14','2026-01-25 15:37:14','1','647415.8','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('234','133','2026-01-25','51','','','','','30615.00','2026-01-25 15:41:55','2026-01-25 15:41:55','1','183700.5','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('235','134','2026-01-25','67','','','','','7500.00','2026-01-25 15:46:02','2026-01-25 15:46:02','1','49220','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('236','135','2026-01-20','53','','','','','12150.00','2026-01-25 15:48:44','2026-01-25 15:48:44','1','695573.2','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('237','136','2026-01-25','64','','','','','8640.00','2026-01-25 15:56:08','2026-01-25 15:56:08','1','27590','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('238','137','2026-01-25','76','','','','','36585.00','2026-01-25 16:04:08','2026-01-25 16:04:08','1','536906.5','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('239','138','2026-01-25','83','','','','','12150.00','2026-01-25 16:06:47','2026-01-25 16:06:47','1','221495.59999999998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('240','139','2026-01-25','47','','','','','35580.00','2026-01-25 16:19:42','2026-01-25 16:19:42','1','281556','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('241','140','2026-01-25','68','','','','','32940.00','2026-01-25 16:26:18','2026-01-25 16:26:18','1','95351','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('242','141','2026-01-25','49','','','','2.00','128331.00','2026-01-25 16:32:23','2026-01-25 16:32:23','1','85255','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('243','142','2026-01-25','45','','','','','66753.00','2026-01-25 16:34:51','2026-01-25 16:34:51','1','301804.5','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('244','143','2026-01-25','134','','','','','15000.00','2026-01-25 16:36:56','2026-01-25 16:36:56','1','66930.4','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('245','144','2026-01-25','60','','','','','86127.60','2026-01-25 16:39:42','2026-01-25 16:39:42','1','889683','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('246','145','2026-01-21','12','','','','','65463.00','2026-01-25 16:42:46','2026-01-25 16:42:46','1','683135','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('247','146','2026-01-25','62','','','','','115200.00','2026-01-25 16:46:23','2026-01-25 16:46:23','1','92823','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('248','147','2026-01-25','12','','','','','136654.20','2026-01-25 16:58:32','2026-01-25 16:58:32','1','748598','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('251','149','2026-01-25','60','','','','0.00','137061.00','2026-01-25 17:03:54','2026-01-25 17:03:54','1','975810.6000000001','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('253','151','2026-01-25','70','','','','','7500.00','2026-01-25 17:11:05','2026-01-25 17:11:05','1','46135','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('254','152','2026-01-25','62','','','','','172800.00','2026-01-25 17:12:38','2026-01-25 17:12:38','1','208023','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('255','153','2026-01-25','68','','','','','16830.00','2026-01-25 17:13:35','2026-01-25 17:13:35','1','128291','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('256','154','2026-01-25','63','','','','','43200.00','2026-01-25 17:15:38','2026-01-25 17:15:38','1','226654.40000000002','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('257','155','2026-01-25','131','','','','','24300.00','2026-01-25 17:23:06','2026-01-25 17:23:06','1','-7654','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('263','157','2026-01-25','142','','','','2.00','33398.50','2026-01-25 17:30:27','2026-01-25 17:30:27','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('264','158','2026-01-25','69','','','','','246920.00','2026-01-25 17:38:31','2026-01-25 17:38:31','1','209400','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('265','156','2026-01-25','141','','','','0.00','24273.00','2026-01-25 18:49:20','2026-01-25 18:49:20','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('266','150','2026-01-25','50','','','','0.00','55240.00','2026-01-25 22:40:08','2026-01-25 22:40:08','1','261247','370','','');
INSERT INTO `sale_invoices_masters` VALUES ('267','128','2026-01-24','65','','','','0.00','66483.00','2026-01-25 22:43:58','2026-01-25 22:43:58','1','187752.09999999998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('268','31','2026-01-08','87','','','','0.00','45396.00','2026-01-25 22:52:45','2026-01-25 22:52:45','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('269','159','2026-01-26','59','','','','','82080.00','2026-01-26 12:16:06','2026-01-26 12:16:06','1','813625.6000000001','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('271','160','2026-01-26','123','','','','2.00','33466.61','2026-01-26 19:54:25','2026-01-26 19:54:25','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('272','161','2026-01-26','81','','','','','156158.00','2026-01-26 21:18:14','2026-01-26 21:18:14','1','629419','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('273','162','2026-01-26','143','','','','','52328.70','2026-01-26 21:38:14','2026-01-26 21:38:14','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('274','163','2026-01-27','87','','','','','66348.00','2026-01-27 19:34:44','2026-01-27 19:34:44','1','-4','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('277','164','2026-01-27','88','','','','0.00','1741086.00','2026-01-27 20:11:20','2026-01-27 20:11:20','1','51833','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('278','165','2026-01-28','139','','','','','16470.00','2026-01-28 13:02:52','2026-01-28 13:02:52','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('280','166','2026-01-28','28','','','','2.00','43306.20','2026-01-28 19:48:50','2026-01-28 19:48:50','1','51437','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('281','167','2026-01-28','15','','','','2.00','60685.13','2026-01-28 20:06:51','2026-01-28 20:06:51','1','505810.01','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('283','168','2026-01-28','29','','','','2.00','37467.36','2026-01-28 20:17:08','2026-01-28 20:17:08','1','113034.79999999999','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('284','169','2026-01-28','24','','','','2.00','29211.84','2026-01-28 20:24:42','2026-01-28 20:24:42','1','16399','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('286','170','2026-01-28','18','','','','0.00','39366.00','2026-01-28 20:30:17','2026-01-28 20:30:17','1','168940.59999999998','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('287','171','2026-01-28','27','','','','2.00','41660.98','2026-01-28 20:33:03','2026-01-28 20:33:03','1','188695.6','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('289','172','2026-01-28','38','','','','2.00','51685.20','2026-01-28 20:43:35','2026-01-28 20:43:35','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('290','173','2026-01-28','25','','','','2.00','12700.80','2026-01-28 20:45:11','2026-01-28 20:45:11','1','107757.09','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('291','174','2026-01-28','31','','','','2.00','62710.20','2026-01-28 20:52:54','2026-01-28 20:52:54','1','280367.69','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('292','175','2026-01-28','35','','','','2.00','52126.20','2026-01-28 20:57:31','2026-01-28 20:57:31','1','20696','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('293','176','2026-01-28','21','','','','2.00','122392.20','2026-01-28 21:00:45','2026-01-28 21:00:45','1','1269083.72','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('294','177','2026-01-28','17','','','','2.00','47987.86','2026-01-28 21:04:28','2026-01-28 21:04:28','1','114197.09','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('295','178','2026-01-28','23','','','','2.00','17463.60','2026-01-28 21:06:53','2026-01-28 21:06:53','1','184973.1','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('296','179','2026-01-28','16','','','','2.00','8731.80','2026-01-28 21:10:25','2026-01-28 21:10:25','1','56872.6','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('298','181','2026-01-28','131','','','','','38196.00','2026-01-28 21:33:54','2026-01-28 21:33:54','1','146','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('299','182','2026-01-28','117','','','','','36774.00','2026-01-28 21:36:15','2026-01-28 21:36:15','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('300','180','2026-01-28','100','','','','2.00','37008.36','2026-01-28 21:40:38','2026-01-28 21:40:38','1','57452.600000000006','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('301','29','2026-01-06','96','','','','2.00','31220.00','2026-01-28 21:45:35','2026-01-28 21:45:35','1','139963','350','','');
INSERT INTO `sale_invoices_masters` VALUES ('302','183','2026-01-14','96','','','','2.00','23937.60','2026-01-28 21:49:57','2026-01-28 21:49:57','1','171183','300','','');
INSERT INTO `sale_invoices_masters` VALUES ('303','184','2026-01-28','96','','','','2.00','66850.00','2026-01-28 21:51:48','2026-01-28 21:51:48','1','195120.6','700','','');


DROP TABLE IF EXISTS `sale_return_details`;
CREATE TABLE `sale_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_return_masters`;
CREATE TABLE `sale_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_return_invoice_invoice_no_unique` (`invoice_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_type`;
CREATE TABLE `sale_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_type` VALUES ('1','Taxable','2','2025-09-17 18:40:38','2025-09-17 18:40:38');
INSERT INTO `sale_type` VALUES ('3','Taxable','1','2025-09-22 10:34:37','2025-09-22 10:34:37');
INSERT INTO `sale_type` VALUES ('5','Exempt','1','2025-09-23 17:24:32','2025-09-23 17:24:32');
INSERT INTO `sale_type` VALUES ('7','Exempt','7','2025-10-15 10:20:19','2025-10-15 10:20:19');


DROP TABLE IF EXISTS `stock_adj_details`;
CREATE TABLE `stock_adj_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adj_details` VALUES ('2','1','7','-100','100','0','7','2025-10-17 21:12:41','2025-10-17 21:12:41');
INSERT INTO `stock_adj_details` VALUES ('3','2','7','-20','100','0','7','2025-10-17 21:13:05','2025-10-17 21:13:05');


DROP TABLE IF EXISTS `stock_adj_masters`;
CREATE TABLE `stock_adj_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` bigint unsigned NOT NULL,
  `v_date` date NOT NULL,
  `prepared_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `stock_adjustment`;
CREATE TABLE `stock_adjustment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adjustment` VALUES ('5','7','9','22','3','2025-10-27','-1.00','100.00','50000.00','100.00','-40000.00','','2025-10-27 19:25:13','2025-10-27 19:25:13','250');


DROP TABLE IF EXISTS `stock_qty`;
;

INSERT INTO `stock_qty` VALUES ('51','1','2025-10-28','9','0','0','0','1540','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('54','2','2025-11-05','9','0','0','0','1200','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('57','1','2025-11-10','14','0','0','0','23','0','0','12','4','8','SALE');
INSERT INTO `stock_qty` VALUES ('65','3','2025-12-19','9','0','0','0','120','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('72','1','2026-01-01','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('73','1','2026-01-01','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('74','2','2026-01-01','87','0','0','0','500','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('75','2','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('76','2','2026-01-01','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('77','2','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('78','2','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('79','3','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('80','4','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('81','4','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('82','4','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('83','4','2026-01-03','83','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('84','5','2026-01-03','40','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('85','6','2026-01-03','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('86','6','2026-01-01','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('87','6','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('88','6','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('89','6','2026-01-01','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('97','9','2026-01-03','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('98','10','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('99','10','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('100','10','2026-01-03','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('101','10','2026-01-03','86','0','0','0','200','0','0','200','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('102','10','2026-01-03','83','0','0','0','144','0','0','72','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('103','10','2026-01-03','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('104','10','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('105','10','2026-01-03','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('112','11','2026-01-03','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('113','12','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('114','12','2026-01-04','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('122','14','2026-01-04','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('123','14','2026-01-04','13','0','0','0','500','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('124','13','2026-01-04','24','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('129','16','2026-01-04','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('130','16','2026-01-04','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('131','16','2026-01-04','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('132','15','2026-01-04','61','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('137','17','2026-01-01','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('138','17','2026-01-01','82','0','0','0','100','0','0','100','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('139','17','2026-01-01','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('140','18','2026-01-01','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('141','18','2026-01-05','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('142','19','2026-01-01','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('148','21','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('149','21','2026-01-01','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('151','23','2026-01-01','25','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('152','24','2026-01-07','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('153','24','2026-01-01','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('154','24','2026-01-01','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('155','24','2026-01-01','19','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('156','25','2026-01-01','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('161','26','2026-01-01','68','0','0','0','384','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('162','26','2026-01-01','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('163','26','2026-01-01','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('164','26','2026-01-01','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('165','27','2025-12-25','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('166','20','2026-01-01','61','0','0','0','36','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('167','20','2026-01-01','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('168','20','2026-01-01','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('169','20','2026-01-01','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('170','20','2026-01-01','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('171','28','2026-01-06','21','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('172','28','2026-01-06','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('173','28','2026-01-06','25','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('174','28','2026-01-06','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('175','28','2026-01-06','66','0','0','0','360','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('176','28','2026-01-06','67','0','0','0','300','0','0','300','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('177','28','2026-01-06','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('178','28','2026-01-06','70','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('180','30','2026-01-06','20','0','0','0','80','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('181','30','2026-01-06','24','0','0','0','200','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('182','30','2026-01-06','28','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('183','30','2026-01-06','34','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('184','30','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('185','30','2026-01-06','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('186','30','2026-01-06','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('195','33','2026-01-11','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('196','33','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('206','35','2026-01-05','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('207','35','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('208','35','2026-01-05','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('209','35','2026-01-05','62','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('210','35','2026-01-05','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('211','35','2026-01-05','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('212','35','2026-01-11','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('213','35','2026-01-05','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('214','36','2026-01-05','20','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('215','36','2026-01-05','24','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('216','36','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('217','37','2026-01-05','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('218','37','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('219','37','2026-01-10','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('220','37','2026-01-10','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('221','38','2026-01-05','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('222','38','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('223','38','2026-01-05','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('224','38','2026-01-05','91','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('225','38','2026-01-05','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('235','39','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('236','39','2026-01-05','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('237','39','2026-01-05','70','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('238','39','2026-01-05','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('239','39','2026-01-05','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('240','39','2026-01-06','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('241','39','2026-01-07','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('242','39','2026-01-08','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('243','39','2026-01-08','79','0','0','0','192','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('244','39','2026-01-08','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('262','41','2026-01-05','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('263','42','2026-01-05','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('264','42','2026-01-05','90','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('265','42','2026-01-09','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('266','42','2026-01-09','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('267','42','2026-01-09','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('268','43','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('269','43','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('276','45','2026-01-06','42','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('277','45','2026-01-06','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('278','45','2026-01-06','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('279','45','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('280','45','2026-01-07','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('281','45','2026-01-07','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('282','45','2026-01-07','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('283','45','2026-01-07','64','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('284','45','2026-01-07','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('285','45','2026-01-07','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('286','45','2026-01-10','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('287','45','2026-01-10','29','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('288','45','2026-01-10','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('289','45','2026-01-10','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('290','46','2026-01-06','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('291','44','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('292','44','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('293','44','2026-01-06','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('294','44','2026-01-11','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('295','44','2026-01-11','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('296','44','2026-01-11','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('297','47','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('298','47','2026-01-11','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('299','47','2026-01-11','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('300','48','2026-01-06','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('301','48','2026-01-06','59','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('315','50','2026-01-06','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('316','50','2026-01-06','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('317','50','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('318','51','2026-01-06','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('319','52','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('320','52','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('322','54','2026-01-06','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('323','54','2026-01-08','83','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('324','54','2026-01-10','94','0','0','0','250','0','0','50','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('325','54','2026-01-10','24','0','0','0','200','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('326','54','2026-01-10','63','0','0','0','240','0','0','120','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('327','54','2026-01-10','81','0','0','0','180','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('328','54','2026-01-10','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('329','55','2026-01-07','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('330','55','2026-01-07','27','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('331','55','2026-01-07','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('332','55','2026-01-07','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('333','55','2026-01-07','62','0','0','0','100','0','0','100','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('340','57','2026-01-06','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('345','59','2026-01-08','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('346','59','2026-01-08','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('347','59','2026-01-08','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('348','59','2026-01-11','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('349','60','2026-01-08','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('351','61','2026-01-08','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('352','61','2026-01-08','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('353','61','2026-01-08','89','0','0','0','180','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('354','61','2026-01-08','80','0','0','0','270','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('355','62','2026-01-10','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('356','62','2026-01-10','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('357','62','2026-01-10','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('358','62','2026-01-10','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('359','63','2026-01-11','64','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('360','63','2026-01-11','79','0','0','0','192','0','0','64','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('361','63','2026-01-11','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('362','63','2026-01-11','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('363','64','2026-01-11','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('364','64','2026-01-11','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('365','64','2026-01-11','65','0','0','0','108','0','0','36','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('366','64','2026-01-11','64','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('367','64','2026-01-11','96','0','0','0','140','0','0','70','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('368','65','2026-01-06','81','0','0','0','300','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('369','65','2026-01-06','80','0','0','0','270','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('370','65','2026-01-11','79','0','0','0','320','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('371','40','2026-01-05','95','0','0','0','360','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('372','40','2026-01-05','96','0','0','0','140','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('373','40','2026-01-05','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('374','40','2026-01-05','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('375','40','2026-01-06','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('376','40','2026-01-06','77','0','0','0','64','0','0','64','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('377','40','2026-01-06','76','0','0','0','60','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('378','40','2026-01-06','96','0','0','0','70','0','0','70','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('379','40','2026-01-06','90','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('380','40','2026-01-07','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('381','40','2026-01-08','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('382','40','2026-01-08','96','0','0','0','140','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('383','40','2026-01-11','83','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('384','40','2026-01-11','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('385','40','2026-01-11','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('386','40','2026-01-11','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('387','40','2026-01-11','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('388','49','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('389','49','2026-01-06','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('390','49','2026-01-06','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('391','49','2026-01-06','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('392','49','2026-01-06','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('393','49','2026-01-06','91','0','0','0','180','0','0','180','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('394','49','2026-01-06','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('395','49','2026-01-06','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('396','49','2026-01-06','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('397','49','2026-01-06','23','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('398','49','2026-01-06','28','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('399','49','2026-01-06','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('400','56','2026-01-07','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('401','56','2026-01-07','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('402','56','2026-01-07','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('403','56','2026-01-09','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('404','56','2026-01-09','28','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('405','58','2026-01-08','71','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('406','58','2026-01-10','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('407','66','2026-01-12','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('408','66','2026-01-12','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('409','67','2026-01-12','24','0','0','0','120','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('410','67','2026-01-12','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('411','68','2026-01-13','66','0','0','0','360','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('412','68','2026-01-13','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('413','68','2026-01-13','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('414','68','2026-01-11','47','0','0','0','30','0','0','30','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('415','68','2026-01-13','61','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('416','68','2026-01-13','60','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('433','70','2026-01-08','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('434','70','2026-01-11','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('435','70','2026-01-12','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('436','70','2026-01-12','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('437','70','2026-01-12','65','0','0','0','36','0','0','36','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('438','70','2026-01-13','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('439','71','2026-01-14','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('441','72','2026-01-13','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('444','74','2026-01-08','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('445','74','2026-01-08','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('446','75','2026-01-08','62','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('447','75','2026-01-08','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('448','76','2026-01-08','64','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('454','78','2026-01-08','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('455','78','2026-01-08','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('456','77','2026-01-08','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('457','77','2026-01-08','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('458','79','2026-01-08','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('461','69','2026-01-13','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('462','69','2026-01-13','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('463','69','2026-01-13','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('464','69','2026-01-13','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('465','69','2026-01-13','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('466','69','2026-01-13','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('467','81','2026-01-06','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('469','82','2026-01-12','83','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('479','84','2026-01-12','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('480','84','2026-01-13','39','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('481','84','2026-01-15','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('482','84','2026-01-15','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('483','84','2026-01-15','21','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('484','84','2026-01-15','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('485','85','2026-01-12','91','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('486','85','2026-01-12','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('487','86','2026-01-12','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('488','86','2026-01-12','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('489','87','2026-01-12','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('490','87','2026-01-15','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('491','88','2026-01-12','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('492','88','2026-01-13','94','0','0','0','150','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('493','88','2026-01-17','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('494','88','2026-01-17','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('495','88','2026-01-17','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('496','88','2026-01-17','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('497','89','2026-01-13','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('498','89','2026-01-13','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('499','89','2026-01-14','59','0','0','0','180','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('500','89','2026-01-14','58','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('501','89','2026-01-14','57','0','0','0','192','0','0','96','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('505','90','2026-01-13','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('506','90','2026-01-13','58','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('507','90','2026-01-13','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('508','91','2026-01-13','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('509','91','2026-01-13','67','0','0','0','90','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('510','91','2026-01-13','68','0','0','0','90','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('511','91','2026-01-13','69','0','0','0','90','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('512','92','2026-01-13','66','0','0','0','84','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('513','92','2026-01-13','67','0','0','0','96','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('514','92','2026-01-13','68','0','0','0','96','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('515','92','2026-01-13','69','0','0','0','72','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('516','92','2026-01-13','70','0','0','0','60','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('517','92','2026-01-13','71','0','0','0','48','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('520','93','2026-01-13','80','0','0','0','180','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('521','93','2026-01-18','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('522','94','2026-01-13','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('523','94','2026-01-13','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('524','94','2026-01-13','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('525','94','2026-01-13','79','0','0','0','64','0','0','64','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('526','94','2026-01-13','90','0','0','0','100','0','0','100','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('527','95','2026-01-13','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('529','96','2026-01-13','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('530','96','2026-01-13','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('539','8','2026-01-03','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('540','8','2026-01-03','39','0','0','0','30','0','0','30','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('541','8','2026-01-03','42','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('542','8','2026-01-03','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('543','8','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('544','8','2026-01-04','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('545','98','2026-01-13','94','0','0','0','250','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('546','98','2026-01-13','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('547','98','2026-01-13','93','0','0','0','60','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('548','99','2026-01-13','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('549','99','2026-01-13','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('550','99','2026-01-13','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('551','99','2026-01-15','90','0','0','0','300','0','0','100','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('552','99','2026-01-15','96','0','0','0','140','0','0','70','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('553','99','2026-01-15','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('554','99','2026-01-18','87','0','0','0','200','0','0','100','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('555','99','2026-01-18','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('579','101','2026-01-13','88','0','0','0','297','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('580','101','2026-01-13','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('581','101','2026-01-13','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('582','101','2026-01-13','89','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('583','101','2026-01-13','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('584','101','2026-01-13','68','0','0','0','192','0','0','192','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('585','101','2026-01-13','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('586','101','2026-01-13','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('587','101','2026-01-13','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('588','101','2026-01-13','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('597','102','2026-01-13','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('598','102','2026-01-13','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('599','102','2026-01-13','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('600','102','2026-01-13','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('601','102','2026-01-13','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('602','102','2026-01-17','51','0','0','0','300','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('603','102','2026-01-17','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('604','102','2026-01-17','20','0','0','0','80','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('605','83','2026-01-12','87','0','0','0','400','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('606','83','2026-01-12','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('607','83','2026-01-14','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('608','83','2026-01-18','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('609','103','2026-01-14','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('610','103','2026-01-17','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('611','103','2026-01-18','20','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('612','103','2026-01-18','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('613','103','2026-01-18','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('614','104','2026-01-14','71','0','0','0','216','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('615','104','2026-01-14','80','0','0','0','180','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('616','104','2026-01-14','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('617','104','2026-01-15','71','0','0','0','144','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('618','105','2026-01-14','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('619','105','2026-01-14','88','0','0','0','297','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('620','106','2026-01-15','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('621','107','2026-01-15','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('622','107','2026-01-15','41','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('623','107','2026-01-15','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('624','108','2026-01-15','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('627','110','2026-01-17','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('628','111','2026-01-17','94','0','0','0','144','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('629','111','2026-01-17','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('630','112','2026-01-17','46','0','0','0','60','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('631','112','2026-01-17','47','0','0','0','60','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('632','112','2026-01-17','61','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('633','112','2026-01-17','93','0','0','0','120','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('638','109','2026-01-15','80','0','0','0','450','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('639','109','2026-01-15','88','0','0','0','1188','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('643','73','2026-01-12','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('644','73','2026-01-12','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('645','73','2026-01-14','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('646','113','2026-01-18','20','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('647','113','2026-01-18','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('655','115','2026-01-19','62','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('656','115','2026-01-20','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('657','116','2026-01-18','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('658','116','2026-01-18','21','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('659','116','2026-01-18','57','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('660','116','2026-01-18','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('661','114','2026-01-15','24','0','0','0','120','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('662','114','2026-01-15','28','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('663','114','2026-01-15','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('664','114','2026-01-15','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('665','114','2026-01-15','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('666','114','2026-01-15','94','0','0','0','150','0','0','50','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('667','114','2026-01-15','96','0','0','0','140','0','0','70','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('668','114','2026-01-18','90','0','0','0','1000','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('669','114','2026-01-18','88','0','0','0','495','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('670','117','2026-01-15','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('671','117','2026-01-15','21','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('672','118','2026-01-15','95','0','0','0','180','0','0','180','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('673','118','2026-01-15','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('674','119','2026-01-21','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('675','120','2026-01-15','87','0','0','0','500','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('676','120','2026-01-15','88','0','0','0','495','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('677','120','2026-01-15','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('678','120','2026-01-15','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('679','120','2026-01-15','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('680','120','2026-01-15','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('681','120','2026-01-15','39','0','0','0','30','0','0','30','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('682','120','2026-01-15','34','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('683','120','2026-01-15','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('684','120','2026-01-15','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('685','120','2026-01-15','95','0','0','0','360','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('686','121','2026-01-18','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('687','121','2026-01-18','41','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('688','121','2026-01-18','27','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('689','121','2026-01-18','29','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('690','121','2026-01-18','23','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('691','121','2026-01-18','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('692','121','2026-01-18','19','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('693','121','2026-01-18','20','0','0','0','80','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('694','121','2026-01-18','13','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('695','121','2026-01-18','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('696','121','2026-01-18','93','0','0','0','60','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('709','32','2026-01-10','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('710','32','2026-01-10','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('711','32','2026-01-10','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('712','32','2026-01-10','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('713','32','2026-01-10','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('714','32','2026-01-10','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('715','122','2026-01-21','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('716','122','2026-01-21','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('717','122','2026-01-21','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('718','122','2026-01-21','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('719','122','2026-01-21','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('720','122','2026-01-21','80','0','0','0','180','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('721','123','2026-01-23','11','0','0','0','216','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('722','22','2026-01-07 00:00:00','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('730','124','2026-01-19 00:00:00','34','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('731','124','2026-01-20 00:00:00','24','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('732','124','2026-01-20 00:00:00','20','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('733','124','2026-01-20 00:00:00','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('734','124','2026-01-20 00:00:00','34','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('735','124','2026-01-20 00:00:00','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('736','124','2026-01-20 00:00:00','88','0','0','0','297','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('737','125','2026-01-19 00:00:00','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('738','125','2026-01-19 00:00:00','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('741','126','2026-01-19 00:00:00','87','0','0','0','500','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('742','126','2026-01-19 00:00:00','88','0','0','0','495','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('751','127','2026-01-19 00:00:00','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('752','127','2026-01-19 00:00:00','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('753','127','2026-01-19 00:00:00','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('754','127','2026-01-19 00:00:00','89','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('755','127','2026-01-19 00:00:00','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('756','127','2026-01-19 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('757','127','2026-01-19 00:00:00','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('758','127','2026-01-21 00:00:00','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('759','127','2026-01-21 00:00:00','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('767','129','2026-01-19 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('772','130','2026-01-19 00:00:00','39','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('773','130','2026-01-19 00:00:00','27','0','0','0','70','0','0','35','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('774','130','2026-01-19 00:00:00','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('775','130','2026-01-19 00:00:00','62','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('776','131','2026-01-19 00:00:00','87','0','0','0','1000','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('777','131','2026-01-19 00:00:00','88','0','0','0','495','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('778','132','2026-01-19 00:00:00','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('779','132','2026-01-19 00:00:00','71','0','0','0','144','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('780','132','2026-01-19 00:00:00','71','0','0','0','216','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('781','133','2026-01-19 00:00:00','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('782','133','2026-01-19 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('783','133','2026-01-21 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('784','134','2026-01-19 00:00:00','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('785','135','2026-01-20 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('786','136','2026-01-25 00:00:00','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('787','137','2026-01-25 00:00:00','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('788','137','2026-01-20 00:00:00','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('789','137','2026-01-20 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('790','138','2026-01-20 00:00:00','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('791','139','2026-01-20 00:00:00','65','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('792','139','2026-01-20 00:00:00','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('793','139','2026-01-20 00:00:00','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('794','140','2026-01-20 00:00:00','79','0','0','0','128','0','0','64','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('795','140','2026-01-20 00:00:00','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('796','141','2026-01-20 00:00:00','81','0','0','0','300','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('797','141','2026-01-20 00:00:00','80','0','0','0','270','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('798','141','2026-01-20 00:00:00','79','0','0','0','320','0','0','64','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('799','141','2026-01-20 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('800','142','2026-01-20 00:00:00','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('801','142','2026-01-20 00:00:00','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('802','142','2026-01-20 00:00:00','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('803','142','2026-01-20 00:00:00','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('804','142','2026-01-20 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('805','142','2026-01-20 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('806','143','2026-01-20 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('807','144','2026-01-20 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('808','144','2026-01-20 00:00:00','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('809','144','2026-01-20 00:00:00','96','0','0','0','140','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('810','144','2026-01-20 00:00:00','77','0','0','0','64','0','0','64','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('811','144','2026-01-20 00:00:00','76','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('812','144','2026-01-20 00:00:00','16','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('813','145','2026-01-21 00:00:00','87','0','0','0','200','0','0','100','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('814','145','2026-01-21 00:00:00','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('815','145','2026-01-21 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('816','145','2026-01-21 00:00:00','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('817','145','2026-01-21 00:00:00','19','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('818','146','2026-01-22 00:00:00','83','0','0','0','1440','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('819','147','2026-01-22 00:00:00','16','0','0','0','72','0','0','72','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('820','147','2026-01-22 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('821','147','2026-01-22 00:00:00','29','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('822','147','2026-01-22 00:00:00','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('823','147','2026-01-22 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('824','147','2026-01-22 00:00:00','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('825','147','2026-01-22 00:00:00','41','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('826','147','2026-01-25 00:00:00','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('827','147','2026-01-25 00:00:00','29','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('828','147','2026-01-25 00:00:00','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('829','147','2026-01-25 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('830','147','2026-01-25 00:00:00','64','0','0','0','72','0','0','36','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('839','149','2026-01-22 00:00:00','83','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('840','149','2026-01-24 00:00:00','70','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('841','149','2026-01-24 00:00:00','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('842','149','2026-01-24 00:00:00','77','0','0','0','64','0','0','64','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('843','149','2026-01-24 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('844','149','2026-01-24 00:00:00','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('845','149','2026-01-24 00:00:00','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('853','151','2026-01-24 00:00:00','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('854','152','2026-01-24 00:00:00','83','0','0','0','2160','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('855','153','2026-01-24 00:00:00','41','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('856','153','2026-01-24 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('857','154','2026-01-24 00:00:00','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('858','154','2026-01-24 00:00:00','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('859','155','2026-01-25 00:00:00','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('860','155','2026-01-22 00:00:00','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('872','157','2026-01-25 00:00:00','47','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('873','157','2026-01-25 00:00:00','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('874','157','2026-01-25 00:00:00','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('875','157','2026-01-25 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('876','158','2026-01-12 00:00:00','89','0','0','0','180','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('877','158','2026-01-14 00:00:00','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('878','158','2026-01-17 00:00:00','79','0','0','0','320','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('879','158','2026-01-24 00:00:00','87','0','0','0','600','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('880','158','2026-01-24 00:00:00','88','0','0','0','594','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('881','158','2026-01-25 00:00:00','87','0','0','0','500','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('882','158','2026-01-25 00:00:00','88','0','0','0','495','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('883','156','2026-01-25 00:00:00','80','0','0','0','180','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('884','150','2026-01-22 00:00:00','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('885','150','2026-01-22 00:00:00','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('886','150','2026-01-25 00:00:00','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('887','150','2026-11-25 00:00:00','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('888','128','2026-01-19 00:00:00','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('889','128','2026-01-19 00:00:00','24','0','0','0','80','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('890','128','2026-01-19 00:00:00','65','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('891','128','2026-01-19 00:00:00','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('892','128','2026-01-19 00:00:00','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('893','128','2026-01-21 00:00:00','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('894','128','2026-01-21 00:00:00','36','0','0','0','16','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('895','128','2026-01-25 00:00:00','93','0','0','0','60','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('896','31','2026-01-08 00:00:00','47','0','0','0','120','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('897','31','2026-01-08 00:00:00','61','0','0','0','50','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('898','159','2026-01-25 00:00:00','34','0','0','0','180','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('899','159','2026-01-25 00:00:00','94','0','0','0','150','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('900','159','2026-01-25 00:00:00','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('902','160','2026-01-26 00:00:00','66','0','0','0','36','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('903','160','2026-01-26 00:00:00','67','0','0','0','36','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('904','160','2026-01-26 00:00:00','68','0','0','0','36','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('905','160','2026-01-26 00:00:00','69','0','0','0','36','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('906','160','2026-01-26 00:00:00','70','0','0','0','36','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('907','160','2026-01-26 00:00:00','71','0','0','0','36','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('908','160','2026-01-26 00:00:00','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('909','161','2026-01-03 00:00:00','16','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('910','161','2026-01-03 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('911','161','2026-01-03 00:00:00','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('912','161','2026-01-03 00:00:00','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('913','161','2026-01-03 00:00:00','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('914','161','2026-01-06 00:00:00','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('915','161','2026-01-06 00:00:00','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('916','161','2026-01-06 00:00:00','24','0','0','0','160','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('917','161','2026-01-06 00:00:00','34','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('918','161','2026-01-08 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('919','161','2026-01-10 00:00:00','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('920','161','2026-01-10 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('921','161','2026-01-10 00:00:00','25','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('922','161','2026-01-10 00:00:00','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('923','161','2026-01-10 00:00:00','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('924','161','2026-01-10 00:00:00','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('925','162','2026-01-26 00:00:00','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('926','162','2026-01-26 00:00:00','20','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('927','162','2026-01-26 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('928','162','2026-01-26 00:00:00','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('929','162','2026-01-26 00:00:00','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('930','162','2026-01-26 00:00:00','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('931','163','2026-01-26 00:00:00','51','0','0','0','240','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('932','163','2026-01-26 00:00:00','47','0','0','0','60','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('933','163','2026-01-26 00:00:00','61','0','0','0','50','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('997','164','2026-01-20 00:00:00','11','0','0','0','540','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('998','164','2026-01-20 00:00:00','16','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('999','164','2026-01-20 00:00:00','20','0','0','0','400','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1000','164','2026-01-20 00:00:00','24','0','0','0','320','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1001','164','2026-01-20 00:00:00','10','0','0','0','324','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1002','164','2026-01-20 00:00:00','13','0','0','0','576','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1003','164','2026-01-20 00:00:00','19','0','0','0','240','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1004','164','2026-01-20 00:00:00','23','0','0','0','240','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1005','164','2026-01-20 00:00:00','27','0','0','0','105','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1006','164','2026-01-20 00:00:00','55','0','0','0','192','0','0','96','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1007','164','2026-01-20 00:00:00','57','0','0','0','192','0','0','96','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1008','164','2026-01-20 00:00:00','58','0','0','0','180','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1009','164','2026-01-20 00:00:00','59','0','0','0','180','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1010','164','2026-01-20 00:00:00','46','0','0','0','450','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1011','164','2026-01-20 00:00:00','47','0','0','0','600','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1012','164','2026-01-20 00:00:00','48','0','0','0','960','0','0','192','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1013','164','2026-01-20 00:00:00','63','0','0','0','240','0','0','120','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1014','164','2026-01-20 00:00:00','62','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1015','164','2026-01-20 00:00:00','61','0','0','0','1000','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1016','164','2026-01-20 00:00:00','65','0','0','0','360','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1017','164','2026-01-20 00:00:00','64','0','0','0','108','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1018','164','2026-01-20 00:00:00','93','0','0','0','120','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1019','164','2026-01-20 00:00:00','51','0','0','0','900','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1020','164','2026-01-20 00:00:00','66','0','0','0','360','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1021','164','2026-01-20 00:00:00','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1022','164','2026-01-20 00:00:00','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1023','164','2026-01-20 00:00:00','69','0','0','0','144','0','0','144','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1024','164','2026-01-20 00:00:00','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1025','164','2026-01-20 00:00:00','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1026','164','2026-01-20 00:00:00','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1027','164','2026-01-20 00:00:00','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1028','164','2026-01-20 00:00:00','97','0','0','0','250','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1029','165','2026-01-28 00:00:00','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1030','165','2026-01-28 00:00:00','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1035','166','2026-01-22 00:00:00','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1036','166','2026-01-22 00:00:00','55','0','0','0','96','0','0','96','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1037','166','2026-01-22 00:00:00','57','0','0','0','96','0','0','96','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1038','166','2026-01-22 00:00:00','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1039','167','2026-01-22 00:00:00','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1040','167','2026-01-25 00:00:00','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1041','167','2026-01-25 00:00:00','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1042','167','2026-01-25 00:00:00','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1043','167','2026-01-25 00:00:00','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1044','167','2026-01-25 00:00:00','61','0','0','0','36','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1045','167','2026-01-25 00:00:00','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1049','168','2026-01-22 00:00:00','47','0','0','0','60','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1050','168','2026-01-22 00:00:00','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1051','168','2026-01-25 00:00:00','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1052','169','2026-01-22 00:00:00','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1053','169','2026-01-22 00:00:00','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1054','169','2026-01-22 00:00:00','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1058','170','2026-01-22 00:00:00','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1059','170','2026-01-22 00:00:00','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1060','170','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1061','171','2026-01-22 00:00:00','87','0','0','0','100','0','0','100','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1062','171','2026-01-22 00:00:00','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1063','171','2026-01-22 00:00:00','96','0','0','0','70','0','0','70','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1064','171','2026-01-28 00:00:00','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1065','171','2026-01-22 00:00:00','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1070','172','2026-01-28 00:00:00','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1071','172','2026-01-22 00:00:00','57','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1072','172','2026-01-22 00:00:00','55','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1073','172','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1074','173','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1075','174','2026-01-22 00:00:00','55','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1076','174','2026-01-22 00:00:00','57','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1077','174','2026-01-22 00:00:00','58','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1078','174','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1079','174','2026-01-22 00:00:00','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1080','175','2026-01-22 00:00:00','55','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1081','175','2026-01-22 00:00:00','57','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1082','175','2026-01-22 00:00:00','58','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1083','175','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1084','176','2026-01-22 00:00:00','57','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1085','176','2026-01-22 00:00:00','55','0','0','0','96','0','0','96','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1086','176','2026-01-22 00:00:00','59','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1087','176','2026-01-22 00:00:00','96','0','0','0','350','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1088','176','2026-01-22 00:00:00','83','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1089','177','2026-01-22 00:00:00','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1090','177','2026-01-22 00:00:00','68','0','0','0','192','0','0','192','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1091','177','2026-01-22 00:00:00','69','0','0','0','144','0','0','144','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1092','177','2026-01-22 00:00:00','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1093','178','2026-01-25 00:00:00','51','0','0','0','120','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1094','179','2026-01-25 00:00:00','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1098','181','2026-01-27 00:00:00','73','0','0','0','36','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1099','181','2026-01-27 00:00:00','85','0','0','0','100','0','0','100','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1100','181','2026-01-27 00:00:00','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1101','181','2026-01-27 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1102','182','2026-01-27 00:00:00','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1103','182','2026-01-27 00:00:00','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1104','182','2026-01-27 00:00:00','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1105','180','2026-01-25 00:00:00','51','0','0','0','120','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('1106','180','2026-01-25 00:00:00','80','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1107','180','2026-01-25 00:00:00','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1108','29','2026-01-06 00:00:00','24','0','0','0','200','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1109','183','2026-01-13 00:00:00','20','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1110','183','2026-01-13 00:00:00','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('1111','184','2026-01-27 00:00:00','24','0','0','0','200','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('1112','184','2026-01-27 00:00:00','94','0','0','0','250','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('11','1','2025-11-10','11','0','0','108','0','0','0','108','1','1','PURCHASE_RETURN');
INSERT INTO `stock_qty` VALUES ('2','1','2025-10-27','9','250','0','0','0','0','0','250','3','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('4','1','2025-12-19','72','1206','0','0','0','0','0','12','7','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('5','1','2025-12-19','72','202','0','0','0','0','0','4','7','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('5','5','2025-10-27','9','0','0','0','0','0','-150','250','3','7','STOCK_ADJUSTMENT');


DROP TABLE IF EXISTS `store`;
CREATE TABLE `store` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store` VALUES ('1','Unit 1(1st Floor)','1','2025-10-21 20:22:12','2025-10-25 18:53:26');
INSERT INTO `store` VALUES ('2','Unit 1(2nd Floor)','1','2025-10-25 18:53:56','2025-10-25 18:53:56');
INSERT INTO `store` VALUES ('3','Tester','7','2025-10-27 19:12:18','2025-10-27 19:12:18');
INSERT INTO `store` VALUES ('4','Zenobias','8','2025-11-10 21:35:42','2025-11-10 21:35:51');
INSERT INTO `store` VALUES ('5','cache','8','2025-11-10 21:36:24','2025-11-10 21:36:24');
INSERT INTO `store` VALUES ('6','Unit 2(1st Floor)','1','2025-12-07 11:28:36','2025-12-07 11:28:53');
INSERT INTO `store` VALUES ('7','Gujranwala Store','7','2025-12-19 16:22:39','2025-12-19 16:22:39');


DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `supplier` VALUES ('3','Gujranwala','Gujranwala','30000-00000-0','03377777000','testuser@gmail.com','12121213','13','2025-09-22 18:55:12','2025-09-22 18:55:26','1','testuser');
INSERT INTO `supplier` VALUES ('4','DONE','DOBNE','1829182918','19289182198','faizan@gmail.com','112112','18','2025-10-17 12:25:24','2025-10-17 12:25:24','7','DONE');
INSERT INTO `supplier` VALUES ('7','Grw','','','123','','','30','2025-11-07 00:20:07','2025-11-07 00:20:07','1','Supplier ABC');
INSERT INTO `supplier` VALUES ('8','Gujranwala','house 25/433 , Kashmir colony, Rahwali,Pakistan','','03251568863','','','34','2025-11-10 21:35:11','2025-11-10 21:35:20','8','Wali Baig');


DROP TABLE IF EXISTS `trn_dtl`;
CREATE TABLE `trn_dtl` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preparedby` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `cash_id` bigint unsigned DEFAULT NULL,
  `r_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pre_bal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=773 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trn_dtl` VALUES ('152','SIN','1','2025-10-28','','261000.00','0','','Admin PremierTax','28','','1','','','7','2025-10-28 19:43:09','2025-11-05 02:01:18');
INSERT INTO `trn_dtl` VALUES ('156','SIN','2','2025-11-05','','202000.00','0','','Admin PremierTax','28','','2','','','7','2025-11-05 02:02:59','2025-11-05 02:05:38');
INSERT INTO `trn_dtl` VALUES ('160','BRV','1','2025-11-06','','0','63000.00','N','Admin','6','2','','','','1','2025-11-07 00:45:38','2025-11-07 00:45:38');
INSERT INTO `trn_dtl` VALUES ('188','SIN','1','2025-11-10','','1351.35','0','','Demo Wali','35','','1','','','8','2025-11-10 21:58:15','2025-11-10 21:58:15');
INSERT INTO `trn_dtl` VALUES ('190','PRN','1','2025-11-10','','83.00','0','','Admin','30','9','1','','','1','2025-11-10 23:14:24','2025-11-10 23:14:24');
INSERT INTO `trn_dtl` VALUES ('197','SIN','3','2025-12-19','','20000.00','0','','Admin PremierTax','28','156','3','','','7','2025-12-19 16:21:31','2025-12-19 16:21:31');
INSERT INTO `trn_dtl` VALUES ('202','OB','1','2026-01-01','','20917.8','0','N','Admin','101','','','','','1','2026-01-01 19:41:04','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('203','OB','1','2026-01-01','','0','20917.8','N','Admin','9','','','','','1','2026-01-01 19:41:04','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('204','OB','1','2026-01-01','','499253','0','N','Admin','37','','','','','1','2026-01-01 19:45:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('205','OB','1','2026-01-01','','0','499253','N','Admin','9','','','','','1','2026-01-01 19:45:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('206','OB','1','2026-01-01','','31471','0','N','Admin','38','','','','','1','2026-01-01 19:45:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('207','OB','1','2026-01-01','','0','31471','N','Admin','9','','','','','1','2026-01-01 19:45:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('208','OB','1','2026-01-01','','164862','0','N','Admin','39','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('209','OB','1','2026-01-01','','0','164862','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('210','OB','1','2026-01-01','','184701','0','N','Admin','40','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('211','OB','1','2026-01-01','','0','184701','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('212','OB','1','2026-01-01','','160979','0','N','Admin','41','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('213','OB','1','2026-01-01','','0','160979','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('214','OB','1','2026-01-01','','779710','0','N','Admin','42','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('215','OB','1','2026-01-01','','0','779710','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('216','OB','1','2026-01-01','','1453069','0','N','Admin','43','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('217','OB','1','2026-01-01','','0','1453069','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('218','OB','1','2026-01-01','','1250635','0','N','Admin','44','','','','','1','2026-01-01 20:07:56','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('219','OB','1','2026-01-01','','0','1250635','N','Admin','9','','','','','1','2026-01-01 20:07:56','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('220','OB','1','2026-01-01','','161041','0','N','Admin','45','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('221','OB','1','2026-01-01','','0','161041','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('222','OB','1','2026-01-01','','46399','0','N','Admin','46','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('223','OB','1','2026-01-01','','0','46399','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('224','OB','1','2026-01-01','','117515','0','N','Admin','47','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('225','OB','1','2026-01-01','','0','117515','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('226','OB','1','2026-01-01','','22106','0','N','Admin','114','','','','','1','2026-01-03 16:39:04','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('227','OB','1','2026-01-01','','0','22106','N','Admin','9','','','','','1','2026-01-03 16:39:04','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('228','SIN','1','2026-01-03','','19130.40','0','','Admin','114','2','1','','','1','2026-01-03 16:53:15','2026-01-03 16:53:15');
INSERT INTO `trn_dtl` VALUES ('229','OB','1','2026-01-01','','114304','0','N','Admin','85','','','','','1','2026-01-04 16:41:23','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('230','OB','1','2026-01-01','','0','114304','N','Admin','9','','','','','1','2026-01-04 16:41:23','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('231','SIN','2','2026-01-04','','74760.00','0','','Admin','85','2','2','','','1','2026-01-04 16:47:08','2026-01-04 16:47:08');
INSERT INTO `trn_dtl` VALUES ('232','OB','1','2026-01-01','','459343','0','N','Admin','64','','','','','1','2026-01-04 16:51:34','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('233','OB','1','2026-01-01','','0','459343','N','Admin','9','','','','','1','2026-01-04 16:51:34','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('234','SIN','3','2026-01-04','','7830.00','0','','Admin','64','2','3','','','1','2026-01-04 16:52:31','2026-01-04 16:52:31');
INSERT INTO `trn_dtl` VALUES ('235','OB','1','2026-01-01','','605118','0','N','Admin','75','','','','','1','2026-01-04 16:54:17','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('236','OB','1','2026-01-01','','0','605118','N','Admin','9','','','','','1','2026-01-04 16:54:17','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('237','SIN','4','2026-01-04','','45900.00','0','','Admin','75','2','4','','','1','2026-01-04 16:58:51','2026-01-04 16:58:51');
INSERT INTO `trn_dtl` VALUES ('238','OB','1','2026-01-01','','197168','0','N','Admin','73','','','','','1','2026-01-04 17:00:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('239','OB','1','2026-01-01','','0','197168','N','Admin','9','','','','','1','2026-01-04 17:00:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('240','SIN','5','2026-01-04','','18630.00','0','','Admin','73','2','5','','','1','2026-01-04 17:02:32','2026-01-04 17:02:32');
INSERT INTO `trn_dtl` VALUES ('241','OB','1','2026-01-01','','85143','0','N','Admin','77','','','','','1','2026-01-04 17:04:37','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('242','OB','1','2026-01-01','','0','85143','N','Admin','9','','','','','1','2026-01-04 17:04:37','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('243','SIN','6','2026-01-04','','48600.00','0','','Admin','77','2','6','','','1','2026-01-04 17:07:51','2026-01-04 17:07:51');
INSERT INTO `trn_dtl` VALUES ('247','OB','1','2026-01-01','','110752','0','N','Admin','87','','','','','1','2026-01-04 17:20:41','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('248','OB','1','2026-01-01','','0','110752','N','Admin','9','','','','','1','2026-01-04 17:20:41','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('250','OB','1','2026-01-01','','332903','0','N','Admin','69','','','','','1','2026-01-04 17:28:34','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('251','OB','1','2026-01-01','','0','332903','N','Admin','9','','','','','1','2026-01-04 17:28:34','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('252','SIN','9','2026-01-04','','12915.00','0','','Admin','69','2','9','','','1','2026-01-04 17:29:31','2026-01-04 17:29:31');
INSERT INTO `trn_dtl` VALUES ('253','OB','1','2026-01-01','','206022','0','N','Admin','72','','','','','1','2026-01-04 17:45:26','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('254','OB','1','2026-01-01','','0','206022','N','Admin','9','','','','','1','2026-01-04 17:45:26','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('256','CRV','1','2026-01-03','','0','50000.00','N','Admin','72','157','','','','1','2026-01-04 20:06:11','2026-01-04 20:06:11');
INSERT INTO `trn_dtl` VALUES ('257','SIN','10','2026-01-04','','83785.00','0','','Admin','72','2','10','','','1','2026-01-04 20:10:46','2026-01-04 20:10:46');
INSERT INTO `trn_dtl` VALUES ('258','OB','1','2026-01-01','','1072290','0','N','Admin','82','','','','','1','2026-01-04 20:19:01','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('259','OB','1','2026-01-01','','0','1072290','N','Admin','9','','','','','1','2026-01-04 20:19:01','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('260','SIN','10','2026-01-04','','7500.00','0','','Admin','82','2','11','','','1','2026-01-04 20:20:53','2026-01-04 20:20:53');
INSERT INTO `trn_dtl` VALUES ('261','OB','1','2026-01-01','','88668','0','N','Admin','100','','','','','1','2026-01-04 20:23:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('262','OB','1','2026-01-01','','0','88668','N','Admin','9','','','','','1','2026-01-04 20:23:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('263','OB','1','2026-01-01','','347332','0','N','Admin','67','','','','','1','2026-01-04 20:24:37','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('264','OB','1','2026-01-01','','0','347332','N','Admin','9','','','','','1','2026-01-04 20:24:37','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('265','SIN','10','2026-01-04','','15915.00','0','','Admin','100','2','12','','','1','2026-01-04 20:27:16','2026-01-04 20:27:16');
INSERT INTO `trn_dtl` VALUES ('266','SIN','10','2026-01-04','','6300.00','0','','Admin','67','2','13','','','1','2026-01-04 20:28:36','2026-01-04 20:57:12');
INSERT INTO `trn_dtl` VALUES ('267','OB','1','2026-01-01','','689487','0','N','Admin','68','','','','','1','2026-01-04 20:29:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('268','OB','1','2026-01-01','','0','689487','N','Admin','9','','','','','1','2026-01-04 20:29:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('269','SIN','10','2026-01-04','','69380.20','0','','Admin','68','2','14','','','1','2026-01-04 20:30:34','2026-01-04 20:55:13');
INSERT INTO `trn_dtl` VALUES ('270','OB','1','2026-01-01','','149620','0','N','Admin','48','','','','','1','2026-01-05 16:38:36','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('271','OB','1','2026-01-01','','0','149620','N','Admin','9','','','','','1','2026-01-05 16:38:36','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('272','OB','1','2026-01-01','','39600','0','N','Admin','136','','','','','1','2026-01-06 18:40:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('273','OB','1','2026-01-01','','0','39600','N','Admin','9','','','','','1','2026-01-06 18:40:15','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('274','SIN','10','2026-01-06','','16848.00','0','','Admin','136','2','15','','','1','2026-01-06 18:42:24','2026-01-06 19:58:41');
INSERT INTO `trn_dtl` VALUES ('275','OB','1','2026-01-01','','5612','0','N','Admin','131','','','','','1','2026-01-06 19:12:45','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('276','OB','1','2026-01-01','','0','5612','N','Admin','9','','','','','1','2026-01-06 19:12:45','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('277','SIN','10','2026-01-06','','32037.77','0','','Admin','131','2','16','','','1','2026-01-06 19:40:49','2026-01-06 19:41:52');
INSERT INTO `trn_dtl` VALUES ('280','OB','1','2026-01-01','','189033','0','N','Admin','49','','','','','1','2026-01-07 18:30:16','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('281','OB','1','2026-01-01','','0','189033','N','Admin','9','','','','','1','2026-01-07 18:30:16','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('282','OB','1','2026-01-01','','65561','0','N','Admin','50','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('283','OB','1','2026-01-01','','0','65561','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('284','OB','1','2026-01-01','','143670','0','N','Admin','51','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('285','OB','1','2026-01-01','','0','143670','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('286','OB','1','2026-01-01','','307647','0','N','Admin','53','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('287','OB','1','2026-01-01','','0','307647','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('288','OB','1','2026-01-01','','22755','0','N','Admin','52','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('289','OB','1','2026-01-01','','0','22755','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('290','OB','1','2026-01-01','','84977','0','N','Admin','54','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('291','OB','1','2026-01-01','','0','84977','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('292','OB','1','2026-01-01','','325980','0','N','Admin','56','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('293','OB','1','2026-01-01','','0','325980','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('294','OB','1','2026-01-01','','25696','0','N','Admin','57','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('295','OB','1','2026-01-01','','0','25696','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('296','OB','1','2026-01-01','','208699','0','N','Admin','58','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('297','OB','1','2026-01-01','','0','208699','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('298','OB','1','2026-01-01','','60839','0','N','Admin','59','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('299','OB','1','2026-01-01','','0','60839','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('300','OB','1','2026-01-01','','102801','0','N','Admin','130','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('301','OB','1','2026-01-01','','0','102801','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('302','OB','1','2026-01-01','','71213','0','N','Admin','122','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('303','OB','1','2026-01-01','','0','71213','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('304','OB','1','2026-01-01','','161050','0','N','Admin','123','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('305','OB','1','2026-01-01','','0','161050','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('307','CRV','2','2026-01-01','','0','20000.00','N','Admin','41','157','','','','1','2026-01-07 18:42:03','2026-01-07 18:42:03');
INSERT INTO `trn_dtl` VALUES ('308','CRV','3','2026-01-01','','0','30000.00','N','Admin','40','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('309','CRV','3','2026-01-01','','0','23000.00','N','Admin','42','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('310','CRV','3','2026-01-01','Meezan Bank','0','100000','N','Admin','44','157','','','','1','2026-01-07 18:50:14','2026-01-21 19:40:50');
INSERT INTO `trn_dtl` VALUES ('311','CRV','3','2026-01-01','','0','7000.00','N','Admin','47','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('312','CRV','3','2026-01-01','','0','20000.00','N','Admin','46','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('313','CRV','3','2026-01-01','','0','15000.00','N','Admin','51','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('314','CRV','3','2026-01-01','','0','21000.00','N','Admin','59','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('315','CRV','3','2026-01-01','','0','30000.00','N','Admin','37','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('316','CRV','3','2026-01-01','Meezan','0','20000.00','N','Admin','53','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('317','CRV','3','2026-01-01','HBL','0','35000.00','N','Admin','58','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('318','CRV','3','2026-01-01','Meezan','0','22700.00','N','Admin','52','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('319','CRV','3','2026-01-01','Meezan Bank','0','20000.00','N','Admin','39','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('321','SIN','17','2026-01-07','','19364.80','0','','Admin','51','2','17','','','1','2026-01-07 19:00:24','2026-01-07 19:00:24');
INSERT INTO `trn_dtl` VALUES ('322','SIN','10','2026-01-07','','16511.04','0','','Admin','52','2','18','','','1','2026-01-07 19:09:15','2026-01-07 19:09:15');
INSERT INTO `trn_dtl` VALUES ('323','SIN','10','2026-01-01','','9261.00','0','','Admin','122','2','19','','','1','2026-01-07 19:22:41','2026-01-07 19:22:41');
INSERT INTO `trn_dtl` VALUES ('325','SIN','10','2026-01-07','','21242.09','0','','Admin','47','2','21','','','1','2026-01-07 19:49:07','2026-01-07 19:49:07');
INSERT INTO `trn_dtl` VALUES ('327','SIN','10','2026-01-07','','9720.00','0','','Admin','41','2','23','','','1','2026-01-07 20:03:38','2026-01-07 20:03:38');
INSERT INTO `trn_dtl` VALUES ('328','SIN','10','2026-01-07','','48423.60','0','','Admin','40','2','24','','','1','2026-01-07 21:34:13','2026-01-07 21:34:13');
INSERT INTO `trn_dtl` VALUES ('329','SIN','10','2026-01-01','','8568.00','0','','Admin','53','2','25','','','1','2026-01-07 21:37:45','2026-01-07 21:37:45');
INSERT INTO `trn_dtl` VALUES ('331','SIN','26','2026-01-07','','70436.52','0','','Admin','43','2','26','','','1','2026-01-07 21:41:45','2026-01-07 21:41:45');
INSERT INTO `trn_dtl` VALUES ('332','SIN','10','2026-01-07','','11907.00','0','','Admin','38','2','27','','','1','2026-01-07 21:47:07','2026-01-07 21:47:07');
INSERT INTO `trn_dtl` VALUES ('333','SIN','20','2026-01-07','','48866.33','0','','Admin','37','2','20','','','1','2026-01-07 21:53:20','2026-01-07 21:53:20');
INSERT INTO `trn_dtl` VALUES ('334','CRV','4','2026-01-06','','0','20000.00','N','Admin','123','157','','','','1','2026-01-07 21:55:32','2026-01-07 21:55:32');
INSERT INTO `trn_dtl` VALUES ('335','SIN','10','2026-01-07','','90681.95','0','','Admin','123','2','28','','','1','2026-01-07 21:59:38','2026-01-07 21:59:38');
INSERT INTO `trn_dtl` VALUES ('336','OB','1','2026-01-01','','139963','0','N','Admin','118','','','','','1','2026-01-07 22:04:00','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('337','OB','1','2026-01-01','','0','139963','N','Admin','9','','','','','1','2026-01-07 22:04:00','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('339','SIN','10','2026-01-07','','111375.00','0','','Admin','132','2','30','','','1','2026-01-07 22:09:34','2026-01-07 22:09:34');
INSERT INTO `trn_dtl` VALUES ('340','OB','1','2026-01-01','','240680','0','N','Admin','124','','','','','1','2026-01-08 19:46:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('341','OB','1','2026-01-01','','0','240680','N','Admin','9','','','','','1','2026-01-08 19:46:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('342','OB','1','2026-01-01','','8348','0','N','Admin','65','','','','','1','2026-01-08 19:46:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('343','OB','1','2026-01-01','','0','8348','N','Admin','9','','','','','1','2026-01-08 19:46:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('344','OB','1','2026-01-01','','172654','0','N','Admin','66','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('345','OB','1','2026-01-01','','0','172654','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('346','OB','1','2026-01-01','','82662','0','N','Admin','70','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('347','OB','1','2026-01-01','','0','82662','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('348','OB','1','2026-01-01','','126441','0','N','Admin','71','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('349','OB','1','2026-01-01','','0','126441','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('350','OB','1','2026-01-01','','126307','0','N','Admin','74','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('351','OB','1','2026-01-01','','0','126307','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('352','OB','1','2026-01-01','','85590','0','N','Admin','78','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('353','OB','1','2026-01-01','','0','85590','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('354','OB','1','2026-01-01','','979451','0','N','Admin','29','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('355','OB','1','2026-01-01','','0','979451','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('356','OB','1','2026-01-01','','71461','0','N','Admin','79','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('357','OB','1','2026-01-01','','0','71461','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('358','OB','1','2026-01-01','','517418','0','N','Admin','98','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('359','OB','1','2026-01-01','','0','517418','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('360','OB','1','2026-01-01','','172039','0','N','Admin','104','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('361','OB','1','2026-01-01','','0','172039','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('362','OB','1','2026-01-01','','201957','0','N','Admin','105','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('363','OB','1','2026-01-01','','0','201957','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('364','OB','1','2026-01-01','','574335','0','N','Admin','80','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('365','OB','1','2026-01-01','','0','574335','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('366','OB','1','2026-01-01','','838626','0','N','Admin','81','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('367','OB','1','2026-01-01','','0','838626','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('373','CRV','5','2026-01-05','','0','50000.00','N','Admin','64','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('374','CRV','5','2026-01-05','','0','50000.00','N','Admin','87','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('375','CRV','5','2026-01-05','','0','30000.00','N','Admin','94','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('376','CRV','5','2026-01-05','','0','40000.00','N','Admin','67','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('377','CRV','5','2026-01-05','','0','15000.00','N','Admin','92','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('378','CRV','5','2026-01-05','','0','100000.00','N','Admin','68','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('380','CRV','5','2026-01-05','','0','60000.00','N','Admin','69','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('381','CRV','5','2026-01-05','','0','20000.00','N','Admin','73','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('382','SIN','10','2026-01-03','','15915.00','0','','Admin','158','2','33','','','1','2026-01-11 18:59:02','2026-01-11 18:59:02');
INSERT INTO `trn_dtl` VALUES ('383','OB','1','2026-01-01','','40723','0','N','Admin','158','','','','','1','2026-01-11 19:00:12','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('384','OB','1','2026-01-01','','0','40723','N','Admin','9','','','','','1','2026-01-11 19:00:12','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('385','CRV','6','2026-01-01','','0','15000.00','N','Admin','158','157','','','','1','2026-01-11 19:01:03','2026-01-11 19:01:03');
INSERT INTO `trn_dtl` VALUES ('386','CRV','7','2026-01-11','','0','89500.00','N','Admin','133','157','','','','1','2026-01-11 19:20:21','2026-01-11 19:20:21');
INSERT INTO `trn_dtl` VALUES ('387','CRV','8','2026-01-05','','0','20000.00','N','Admin','73','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('388','CRV','8','2026-01-05','','0','13000.00','N','Admin','158','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('389','CRV','8','2026-01-05','','0','30000.00','N','Admin','71','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('390','CRV','8','2026-01-05','','0','30000.00','N','Admin','79','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('391','CRV','8','2026-01-05','','0','60000.00','N','Admin','81','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('392','CRV','8','2026-01-05','','0','100000.00','N','Admin','80','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('393','CRV','8','2026-01-05','','0','50000.00','N','Admin','72','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('394','CRV','8','2026-01-05','','0','50000.00','N','Admin','98','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('395','CRV','8','2026-01-05','','0','25000.00','N','Admin','105','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('396','CRV','9','2026-01-07','','0','20000.00','N','Admin','89','157','','','','1','2026-01-11 20:42:02','2026-01-11 20:42:02');
INSERT INTO `trn_dtl` VALUES ('397','CRV','9','2026-01-07','','0','100000.00','N','Admin','29','157','','','','1','2026-01-11 20:42:02','2026-01-11 20:42:02');
INSERT INTO `trn_dtl` VALUES ('398','OB','1','2026-01-01','','96303','0','N','Admin','159','','','','','1','2026-01-11 20:50:30','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('399','OB','1','2026-01-01','','0','96303','N','Admin','9','','','','','1','2026-01-11 20:50:30','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('400','CRV','10','2026-01-11','','0','50000.00','N','Admin','159','157','','','','1','2026-01-11 20:54:31','2026-01-11 20:54:31');
INSERT INTO `trn_dtl` VALUES ('401','CRV','10','2026-01-11','','0','30000.00','N','Admin','85','157','','','','1','2026-01-11 20:54:31','2026-01-11 20:54:31');
INSERT INTO `trn_dtl` VALUES ('402','CRV','11','2026-01-04','','0','150000.00','N','Admin','82','157','','','','1','2026-01-11 20:54:52','2026-01-11 20:54:52');
INSERT INTO `trn_dtl` VALUES ('403','CRV','10','2026-01-11','','0','150000','N','Admin','82','157','','','','1','2026-01-11 20:56:04','2026-01-11 20:56:04');
INSERT INTO `trn_dtl` VALUES ('404','CRV','11','2026-01-08','','0','30000.00','N','Admin','85','157','','','','1','2026-01-11 20:56:43','2026-01-11 20:56:43');
INSERT INTO `trn_dtl` VALUES ('405','CRV','11','2026-01-08','','0','59000.00','N','Admin','74','157','','','','1','2026-01-11 20:56:43','2026-01-11 20:56:43');
INSERT INTO `trn_dtl` VALUES ('408','OB','1','2026-01-01','','167363','0','N','Admin','94','','','','','1','2026-01-11 21:13:51','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('409','OB','1','2026-01-01','','0','167363','N','Admin','9','','','','','1','2026-01-11 21:13:51','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('410','SIN','35','2026-01-11','','92475.00','0','','Admin','94','2','35','','','1','2026-01-11 21:14:32','2026-01-11 21:14:32');
INSERT INTO `trn_dtl` VALUES ('411','SIN','10','2026-01-11','','21420.00','0','','Admin','66','2','36','','','1','2026-01-11 21:22:25','2026-01-11 21:22:25');
INSERT INTO `trn_dtl` VALUES ('412','SIN','10','2026-01-11','','40500.00','0','','Admin','73','2','37','','','1','2026-01-11 21:27:23','2026-01-11 21:27:23');
INSERT INTO `trn_dtl` VALUES ('413','SIN','10','2026-01-11','','58292.40','0','','Admin','158','2','38','','','1','2026-01-11 21:31:39','2026-01-11 21:31:39');
INSERT INTO `trn_dtl` VALUES ('415','SIN','39','2026-01-11','','165618.00','0','','Admin','75','2','39','','','1','2026-01-11 21:42:12','2026-01-11 21:42:12');
INSERT INTO `trn_dtl` VALUES ('417','OB','1','2026-01-01','','90181','0','N','Admin','90','','','','','1','2026-01-11 22:20:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('418','OB','1','2026-01-01','','0','90181','N','Admin','9','','','','','1','2026-01-11 22:20:57','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('419','SIN','10','2026-01-11','','6300.00','0','','Admin','90','2','41','','','1','2026-01-11 22:21:51','2026-01-11 22:21:51');
INSERT INTO `trn_dtl` VALUES ('420','SIN','10','2026-01-11','','66765.00','0','','Admin','72','2','42','','','1','2026-01-11 22:31:11','2026-01-11 22:31:11');
INSERT INTO `trn_dtl` VALUES ('421','SIN','10','2026-01-11','','24300.00','0','','Admin','79','2','43','','','1','2026-01-11 22:35:04','2026-01-11 22:35:04');
INSERT INTO `trn_dtl` VALUES ('424','SIN','10','2026-01-11','','157685.10','0','','Admin','87','2','45','','','1','2026-01-11 22:51:27','2026-01-11 22:51:27');
INSERT INTO `trn_dtl` VALUES ('425','OB','1','2026-01-01','','59575','0','N','Admin','89','','','','','1','2026-01-11 22:54:46','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('426','OB','1','2026-01-01','','0','59575','N','Admin','9','','','','','1','2026-01-11 22:54:46','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('427','SIN','10','2026-01-11','','16830.00','0','','Admin','89','2','46','','','1','2026-01-11 22:55:45','2026-01-11 22:55:45');
INSERT INTO `trn_dtl` VALUES ('428','SIN','44','2026-01-11','','78210.00','0','','Admin','85','2','44','','','1','2026-01-11 22:57:34','2026-01-11 22:57:34');
INSERT INTO `trn_dtl` VALUES ('429','SIN','10','2026-01-11','','43530.00','0','','Admin','69','2','47','','','1','2026-01-11 23:01:38','2026-01-11 23:01:38');
INSERT INTO `trn_dtl` VALUES ('430','CRV','12','2026-01-11','','0','20000.00','N','Admin','99','157','','','','1','2026-01-11 23:04:45','2026-01-11 23:04:45');
INSERT INTO `trn_dtl` VALUES ('431','OB','1','2026-01-01','','53566','0','N','Admin','99','','','','','1','2026-01-11 23:09:53','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('432','OB','1','2026-01-01','','0','53566','N','Admin','9','','','','','1','2026-01-11 23:09:53','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('433','SIN','10','2026-01-11','','37665.00','0','','Admin','99','2','48','','','1','2026-01-11 23:10:39','2026-01-11 23:10:39');
INSERT INTO `trn_dtl` VALUES ('435','SIN','10','2026-01-11','','40305.60','0','','Admin','104','2','50','','','1','2026-01-11 23:23:47','2026-01-11 23:23:47');
INSERT INTO `trn_dtl` VALUES ('436','OB','1','2026-01-01','','58020','0','N','Admin','92','','','','','1','2026-01-11 23:29:28','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('437','OB','1','2026-01-01','','0','58020','N','Admin','9','','','','','1','2026-01-11 23:29:28','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('438','SIN','10','2026-01-11','','7500.00','0','','Admin','92','2','51','','','1','2026-01-11 23:30:31','2026-01-11 23:30:31');
INSERT INTO `trn_dtl` VALUES ('439','SIN','10','2026-01-11','','24300.00','0','','Admin','160','2','52','','','1','2026-01-11 23:32:31','2026-01-11 23:32:31');
INSERT INTO `trn_dtl` VALUES ('442','SIN','10','2026-01-11','','157068.00','0','','Admin','81','2','54','','','1','2026-01-11 23:41:33','2026-01-11 23:41:33');
INSERT INTO `trn_dtl` VALUES ('443','SIN','10','2026-01-11','','70842.60','0','','Admin','105','2','55','','','1','2026-01-11 23:45:14','2026-01-11 23:45:14');
INSERT INTO `trn_dtl` VALUES ('446','SIN','10','2026-01-11','','17280.00','0','','Admin','100','2','57','','','1','2026-01-11 23:54:27','2026-01-11 23:54:27');
INSERT INTO `trn_dtl` VALUES ('449','CRV','13','2026-01-11','','0','272000.00','N','Admin','29','157','','','','1','2026-01-11 23:58:56','2026-01-11 23:58:56');
INSERT INTO `trn_dtl` VALUES ('451','SIN','59','2026-01-11','','44436.00','0','','Admin','29','2','59','','','1','2026-01-12 00:00:40','2026-01-12 00:00:40');
INSERT INTO `trn_dtl` VALUES ('452','SIN','10','2026-01-12','','6415.20','0','','Admin','70','2','60','','','1','2026-01-12 00:03:06','2026-01-12 00:03:06');
INSERT INTO `trn_dtl` VALUES ('454','SIN','61','2026-01-12','','99360.00','0','','Admin','74','2','61','','','1','2026-01-12 00:05:58','2026-01-12 00:05:58');
INSERT INTO `trn_dtl` VALUES ('455','SIN','10','2026-01-12','','27382.50','0','','Admin','67','2','62','','','1','2026-01-12 00:09:16','2026-01-12 00:09:16');
INSERT INTO `trn_dtl` VALUES ('456','SIN','10','2026-01-12','','78300.00','0','','Admin','64','2','63','','','1','2026-01-12 00:12:34','2026-01-12 00:12:34');
INSERT INTO `trn_dtl` VALUES ('457','SIN','10','2026-01-12','','87000.00','0','','Admin','159','2','64','','','1','2026-01-12 00:16:04','2026-01-12 00:16:04');
INSERT INTO `trn_dtl` VALUES ('459','OB','1','2026-01-01','','204100','0','N','Admin','91','','','','','1','2026-01-12 00:21:32','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('460','OB','1','2026-01-01','','0','204100','N','Admin','9','','','','','1','2026-01-12 00:21:32','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('461','SIN','10','2026-01-11','','105300.00','0','','Admin','91','2','65','','','1','2026-01-12 00:25:02','2026-01-12 00:25:02');
INSERT INTO `trn_dtl` VALUES ('462','SIN','40','2026-01-11','','308208.00','0','','Admin','82','2','40','','','1','2026-01-12 11:27:12','2026-01-12 11:27:12');
INSERT INTO `trn_dtl` VALUES ('463','SIN','49','2026-01-06','','141298.50','0','','Admin','98','2','49','','','1','2026-01-12 11:28:09','2026-01-12 11:28:09');
INSERT INTO `trn_dtl` VALUES ('464','SIN','56','2026-01-11','','50516.55','0','','Admin','68','2','56','','','1','2026-01-12 11:28:59','2026-01-12 11:28:59');
INSERT INTO `trn_dtl` VALUES ('465','SIN','58','2026-01-11','','54712.80','0','','Admin','80','2','58','','','1','2026-01-12 11:29:24','2026-01-12 11:29:24');
INSERT INTO `trn_dtl` VALUES ('466','SIN','10','2026-01-12','','16470.00','0','','Admin','163','2','66','','','1','2026-01-12 18:41:05','2026-01-12 18:41:05');
INSERT INTO `trn_dtl` VALUES ('467','SIN','10','2026-01-12','','31730.40','0','','Admin','152','2','67','','','1','2026-01-12 20:21:18','2026-01-12 20:21:18');
INSERT INTO `trn_dtl` VALUES ('468','OB','1','2026-01-01','','238711','0','N','Admin','119','','','','','1','2026-01-13 21:20:44','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('469','OB','1','2026-01-01','','0','238711','N','Admin','9','','','','','1','2026-01-13 21:20:44','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('470','CRV','15','2026-01-06','','0','50000.00','N','Admin','119','157','','','','1','2026-01-13 21:21:26','2026-01-13 21:21:26');
INSERT INTO `trn_dtl` VALUES ('471','SIN','10','2026-01-13','','73191.60','0','','Admin','119','2','68','','','1','2026-01-13 21:24:51','2026-01-13 21:24:51');
INSERT INTO `trn_dtl` VALUES ('472','OB','1','2026-01-01','','29494','0','N','Admin','147','','','','','1','2026-01-13 21:28:27','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('473','OB','1','2026-01-01','','0','29494','N','Admin','9','','','','','1','2026-01-13 21:28:27','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('475','CRV','16','2026-01-08','','0','25000.00','N','Admin','122','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('476','CRV','16','2026-01-08','','0','30000.00','N','Admin','40','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('477','CRV','16','2026-01-08','','0','20000.00','N','Admin','41','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('478','CRV','16','2026-01-08','','0','20000.00','N','Admin','42','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('479','CRV','16','2026-01-08','','0','200000.00','N','Admin','43','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('480','CRV','16','2026-01-08','','0','100000.00','N','Admin','44','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('481','CRV','16','2026-01-08','','0','10000.00','N','Admin','45','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('482','CRV','16','2026-01-08','','0','10000.00','N','Admin','47','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('483','CRV','16','2026-01-08','','0','10000.00','N','Admin','49','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('484','CRV','16','2026-01-08','','0','10000.00','N','Admin','50','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('485','CRV','16','2026-01-08','','0','10000.00','N','Admin','46','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('486','CRV','16','2026-01-08','','0','20000.00','N','Admin','51','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('487','CRV','16','2026-01-08','','0','5000.00','N','Admin','54','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('488','CRV','16','2026-01-08','','0','50000.00','N','Admin','56','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('489','CRV','16','2026-01-08','','0','9000.00','N','Admin','59','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('490','CRV','16','2026-01-08','','0','35000.00','N','Admin','37','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('491','CRV','16','2026-01-08','','0','20000.00','N','Admin','53','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('492','CRV','16','2026-01-08','','0','25000.00','N','Admin','58','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('493','CRV','16','2026-01-08','','0','16500.00','N','Admin','52','157','','','','1','2026-01-14 19:15:21','2026-01-14 19:15:21');
INSERT INTO `trn_dtl` VALUES ('496','SIN','70','2026-01-14','','52690.68','0','','Admin','37','2','70','','','1','2026-01-14 19:21:29','2026-01-14 19:21:29');
INSERT INTO `trn_dtl` VALUES ('497','SIN','10','2026-01-14','','13494.60','0','','Admin','38','2','71','','','1','2026-01-14 19:25:46','2026-01-14 19:25:46');
INSERT INTO `trn_dtl` VALUES ('499','SIN','72','2026-01-14','','13494.60','0','','Admin','52','2','72','','','1','2026-01-14 19:27:59','2026-01-14 19:27:59');
INSERT INTO `trn_dtl` VALUES ('501','SIN','10','2026-01-14','','22755.60','0','','Admin','49','2','74','','','1','2026-01-14 19:36:57','2026-01-14 19:36:57');
INSERT INTO `trn_dtl` VALUES ('502','SIN','10','2026-01-14','','42777.00','0','','Admin','43','2','75','','','1','2026-01-14 19:39:31','2026-01-14 19:39:31');
INSERT INTO `trn_dtl` VALUES ('503','SIN','10','2026-01-14','','15876.00','0','','Admin','50','2','76','','','1','2026-01-14 19:42:02','2026-01-14 19:42:02');
INSERT INTO `trn_dtl` VALUES ('506','SIN','10','2026-01-14','','24152.69','0','','Admin','53','2','78','','','1','2026-01-14 19:53:34','2026-01-14 19:53:34');
INSERT INTO `trn_dtl` VALUES ('507','SIN','77','2026-01-14','','23166.00','0','','Admin','40','2','77','','','1','2026-01-14 19:54:50','2026-01-14 19:54:50');
INSERT INTO `trn_dtl` VALUES ('508','SIN','10','2026-01-14','','7200.00','0','','Admin','41','2','79','','','1','2026-01-14 20:01:11','2026-01-14 20:01:11');
INSERT INTO `trn_dtl` VALUES ('510','SIN','69','2026-01-13','','80240.80','0','','Admin','147','2','69','','','1','2026-01-14 20:05:34','2026-01-14 20:05:34');
INSERT INTO `trn_dtl` VALUES ('511','SIN','10','2026-01-14','','8279.04','0','','Admin','59','2','81','','','1','2026-01-14 20:18:44','2026-01-14 20:18:44');
INSERT INTO `trn_dtl` VALUES ('513','CRV','17','2026-01-15','','0','100000.00','N','Admin','91','157','','','','1','2026-01-15 20:01:51','2026-01-15 20:01:51');
INSERT INTO `trn_dtl` VALUES ('514','CRV','18','2026-01-12','','0','50000.00','N','Admin','64','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('515','CRV','18','2026-01-12','','0','60000.00','N','Admin','87','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('516','CRV','18','2026-01-12','JazzCash','0','25000.00','N','Admin','87','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('517','CRV','18','2026-01-12','','0','18000.00','N','Admin','98','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('518','CRV','18','2026-01-12','Raast','0','32000.00','N','Admin','98','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('519','CRV','18','2026-01-12','JazzCash','0','15000.00','N','Admin','92','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('520','CRV','18','2026-01-12','','0','30000.00','N','Admin','66','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('521','CRV','18','2026-01-12','Faisal','0','70000.00','N','Admin','83','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('522','CRV','18','2026-01-12','','0','40000.00','N','Admin','69','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('523','CRV','18','2026-01-12','','0','30000.00','N','Admin','73','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('524','CRV','18','2026-01-12','','0','100000.00','N','Admin','75','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('525','CRV','18','2026-01-12','','0','50000.00','N','Admin','85','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('526','CRV','18','2026-01-12','','0','50000.00','N','Admin','74','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('527','CRV','18','2026-01-12','','0','130000.00','N','Admin','81','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('528','CRV','18','2026-01-12','','0','50000.00','N','Admin','72','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('529','CRV','18','2026-01-12','Meezan','0','20000.00','N','Admin','72','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('530','CRV','18','2026-01-12','','0','30000.00','N','Admin','86','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('531','CRV','18','2026-01-12','','0','15000.00','N','Admin','70','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('532','CRV','18','2026-01-12','Meezan','0','20000.00','N','Admin','78','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('533','CRV','18','2026-01-12','','0','3940.00','N','Admin','98','157','','','','1','2026-01-18 18:16:10','2026-01-18 19:59:30');
INSERT INTO `trn_dtl` VALUES ('534','CRV','18','2026-01-12','Raast','0','30000.00','N','Admin','105','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('535','CRV','18','2026-01-12','','0','25000.00','N','Admin','90','157','','','','1','2026-01-18 18:16:10','2026-01-18 18:16:10');
INSERT INTO `trn_dtl` VALUES ('536','CRV','19','2026-01-15','','0','30000.00','N','Admin','77','157','','','','1','2026-01-18 18:18:04','2026-01-18 18:18:04');
INSERT INTO `trn_dtl` VALUES ('537','SIN','10','2026-01-18','','57600.00','0','','Admin','72','2','82','','','1','2026-01-18 18:33:20','2026-01-18 18:33:20');
INSERT INTO `trn_dtl` VALUES ('541','CRV','20','2026-01-12','','0','16470.00','N','Admin','163','157','','','','1','2026-01-18 18:46:36','2026-01-18 18:46:36');
INSERT INTO `trn_dtl` VALUES ('542','SIN','10','2026-01-12','','78937.20','0','','Admin','75','2','84','','','1','2026-01-18 18:57:21','2026-01-18 18:57:21');
INSERT INTO `trn_dtl` VALUES ('543','SIN','10','2026-01-18','','24300.00','0','','Admin','70','2','85','','','1','2026-01-18 19:03:34','2026-01-18 19:03:34');
INSERT INTO `trn_dtl` VALUES ('544','SIN','10','2026-01-18','','22402.50','0','','Admin','73','2','86','','','1','2026-01-18 19:08:58','2026-01-18 19:08:58');
INSERT INTO `trn_dtl` VALUES ('545','SIN','10','2026-01-18','','14700.00','0','','Admin','92','2','87','','','1','2026-01-18 19:17:39','2026-01-18 19:17:39');
INSERT INTO `trn_dtl` VALUES ('546','SIN','10','2026-01-18','','107931.60','0','','Admin','81','2','88','','','1','2026-01-18 19:24:56','2026-01-18 19:24:56');
INSERT INTO `trn_dtl` VALUES ('547','SIN','10','2026-01-18','','105516.00','0','','Admin','66','2','89','','','1','2026-01-18 19:29:26','2026-01-18 19:29:26');
INSERT INTO `trn_dtl` VALUES ('549','SIN','90','2026-01-18','','37620.00','0','','Admin','78','2','90','','','1','2026-01-18 19:40:34','2026-01-18 19:40:34');
INSERT INTO `trn_dtl` VALUES ('550','SIN','91','2026-01-18','','33696.00','0','','Admin','105','2','91','','','1','2026-01-18 19:46:19','2026-01-18 19:46:19');
INSERT INTO `trn_dtl` VALUES ('551','SIN','92','2026-01-18','','41504.40','0','','Admin','101','2','92','','','1','2026-01-18 19:53:59','2026-01-18 19:53:59');
INSERT INTO `trn_dtl` VALUES ('553','SIN','93','2026-01-18','','32130.00','0','','Admin','98','2','93','','','1','2026-01-18 20:01:27','2026-01-18 20:01:27');
INSERT INTO `trn_dtl` VALUES ('554','SIN','94','2026-01-18','','48870.00','0','','Admin','90','2','94','','','1','2026-01-18 20:05:44','2026-01-18 20:05:44');
INSERT INTO `trn_dtl` VALUES ('555','OB','1','2026-01-01','','45440','0','N','Admin','86','','','','','1','2026-01-18 20:08:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('556','OB','1','2026-01-01','','0','45440','N','Admin','9','','','','','1','2026-01-18 20:08:33','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('557','SIN','95','2026-01-18','','12150.00','0','','Admin','86','2','95','','','1','2026-01-18 20:09:22','2026-01-18 20:09:22');
INSERT INTO `trn_dtl` VALUES ('559','SIN','96','2026-01-18','','20790.00','0','','Admin','67','2','96','','','1','2026-01-18 20:11:22','2026-01-18 20:11:22');
INSERT INTO `trn_dtl` VALUES ('561','SIN','8','2026-01-04','','63795.00','0','','Admin','87','2','8','','','1','2026-01-18 20:22:11','2026-01-18 20:22:11');
INSERT INTO `trn_dtl` VALUES ('562','SIN','98','2026-01-18','','50520.00','0','','Admin','87','2','98','','','1','2026-01-18 20:23:52','2026-01-18 20:23:52');
INSERT INTO `trn_dtl` VALUES ('564','SIN','99','2026-01-18','','101685.00','0','','Admin','82','2','99','','','1','2026-01-18 20:34:08','2026-01-18 20:34:08');
INSERT INTO `trn_dtl` VALUES ('569','CRV','22','2026-01-05','','0','30000.00','N','Admin','100','157','','','','1','2026-01-18 20:50:04','2026-01-18 20:50:04');
INSERT INTO `trn_dtl` VALUES ('570','CRV','23','2026-01-12','','0','50000.00','N','Admin','100','157','','','','1','2026-01-18 20:50:27','2026-01-18 20:50:27');
INSERT INTO `trn_dtl` VALUES ('571','SIN','100','2026-01-13','','167196.60','0','','Admin','100','2','101','','','1','2026-01-18 20:55:58','2026-01-18 20:55:58');
INSERT INTO `trn_dtl` VALUES ('573','SIN','102','2026-01-18','','107625.60','0','','Admin','77','2','102','','','1','2026-01-18 23:39:12','2026-01-18 23:39:12');
INSERT INTO `trn_dtl` VALUES ('574','SIN','83','2026-01-18','','69380.40','0','','Admin','85','2','83','','','1','2026-01-18 23:40:13','2026-01-18 23:40:13');
INSERT INTO `trn_dtl` VALUES ('575','SIN','100','2026-01-18','','54816.30','0','','Admin','68','2','103','','','1','2026-01-18 23:46:13','2026-01-18 23:46:13');
INSERT INTO `trn_dtl` VALUES ('576','SIN','100','2026-01-18','','118368.00','0','','Admin','80','2','104','','','1','2026-01-18 23:50:34','2026-01-18 23:50:34');
INSERT INTO `trn_dtl` VALUES ('577','SIN','100','2026-01-18','','47745.00','0','','Admin','69','2','105','','','1','2026-01-18 23:54:17','2026-01-18 23:54:17');
INSERT INTO `trn_dtl` VALUES ('578','CRV','24','2026-01-12','','0','50000.00','N','Admin','94','157','','','','1','2026-01-18 23:57:56','2026-01-18 23:57:56');
INSERT INTO `trn_dtl` VALUES ('579','SIN','100','2026-01-18','','14400.00','0','','Admin','94','2','106','','','1','2026-01-18 23:58:30','2026-01-18 23:58:30');
INSERT INTO `trn_dtl` VALUES ('580','SIN','100','2026-01-18','','31248.00','0','','Admin','29','2','107','','','1','2026-01-19 00:01:03','2026-01-19 00:01:03');
INSERT INTO `trn_dtl` VALUES ('581','SIN','100','2026-01-18','','23814.00','0','','Admin','71','2','108','','','1','2026-01-19 00:04:57','2026-01-19 00:04:57');
INSERT INTO `trn_dtl` VALUES ('582','OB','1','2026-01-01','','139708','0','N','Admin','88','','','','','1','2026-01-19 00:08:03','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('583','OB','1','2026-01-01','','0','139708','N','Admin','9','','','','','1','2026-01-19 00:08:03','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('584','CRV','25','2026-01-13','','0','139708.00','N','Admin','88','157','','','','1','2026-01-19 00:10:57','2026-01-19 00:10:57');
INSERT INTO `trn_dtl` VALUES ('586','SIN','100','2026-01-19','','7830.00','0','','Admin','64','2','110','','','1','2026-01-19 00:13:23','2026-01-19 00:13:23');
INSERT INTO `trn_dtl` VALUES ('587','CRV','26','2026-01-17','','0','30000.00','N','Admin','89','157','','','','1','2026-01-19 00:17:15','2026-01-19 00:17:15');
INSERT INTO `trn_dtl` VALUES ('588','SIN','100','2026-01-17','','22815.00','0','','Admin','89','2','111','','','1','2026-01-19 00:19:07','2026-01-19 00:19:07');
INSERT INTO `trn_dtl` VALUES ('589','SIN','100','2026-01-19','','75276.00','0','','Admin','136','2','112','','','1','2026-01-19 00:21:38','2026-01-19 00:21:38');
INSERT INTO `trn_dtl` VALUES ('592','SIN','109','2026-01-19','','148809.20','0','','Admin','88','2','109','','','1','2026-01-19 00:29:31','2026-01-19 00:29:31');
INSERT INTO `trn_dtl` VALUES ('593','OB','1','2026-01-01','','901833','0','N','Admin','110','','','','','1','2026-01-19 00:31:50','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('594','OB','1','2026-01-01','','0','901833','N','Admin','9','','','','','1','2026-01-19 00:31:50','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('595','CRV','27','2026-01-17','','0','850000.00','N','Admin','110','157','','','','1','2026-01-19 00:32:29','2026-01-19 00:32:29');
INSERT INTO `trn_dtl` VALUES ('597','SIN','73','2026-01-14','','27323.10','0','','Admin','45','2','73','','','1','2026-01-19 19:58:29','2026-01-19 19:58:29');
INSERT INTO `trn_dtl` VALUES ('598','OB','1','2026-01-01','','24852','0','N','Admin','137','','','','','1','2026-01-19 20:15:55','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('599','OB','1','2026-01-01','','0','24852','N','Admin','9','','','','','1','2026-01-19 20:15:55','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('600','CRV','28','2026-01-02','','0','25000.00','N','Admin','137','157','','','','1','2026-01-19 20:16:26','2026-01-19 20:16:26');
INSERT INTO `trn_dtl` VALUES ('601','SIN','100','2026-01-19','','18360.00','0','','Admin','137','2','113','','','1','2026-01-19 20:17:49','2026-01-19 20:17:49');
INSERT INTO `trn_dtl` VALUES ('602','CRV','29','2026-01-15','','0','25000.00','N','Admin','122','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('603','CRV','29','2026-01-15','','0','25000.00','N','Admin','40','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('604','CRV','29','2026-01-15','','0','20000.00','N','Admin','42','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('605','CRV','29','2026-01-15','Meezan','0','100000.00','N','Admin','44','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('606','CRV','29','2026-01-15','','0','7000.00','N','Admin','47','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('607','CRV','29','2026-01-15','','0','10000.00','N','Admin','49','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('608','CRV','29','2026-01-15','','0','10000.00','N','Admin','50','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('609','CRV','29','2026-01-15','','0','5000.00','N','Admin','54','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('610','CRV','29','2026-01-15','','0','55000.00','N','Admin','59','157','','','','1','2026-01-21 18:46:14','2026-01-21 18:46:14');
INSERT INTO `trn_dtl` VALUES ('611','CRV','30','2026-01-17','','0','20000.00','N','Admin','58','157','','','','1','2026-01-21 18:47:24','2026-01-21 18:49:07');
INSERT INTO `trn_dtl` VALUES ('612','CRV','31','2026-01-20','','0','20000.00','N','Admin','41','157','','','','1','2026-01-21 18:49:31','2026-01-21 19:29:12');
INSERT INTO `trn_dtl` VALUES ('613','CRV','31','2026-01-20','','0','150000.00','N','Admin','43','157','','','','1','2026-01-21 18:49:31','2026-01-21 18:49:31');
INSERT INTO `trn_dtl` VALUES ('615','SIN','100','2026-01-21','','21609.00','0','','Admin','45','2','115','','','1','2026-01-21 19:15:20','2026-01-21 19:15:20');
INSERT INTO `trn_dtl` VALUES ('616','SIN','100','2026-01-21','','51978.60','0','','Admin','122','2','116','','','1','2026-01-21 19:24:42','2026-01-21 19:24:42');
INSERT INTO `trn_dtl` VALUES ('617','SIN','114','2026-01-21','','202801.20','0','','Admin','43','2','114','','','1','2026-01-21 19:26:36','2026-01-21 19:26:36');
INSERT INTO `trn_dtl` VALUES ('618','SIN','100','2026-01-21','','18378.00','0','','Admin','41','2','117','','','1','2026-01-21 19:29:51','2026-01-21 19:29:51');
INSERT INTO `trn_dtl` VALUES ('619','SIN','100','2026-01-21','','21150.00','0','','Admin','40','2','118','','','1','2026-01-21 19:31:14','2026-01-21 19:31:14');
INSERT INTO `trn_dtl` VALUES ('620','SIN','100','2026-01-21','','11907.00','0','','Admin','49','2','119','','','1','2026-01-21 19:32:24','2026-01-21 19:32:24');
INSERT INTO `trn_dtl` VALUES ('621','SIN','100','2026-01-21','','191091.18','0','','Admin','44','2','120','','','1','2026-01-21 19:41:10','2026-01-21 19:41:10');
INSERT INTO `trn_dtl` VALUES ('622','SIN','100','2026-01-21','','170742.85','0','','Admin','58','2','121','','','1','2026-01-21 19:54:32','2026-01-21 19:54:32');
INSERT INTO `trn_dtl` VALUES ('625','SIN','32','2026-01-10','','78577.00','0','','Admin','133','2','32','','','1','2026-01-21 20:18:52','2026-01-21 20:18:52');
INSERT INTO `trn_dtl` VALUES ('626','SIN','100','2026-01-21','','78577.00','0','','Admin','133','2','122','','','1','2026-01-21 20:22:01','2026-01-21 20:22:01');
INSERT INTO `trn_dtl` VALUES ('628','CRV','32','2026-01-19','','0','27000.00','N','Admin','64','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('629','CRV','32','2026-01-19','Meezan','0','43000.00','N','Admin','64','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('630','CRV','32','2026-01-19','Meezan','0','60000.00','N','Admin','87','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('631','CRV','32','2026-01-19','','0','30000.00','N','Admin','94','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('632','CRV','32','2026-01-19','Meezan','0','60000.00','N','Admin','67','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('633','CRV','32','2026-01-19','JazzCash','0','20000.00','N','Admin','92','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('634','CRV','32','2026-01-19','Meezan','0','100000.00','N','Admin','68','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('635','CRV','32','2026-01-19','Meezan','0','300000.00','N','Admin','82','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('636','CRV','32','2026-01-19','','0','50000.00','N','Admin','69','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('637','CRV','32','2026-01-19','Meezan','0','10100.00','N','Admin','73','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('638','CRV','32','2026-01-19','','0','14900.00','N','Admin','73','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('639','CRV','32','2026-01-19','Meezan','0','20000.00','N','Admin','158','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('640','CRV','32','2026-01-19','','0','100000.00','N','Admin','75','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('641','CRV','32','2026-01-19','','0','35000.00','N','Admin','71','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('642','CRV','32','2026-01-19','','0','35000.00','N','Admin','79','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('643','CRV','32','2026-01-19','Meezan','0','100000.00','N','Admin','81','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('644','CRV','32','2026-01-19','Meezan','0','50000.00','N','Admin','84','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('645','CRV','32','2026-01-19','Meezan','0','50000.00','N','Admin','72','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('646','CRV','32','2026-01-19','Meezan','0','50000.00','N','Admin','98','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('647','CRV','32','2026-01-19','','0','20000.00','N','Admin','101','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('648','CRV','32','2026-01-19','','0','50000.00','N','Admin','100','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('649','CRV','32','2026-01-19','','0','30000.00','N','Admin','104','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('650','CRV','32','2026-01-19','Meezan','0','30000.00','N','Admin','105','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('651','CRV','32','2026-01-19','','0','25000.00','N','Admin','90','157','','','','1','2026-01-22 18:22:21','2026-01-22 18:22:21');
INSERT INTO `trn_dtl` VALUES ('652','CRV','33','2026-01-20','Meezan','0','50000.00','N','Admin','72','157','','','','1','2026-01-22 18:28:50','2026-01-22 18:28:50');
INSERT INTO `trn_dtl` VALUES ('655','CRV','35','2026-01-01','','0','50000.00','N','Admin','164','157','','','','1','2026-01-23 17:06:20','2026-01-23 17:06:20');
INSERT INTO `trn_dtl` VALUES ('656','SIN','100','2026-01-23','','17928.00','0','','Admin','164','2','123','','','1','2026-01-23 17:07:44','2026-01-23 17:07:44');
INSERT INTO `trn_dtl` VALUES ('657','CRV','36','2026-01-13','testing','0','13000.00','N','Admin','164','157','','','','1','2026-01-23 17:08:24','2026-01-23 17:08:24');
INSERT INTO `trn_dtl` VALUES ('658','SIN','22','2026-01-07','','9335.09','0','','Admin','39','2','22','','','1','2026-01-24 12:21:42','2026-01-24 12:21:42');
INSERT INTO `trn_dtl` VALUES ('660','SIN','124','2026-01-24','','98254.80','0','','Admin','68','2','124','','','1','2026-01-24 15:56:29','2026-01-24 15:56:29');
INSERT INTO `trn_dtl` VALUES ('661','SIN','100','2026-01-24','','15915.00','0','','Admin','92','2','125','','','1','2026-01-24 16:04:11','2026-01-24 16:04:11');
INSERT INTO `trn_dtl` VALUES ('663','OB','1','2026-01-01','','193204','0','N','Admin','83','','','','','1','2026-01-24 16:08:41','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('664','OB','1','2026-01-01','','0','193204','N','Admin','9','','','','','1','2026-01-24 16:08:41','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('665','SIN','126','2026-01-24','','79575.00','0','','Admin','83','2','126','','','1','2026-01-24 16:10:12','2026-01-24 16:10:12');
INSERT INTO `trn_dtl` VALUES ('667','SIN','127','2026-01-19','','124405.20','0','','Admin','64','2','127','','','1','2026-01-24 16:16:50','2026-01-24 16:16:50');
INSERT INTO `trn_dtl` VALUES ('669','SIN','100','2026-01-19','','12150.00','0','','Admin','66','2','129','','','1','2026-01-24 16:25:39','2026-01-24 16:25:39');
INSERT INTO `trn_dtl` VALUES ('671','SIN','130','2026-01-24','','79320.00','0','','Admin','94','2','130','','','1','2026-01-24 16:28:30','2026-01-24 16:28:30');
INSERT INTO `trn_dtl` VALUES ('672','SIN','100','2026-01-25','','117075.00','0','','Admin','72','2','131','','','1','2026-01-25 15:34:40','2026-01-25 15:34:40');
INSERT INTO `trn_dtl` VALUES ('673','SIN','100','2026-01-25','','94068.00','0','','Admin','80','2','132','','','1','2026-01-25 15:37:14','2026-01-25 15:37:14');
INSERT INTO `trn_dtl` VALUES ('674','SIN','100','2026-01-25','','30615.00','0','','Admin','73','2','133','','','1','2026-01-25 15:41:55','2026-01-25 15:41:55');
INSERT INTO `trn_dtl` VALUES ('675','SIN','100','2026-01-25','','7500.00','0','','Admin','89','2','134','','','1','2026-01-25 15:46:02','2026-01-25 15:46:02');
INSERT INTO `trn_dtl` VALUES ('676','SIN','100','2026-01-20','','12150.00','0','','Admin','75','2','135','','','1','2026-01-25 15:48:44','2026-01-25 15:48:44');
INSERT INTO `trn_dtl` VALUES ('677','SIN','100','2026-01-25','','8640.00','0','','Admin','86','2','136','','','1','2026-01-25 15:56:08','2026-01-25 15:56:08');
INSERT INTO `trn_dtl` VALUES ('678','SIN','100','2026-01-25','','36585.00','0','','Admin','98','2','137','','','1','2026-01-25 16:04:08','2026-01-25 16:04:08');
INSERT INTO `trn_dtl` VALUES ('679','SIN','100','2026-01-25','','12150.00','0','','Admin','105','2','138','','','1','2026-01-25 16:06:47','2026-01-25 16:06:47');
INSERT INTO `trn_dtl` VALUES ('680','CRV','37','2026-01-18','Breakage','0','5537.00','N','Admin','69','157','','','','1','2026-01-25 16:17:33','2026-01-25 16:17:33');
INSERT INTO `trn_dtl` VALUES ('681','SIN','100','2026-01-25','','35580.00','0','','Admin','69','2','139','','','1','2026-01-25 16:19:42','2026-01-25 16:19:42');
INSERT INTO `trn_dtl` VALUES ('682','SIN','100','2026-01-25','','32940.00','0','','Admin','90','2','140','','','1','2026-01-25 16:26:18','2026-01-25 16:26:18');
INSERT INTO `trn_dtl` VALUES ('683','SIN','100','2026-01-25','','128331.00','0','','Admin','71','2','141','','','1','2026-01-25 16:32:23','2026-01-25 16:32:23');
INSERT INTO `trn_dtl` VALUES ('684','SIN','100','2026-01-25','','66753.00','0','','Admin','67','2','142','','','1','2026-01-25 16:34:51','2026-01-25 16:34:51');
INSERT INTO `trn_dtl` VALUES ('685','SIN','100','2026-01-25','','15000.00','0','','Admin','158','2','143','','','1','2026-01-25 16:36:56','2026-01-25 16:36:56');
INSERT INTO `trn_dtl` VALUES ('686','SIN','100','2026-01-25','','86127.60','0','','Admin','82','2','144','','','1','2026-01-25 16:39:42','2026-01-25 16:39:42');
INSERT INTO `trn_dtl` VALUES ('687','SIN','100','2026-01-21','','65463.00','0','','Admin','29','2','145','','','1','2026-01-25 16:42:46','2026-01-25 16:42:46');
INSERT INTO `trn_dtl` VALUES ('688','OB','1','2026-01-01','','142823','0','N','Admin','84','','','','','1','2026-01-25 16:45:50','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('689','OB','1','2026-01-01','','0','142823','N','Admin','9','','','','','1','2026-01-25 16:45:50','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('690','SIN','100','2026-01-25','','115200.00','0','','Admin','84','2','146','','','1','2026-01-25 16:46:23','2026-01-25 16:46:23');
INSERT INTO `trn_dtl` VALUES ('691','SIN','100','2026-01-25','','136654.20','0','','Admin','29','2','147','','','1','2026-01-25 16:58:32','2026-01-25 16:58:32');
INSERT INTO `trn_dtl` VALUES ('694','SIN','149','2026-01-25','','137061.00','0','','Admin','82','2','149','','','1','2026-01-25 17:03:54','2026-01-25 17:03:54');
INSERT INTO `trn_dtl` VALUES ('696','SIN','100','2026-01-25','','7500.00','0','','Admin','92','2','151','','','1','2026-01-25 17:11:05','2026-01-25 17:11:05');
INSERT INTO `trn_dtl` VALUES ('697','SIN','100','2026-01-25','','172800.00','0','','Admin','84','2','152','','','1','2026-01-25 17:12:38','2026-01-25 17:12:38');
INSERT INTO `trn_dtl` VALUES ('698','SIN','100','2026-01-25','','16830.00','0','','Admin','90','2','153','','','1','2026-01-25 17:13:35','2026-01-25 17:13:35');
INSERT INTO `trn_dtl` VALUES ('699','SIN','100','2026-01-25','','43200.00','0','','Admin','85','2','154','','','1','2026-01-25 17:15:38','2026-01-25 17:15:38');
INSERT INTO `trn_dtl` VALUES ('700','CRV','38','2026-01-01','','0','7654.00','N','Admin','153','157','','','','1','2026-01-25 17:22:14','2026-01-25 17:22:14');
INSERT INTO `trn_dtl` VALUES ('701','SIN','100','2026-01-25','','24300.00','0','','Admin','153','2','155','','','1','2026-01-25 17:23:06','2026-01-25 17:23:06');
INSERT INTO `trn_dtl` VALUES ('707','SIN','157','2026-01-25','','33398.50','0','','Admin','166','2','157','','','1','2026-01-25 17:30:27','2026-01-25 17:30:27');
INSERT INTO `trn_dtl` VALUES ('708','SIN','100','2026-01-25','','246920.00','0','','Admin','91','2','158','','','1','2026-01-25 17:38:31','2026-01-25 17:38:31');
INSERT INTO `trn_dtl` VALUES ('709','SIN','156','2026-01-25','','24273.00','0','','Admin','165','2','156','','','1','2026-01-25 18:49:20','2026-01-25 18:49:20');
INSERT INTO `trn_dtl` VALUES ('710','SIN','150','2026-01-25','','55240.00','0','','Admin','72','2','150','','','1','2026-01-25 22:40:08','2026-01-25 22:40:08');
INSERT INTO `trn_dtl` VALUES ('711','SIN','128','2026-01-24','','66483.00','0','','Admin','87','2','128','','','1','2026-01-25 22:43:58','2026-01-25 22:43:58');
INSERT INTO `trn_dtl` VALUES ('712','SIN','31','2026-01-08','','45396.00','0','','Admin','109','2','31','','','1','2026-01-25 22:52:45','2026-01-25 22:52:45');
INSERT INTO `trn_dtl` VALUES ('713','SIN','100','2026-01-26','','82080.00','0','','Admin','81','2','159','','','1','2026-01-26 12:16:06','2026-01-26 12:16:06');
INSERT INTO `trn_dtl` VALUES ('715','SIN','160','2026-01-26','','33466.61','0','','Admin','145','2','160','','','1','2026-01-26 19:54:25','2026-01-26 19:54:25');
INSERT INTO `trn_dtl` VALUES ('716','OB','1','2026-01-01','','629419','0','N','Admin','103','','','','','1','2026-01-26 20:59:20','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('717','OB','1','2026-01-01','','0','629419','N','Admin','9','','','','','1','2026-01-26 20:59:20','2026-01-26 20:59:20');
INSERT INTO `trn_dtl` VALUES ('718','SIN','100','2026-01-26','','156158.00','0','','Admin','103','2','161','','','1','2026-01-26 21:18:14','2026-01-26 21:18:14');
INSERT INTO `trn_dtl` VALUES ('719','SIN','100','2026-01-26','','52328.70','0','','Admin','167','2','162','','','1','2026-01-26 21:38:14','2026-01-26 21:38:14');
INSERT INTO `trn_dtl` VALUES ('720','CRV','39','2026-01-26','','0','45400.00','N','Admin','109','157','','','','1','2026-01-27 19:30:51','2026-01-27 19:30:51');
INSERT INTO `trn_dtl` VALUES ('721','SIN','100','2026-01-27','','66348.00','0','','Admin','109','2','163','','','1','2026-01-27 19:34:44','2026-01-27 19:34:44');
INSERT INTO `trn_dtl` VALUES ('724','SIN','164','2026-01-27','','1741086.00','0','','Admin','110','2','164','','','1','2026-01-27 20:11:20','2026-01-27 20:11:20');
INSERT INTO `trn_dtl` VALUES ('725','SIN','100','2026-01-28','','16470.00','0','','Admin','163','2','165','','','1','2026-01-28 13:02:52','2026-01-28 13:02:52');
INSERT INTO `trn_dtl` VALUES ('726','CRV','40','2026-01-22','','0','25000.00','N','Admin','122','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('727','CRV','40','2026-01-22','','0','10000.00','N','Admin','41','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('728','CRV','40','2026-01-22','','0','15000.00','N','Admin','42','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('729','CRV','40','2026-01-22','','0','100000.00','N','Admin','44','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('730','CRV','40','2026-01-22','','0','15000.00','N','Admin','45','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('731','CRV','40','2026-01-22','','0','7000.00','N','Admin','47','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('732','CRV','40','2026-01-22','','0','15000.00','N','Admin','49','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('733','CRV','40','2026-01-22','','0','15000.00','N','Admin','51','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('734','CRV','40','2026-01-22','','0','5000.00','N','Admin','57','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('735','CRV','40','2026-01-22','','0','60000.00','N','Admin','59','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('736','CRV','40','2026-01-22','','0','30000.00','N','Admin','37','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('737','CRV','40','2026-01-22','','0','20000.00','N','Admin','53','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('738','CRV','40','2026-01-22','','0','5000.00','N','Admin','61','157','','','','1','2026-01-28 19:20:45','2026-01-28 19:20:45');
INSERT INTO `trn_dtl` VALUES ('739','CRV','40','2026-01-22','','0','20000','N','Admin','123','157','','','','1','2026-01-28 19:24:34','2026-01-28 19:24:34');
INSERT INTO `trn_dtl` VALUES ('740','CRV','41','2026-01-21','JazzCash','0','3500.00','N','Admin','40','157','','','','1','2026-01-28 19:26:21','2026-01-28 19:26:21');
INSERT INTO `trn_dtl` VALUES ('741','CRV','41','2026-01-21','JazzCash','0','20000.00','N','Admin','39','157','','','','1','2026-01-28 19:26:21','2026-01-28 19:26:21');
INSERT INTO `trn_dtl` VALUES ('742','CRV','39','2026-01-26','','0','20000','N','Admin','39','157','','','','1','2026-01-28 19:37:23','2026-01-28 19:37:23');
INSERT INTO `trn_dtl` VALUES ('743','CRV','40','2026-01-20','','0','10000.00','N','Admin','50','157','','','','1','2026-01-28 19:38:19','2026-01-28 19:38:19');
INSERT INTO `trn_dtl` VALUES ('744','CRV','40','2026-01-22','','0','20000','N','Admin','41','157','','','','1','2026-01-28 19:39:15','2026-01-28 19:39:15');
INSERT INTO `trn_dtl` VALUES ('745','CRV','41','2026-01-27','','0','20000.00','N','Admin','40','157','','','','1','2026-01-28 19:41:13','2026-01-28 19:41:13');
INSERT INTO `trn_dtl` VALUES ('746','CRV','42','2026-01-28','','0','150000.00','N','Admin','43','157','','','','1','2026-01-28 19:41:40','2026-01-28 19:41:40');
INSERT INTO `trn_dtl` VALUES ('748','SIN','166','2026-01-28','','43306.20','0','','Admin','50','2','166','','','1','2026-01-28 19:48:50','2026-01-28 19:48:50');
INSERT INTO `trn_dtl` VALUES ('749','SIN','100','2026-01-28','','60685.13','0','','Admin','37','2','167','','','1','2026-01-28 20:06:51','2026-01-28 20:06:51');
INSERT INTO `trn_dtl` VALUES ('751','SIN','100','2026-01-28','','37467.36','0','','Admin','51','2','168','','','1','2026-01-28 20:17:08','2026-01-28 20:17:08');
INSERT INTO `trn_dtl` VALUES ('752','SIN','100','2026-01-28','','29211.84','0','','Admin','46','2','169','','','1','2026-01-28 20:24:42','2026-01-28 20:24:42');
INSERT INTO `trn_dtl` VALUES ('754','SIN','170','2026-01-28','','39366.00','0','','Admin','40','2','170','','','1','2026-01-28 20:30:17','2026-01-28 20:30:17');
INSERT INTO `trn_dtl` VALUES ('755','SIN','100','2026-01-28','','41660.98','0','','Admin','49','2','171','','','1','2026-01-28 20:33:03','2026-01-28 20:33:03');
INSERT INTO `trn_dtl` VALUES ('757','SIN','172','2026-01-28','','51685.20','0','','Admin','60','2','172','','','1','2026-01-28 20:43:35','2026-01-28 20:43:35');
INSERT INTO `trn_dtl` VALUES ('758','SIN','100','2026-01-28','','12700.80','0','','Admin','47','2','173','','','1','2026-01-28 20:45:11','2026-01-28 20:45:11');
INSERT INTO `trn_dtl` VALUES ('759','SIN','100','2026-01-28','','62710.20','0','','Admin','53','2','174','','','1','2026-01-28 20:52:54','2026-01-28 20:52:54');
INSERT INTO `trn_dtl` VALUES ('760','SIN','100','2026-01-28','','52126.20','0','','Admin','57','2','175','','','1','2026-01-28 20:57:31','2026-01-28 20:57:31');
INSERT INTO `trn_dtl` VALUES ('761','SIN','100','2026-01-28','','122392.20','0','','Admin','43','2','176','','','1','2026-01-28 21:00:45','2026-01-28 21:00:45');
INSERT INTO `trn_dtl` VALUES ('762','SIN','100','2026-01-28','','47987.86','0','','Admin','39','2','177','','','1','2026-01-28 21:04:28','2026-01-28 21:04:28');
INSERT INTO `trn_dtl` VALUES ('763','SIN','100','2026-01-28','','17463.60','0','','Admin','45','2','178','','','1','2026-01-28 21:06:53','2026-01-28 21:06:53');
INSERT INTO `trn_dtl` VALUES ('764','SIN','100','2026-01-28','','8731.80','0','','Admin','38','2','179','','','1','2026-01-28 21:10:25','2026-01-28 21:10:25');
INSERT INTO `trn_dtl` VALUES ('766','CRV','43','2026-01-27','','0','16500.00','N','Admin','153','157','','','','1','2026-01-28 21:26:24','2026-01-28 21:26:24');
INSERT INTO `trn_dtl` VALUES ('767','SIN','100','2026-01-28','','38196.00','0','','Admin','153','2','181','','','1','2026-01-28 21:33:54','2026-01-28 21:33:54');
INSERT INTO `trn_dtl` VALUES ('768','SIN','100','2026-01-28','','36774.00','0','','Admin','139','2','182','','','1','2026-01-28 21:36:15','2026-01-28 21:36:15');
INSERT INTO `trn_dtl` VALUES ('769','SIN','180','2026-01-28','','37008.36','0','','Admin','122','2','180','','','1','2026-01-28 21:40:38','2026-01-28 21:40:38');
INSERT INTO `trn_dtl` VALUES ('770','SIN','29','2026-01-06','','31220.00','0','','Admin','118','2','29','','','1','2026-01-28 21:45:35','2026-01-28 21:45:35');
INSERT INTO `trn_dtl` VALUES ('771','SIN','100','2026-01-14','','23937.60','0','','Admin','118','2','183','','','1','2026-01-28 21:49:57','2026-01-28 21:49:57');
INSERT INTO `trn_dtl` VALUES ('772','SIN','100','2026-01-28','','66850.00','0','','Admin','118','2','184','','','1','2026-01-28 21:51:48','2026-01-28 21:51:48');


DROP TABLE IF EXISTS `trn_dtl_views`;
;

INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','28','','261000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','28','','202000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','6','','0','63000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','35','','1351.35','0','8','account');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','30','','83.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('197','3','SIN','2025-12-19','28','','20000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('202','1','OB','2026-01-01','101','','20917.8','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('203','1','OB','2026-01-01','9','','0','20917.8','1','account');
INSERT INTO `trn_dtl_views` VALUES ('204','1','OB','2026-01-01','37','','499253','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('205','1','OB','2026-01-01','9','','0','499253','1','account');
INSERT INTO `trn_dtl_views` VALUES ('206','1','OB','2026-01-01','38','','31471','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('207','1','OB','2026-01-01','9','','0','31471','1','account');
INSERT INTO `trn_dtl_views` VALUES ('208','1','OB','2026-01-01','39','','164862','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('209','1','OB','2026-01-01','9','','0','164862','1','account');
INSERT INTO `trn_dtl_views` VALUES ('210','1','OB','2026-01-01','40','','184701','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('211','1','OB','2026-01-01','9','','0','184701','1','account');
INSERT INTO `trn_dtl_views` VALUES ('212','1','OB','2026-01-01','41','','160979','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('213','1','OB','2026-01-01','9','','0','160979','1','account');
INSERT INTO `trn_dtl_views` VALUES ('214','1','OB','2026-01-01','42','','779710','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('215','1','OB','2026-01-01','9','','0','779710','1','account');
INSERT INTO `trn_dtl_views` VALUES ('216','1','OB','2026-01-01','43','','1453069','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('217','1','OB','2026-01-01','9','','0','1453069','1','account');
INSERT INTO `trn_dtl_views` VALUES ('218','1','OB','2026-01-01','44','','1250635','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('219','1','OB','2026-01-01','9','','0','1250635','1','account');
INSERT INTO `trn_dtl_views` VALUES ('220','1','OB','2026-01-01','45','','161041','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('221','1','OB','2026-01-01','9','','0','161041','1','account');
INSERT INTO `trn_dtl_views` VALUES ('222','1','OB','2026-01-01','46','','46399','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('223','1','OB','2026-01-01','9','','0','46399','1','account');
INSERT INTO `trn_dtl_views` VALUES ('224','1','OB','2026-01-01','47','','117515','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('225','1','OB','2026-01-01','9','','0','117515','1','account');
INSERT INTO `trn_dtl_views` VALUES ('226','1','OB','2026-01-01','114','','22106','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('227','1','OB','2026-01-01','9','','0','22106','1','account');
INSERT INTO `trn_dtl_views` VALUES ('228','1','SIN','2026-01-03','114','','19130.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('229','1','OB','2026-01-01','85','','114304','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('230','1','OB','2026-01-01','9','','0','114304','1','account');
INSERT INTO `trn_dtl_views` VALUES ('231','2','SIN','2026-01-04','85','','74760.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('232','1','OB','2026-01-01','64','','459343','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('233','1','OB','2026-01-01','9','','0','459343','1','account');
INSERT INTO `trn_dtl_views` VALUES ('234','3','SIN','2026-01-04','64','','7830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('235','1','OB','2026-01-01','75','','605118','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('236','1','OB','2026-01-01','9','','0','605118','1','account');
INSERT INTO `trn_dtl_views` VALUES ('237','4','SIN','2026-01-04','75','','45900.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('238','1','OB','2026-01-01','73','','197168','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('239','1','OB','2026-01-01','9','','0','197168','1','account');
INSERT INTO `trn_dtl_views` VALUES ('240','5','SIN','2026-01-04','73','','18630.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('241','1','OB','2026-01-01','77','','85143','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('242','1','OB','2026-01-01','9','','0','85143','1','account');
INSERT INTO `trn_dtl_views` VALUES ('243','6','SIN','2026-01-04','77','','48600.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('247','1','OB','2026-01-01','87','','110752','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('248','1','OB','2026-01-01','9','','0','110752','1','account');
INSERT INTO `trn_dtl_views` VALUES ('250','1','OB','2026-01-01','69','','332903','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('251','1','OB','2026-01-01','9','','0','332903','1','account');
INSERT INTO `trn_dtl_views` VALUES ('252','9','SIN','2026-01-04','69','','12915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('253','1','OB','2026-01-01','72','','206022','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('254','1','OB','2026-01-01','9','','0','206022','1','account');
INSERT INTO `trn_dtl_views` VALUES ('256','1','CRV','2026-01-03','72','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('257','10','SIN','2026-01-04','72','','83785.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('258','1','OB','2026-01-01','82','','1072290','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('259','1','OB','2026-01-01','9','','0','1072290','1','account');
INSERT INTO `trn_dtl_views` VALUES ('260','10','SIN','2026-01-04','82','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('261','1','OB','2026-01-01','100','','88668','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('262','1','OB','2026-01-01','9','','0','88668','1','account');
INSERT INTO `trn_dtl_views` VALUES ('263','1','OB','2026-01-01','67','','347332','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('264','1','OB','2026-01-01','9','','0','347332','1','account');
INSERT INTO `trn_dtl_views` VALUES ('265','10','SIN','2026-01-04','100','','15915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('266','10','SIN','2026-01-04','67','','6300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('267','1','OB','2026-01-01','68','','689487','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('268','1','OB','2026-01-01','9','','0','689487','1','account');
INSERT INTO `trn_dtl_views` VALUES ('269','10','SIN','2026-01-04','68','','69380.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('270','1','OB','2026-01-01','48','','149620','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('271','1','OB','2026-01-01','9','','0','149620','1','account');
INSERT INTO `trn_dtl_views` VALUES ('272','1','OB','2026-01-01','136','','39600','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('273','1','OB','2026-01-01','9','','0','39600','1','account');
INSERT INTO `trn_dtl_views` VALUES ('274','10','SIN','2026-01-06','136','','16848.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('275','1','OB','2026-01-01','131','','5612','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('276','1','OB','2026-01-01','9','','0','5612','1','account');
INSERT INTO `trn_dtl_views` VALUES ('277','10','SIN','2026-01-06','131','','32037.77','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('280','1','OB','2026-01-01','49','','189033','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('281','1','OB','2026-01-01','9','','0','189033','1','account');
INSERT INTO `trn_dtl_views` VALUES ('282','1','OB','2026-01-01','50','','65561','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('283','1','OB','2026-01-01','9','','0','65561','1','account');
INSERT INTO `trn_dtl_views` VALUES ('284','1','OB','2026-01-01','51','','143670','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('285','1','OB','2026-01-01','9','','0','143670','1','account');
INSERT INTO `trn_dtl_views` VALUES ('286','1','OB','2026-01-01','53','','307647','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('287','1','OB','2026-01-01','9','','0','307647','1','account');
INSERT INTO `trn_dtl_views` VALUES ('288','1','OB','2026-01-01','52','','22755','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('289','1','OB','2026-01-01','9','','0','22755','1','account');
INSERT INTO `trn_dtl_views` VALUES ('290','1','OB','2026-01-01','54','','84977','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('291','1','OB','2026-01-01','9','','0','84977','1','account');
INSERT INTO `trn_dtl_views` VALUES ('292','1','OB','2026-01-01','56','','325980','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('293','1','OB','2026-01-01','9','','0','325980','1','account');
INSERT INTO `trn_dtl_views` VALUES ('294','1','OB','2026-01-01','57','','25696','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('295','1','OB','2026-01-01','9','','0','25696','1','account');
INSERT INTO `trn_dtl_views` VALUES ('296','1','OB','2026-01-01','58','','208699','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('297','1','OB','2026-01-01','9','','0','208699','1','account');
INSERT INTO `trn_dtl_views` VALUES ('298','1','OB','2026-01-01','59','','60839','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('299','1','OB','2026-01-01','9','','0','60839','1','account');
INSERT INTO `trn_dtl_views` VALUES ('300','1','OB','2026-01-01','130','','102801','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('301','1','OB','2026-01-01','9','','0','102801','1','account');
INSERT INTO `trn_dtl_views` VALUES ('302','1','OB','2026-01-01','122','','71213','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('303','1','OB','2026-01-01','9','','0','71213','1','account');
INSERT INTO `trn_dtl_views` VALUES ('304','1','OB','2026-01-01','123','','161050','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('305','1','OB','2026-01-01','9','','0','161050','1','account');
INSERT INTO `trn_dtl_views` VALUES ('307','2','CRV','2026-01-01','41','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('308','3','CRV','2026-01-01','40','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('309','3','CRV','2026-01-01','42','','0','23000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('310','3','CRV','2026-01-01','44','Meezan Bank','0','100000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('311','3','CRV','2026-01-01','47','','0','7000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('312','3','CRV','2026-01-01','46','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('313','3','CRV','2026-01-01','51','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('314','3','CRV','2026-01-01','59','','0','21000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('315','3','CRV','2026-01-01','37','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('316','3','CRV','2026-01-01','53','Meezan','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('317','3','CRV','2026-01-01','58','HBL','0','35000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('318','3','CRV','2026-01-01','52','Meezan','0','22700.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('319','3','CRV','2026-01-01','39','Meezan Bank','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('321','17','SIN','2026-01-07','51','','19364.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('322','10','SIN','2026-01-07','52','','16511.04','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('323','10','SIN','2026-01-01','122','','9261.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('325','10','SIN','2026-01-07','47','','21242.09','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('327','10','SIN','2026-01-07','41','','9720.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('328','10','SIN','2026-01-07','40','','48423.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('329','10','SIN','2026-01-01','53','','8568.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('331','26','SIN','2026-01-07','43','','70436.52','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('332','10','SIN','2026-01-07','38','','11907.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('333','20','SIN','2026-01-07','37','','48866.33','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('334','4','CRV','2026-01-06','123','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('335','10','SIN','2026-01-07','123','','90681.95','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('336','1','OB','2026-01-01','118','','139963','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('337','1','OB','2026-01-01','9','','0','139963','1','account');
INSERT INTO `trn_dtl_views` VALUES ('339','10','SIN','2026-01-07','132','','111375.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('340','1','OB','2026-01-01','124','','240680','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('341','1','OB','2026-01-01','9','','0','240680','1','account');
INSERT INTO `trn_dtl_views` VALUES ('342','1','OB','2026-01-01','65','','8348','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('343','1','OB','2026-01-01','9','','0','8348','1','account');
INSERT INTO `trn_dtl_views` VALUES ('344','1','OB','2026-01-01','66','','172654','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('345','1','OB','2026-01-01','9','','0','172654','1','account');
INSERT INTO `trn_dtl_views` VALUES ('346','1','OB','2026-01-01','70','','82662','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('347','1','OB','2026-01-01','9','','0','82662','1','account');
INSERT INTO `trn_dtl_views` VALUES ('348','1','OB','2026-01-01','71','','126441','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('349','1','OB','2026-01-01','9','','0','126441','1','account');
INSERT INTO `trn_dtl_views` VALUES ('350','1','OB','2026-01-01','74','','126307','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('351','1','OB','2026-01-01','9','','0','126307','1','account');
INSERT INTO `trn_dtl_views` VALUES ('352','1','OB','2026-01-01','78','','85590','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('353','1','OB','2026-01-01','9','','0','85590','1','account');
INSERT INTO `trn_dtl_views` VALUES ('354','1','OB','2026-01-01','29','','979451','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('355','1','OB','2026-01-01','9','','0','979451','1','account');
INSERT INTO `trn_dtl_views` VALUES ('356','1','OB','2026-01-01','79','','71461','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('357','1','OB','2026-01-01','9','','0','71461','1','account');
INSERT INTO `trn_dtl_views` VALUES ('358','1','OB','2026-01-01','98','','517418','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('359','1','OB','2026-01-01','9','','0','517418','1','account');
INSERT INTO `trn_dtl_views` VALUES ('360','1','OB','2026-01-01','104','','172039','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('361','1','OB','2026-01-01','9','','0','172039','1','account');
INSERT INTO `trn_dtl_views` VALUES ('362','1','OB','2026-01-01','105','','201957','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('363','1','OB','2026-01-01','9','','0','201957','1','account');
INSERT INTO `trn_dtl_views` VALUES ('364','1','OB','2026-01-01','80','','574335','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('365','1','OB','2026-01-01','9','','0','574335','1','account');
INSERT INTO `trn_dtl_views` VALUES ('366','1','OB','2026-01-01','81','','838626','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('367','1','OB','2026-01-01','9','','0','838626','1','account');
INSERT INTO `trn_dtl_views` VALUES ('373','5','CRV','2026-01-05','64','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('374','5','CRV','2026-01-05','87','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('375','5','CRV','2026-01-05','94','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('376','5','CRV','2026-01-05','67','','0','40000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('377','5','CRV','2026-01-05','92','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('378','5','CRV','2026-01-05','68','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('380','5','CRV','2026-01-05','69','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('381','5','CRV','2026-01-05','73','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('382','10','SIN','2026-01-03','158','','15915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('383','1','OB','2026-01-01','158','','40723','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('384','1','OB','2026-01-01','9','','0','40723','1','account');
INSERT INTO `trn_dtl_views` VALUES ('385','6','CRV','2026-01-01','158','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('386','7','CRV','2026-01-11','133','','0','89500.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('387','8','CRV','2026-01-05','73','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('388','8','CRV','2026-01-05','158','','0','13000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('389','8','CRV','2026-01-05','71','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('390','8','CRV','2026-01-05','79','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('391','8','CRV','2026-01-05','81','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('392','8','CRV','2026-01-05','80','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('393','8','CRV','2026-01-05','72','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('394','8','CRV','2026-01-05','98','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('395','8','CRV','2026-01-05','105','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('396','9','CRV','2026-01-07','89','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('397','9','CRV','2026-01-07','29','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('398','1','OB','2026-01-01','159','','96303','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('399','1','OB','2026-01-01','9','','0','96303','1','account');
INSERT INTO `trn_dtl_views` VALUES ('400','10','CRV','2026-01-11','159','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('401','10','CRV','2026-01-11','85','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('402','11','CRV','2026-01-04','82','','0','150000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('403','10','CRV','2026-01-11','82','','0','150000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('404','11','CRV','2026-01-08','85','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('405','11','CRV','2026-01-08','74','','0','59000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('408','1','OB','2026-01-01','94','','167363','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('409','1','OB','2026-01-01','9','','0','167363','1','account');
INSERT INTO `trn_dtl_views` VALUES ('410','35','SIN','2026-01-11','94','','92475.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('411','10','SIN','2026-01-11','66','','21420.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('412','10','SIN','2026-01-11','73','','40500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('413','10','SIN','2026-01-11','158','','58292.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('415','39','SIN','2026-01-11','75','','165618.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('417','1','OB','2026-01-01','90','','90181','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('418','1','OB','2026-01-01','9','','0','90181','1','account');
INSERT INTO `trn_dtl_views` VALUES ('419','10','SIN','2026-01-11','90','','6300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('420','10','SIN','2026-01-11','72','','66765.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('421','10','SIN','2026-01-11','79','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('424','10','SIN','2026-01-11','87','','157685.10','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('425','1','OB','2026-01-01','89','','59575','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('426','1','OB','2026-01-01','9','','0','59575','1','account');
INSERT INTO `trn_dtl_views` VALUES ('427','10','SIN','2026-01-11','89','','16830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('428','44','SIN','2026-01-11','85','','78210.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('429','10','SIN','2026-01-11','69','','43530.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('430','12','CRV','2026-01-11','99','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('431','1','OB','2026-01-01','99','','53566','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('432','1','OB','2026-01-01','9','','0','53566','1','account');
INSERT INTO `trn_dtl_views` VALUES ('433','10','SIN','2026-01-11','99','','37665.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('435','10','SIN','2026-01-11','104','','40305.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('436','1','OB','2026-01-01','92','','58020','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('437','1','OB','2026-01-01','9','','0','58020','1','account');
INSERT INTO `trn_dtl_views` VALUES ('438','10','SIN','2026-01-11','92','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('439','10','SIN','2026-01-11','160','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('442','10','SIN','2026-01-11','81','','157068.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('443','10','SIN','2026-01-11','105','','70842.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('446','10','SIN','2026-01-11','100','','17280.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('449','13','CRV','2026-01-11','29','','0','272000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('451','59','SIN','2026-01-11','29','','44436.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('452','10','SIN','2026-01-12','70','','6415.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('454','61','SIN','2026-01-12','74','','99360.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('455','10','SIN','2026-01-12','67','','27382.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('456','10','SIN','2026-01-12','64','','78300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('457','10','SIN','2026-01-12','159','','87000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('459','1','OB','2026-01-01','91','','204100','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('460','1','OB','2026-01-01','9','','0','204100','1','account');
INSERT INTO `trn_dtl_views` VALUES ('461','10','SIN','2026-01-11','91','','105300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('462','40','SIN','2026-01-11','82','','308208.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('463','49','SIN','2026-01-06','98','','141298.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('464','56','SIN','2026-01-11','68','','50516.55','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('465','58','SIN','2026-01-11','80','','54712.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('466','10','SIN','2026-01-12','163','','16470.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('467','10','SIN','2026-01-12','152','','31730.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('468','1','OB','2026-01-01','119','','238711','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('469','1','OB','2026-01-01','9','','0','238711','1','account');
INSERT INTO `trn_dtl_views` VALUES ('470','15','CRV','2026-01-06','119','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('471','10','SIN','2026-01-13','119','','73191.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('472','1','OB','2026-01-01','147','','29494','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('473','1','OB','2026-01-01','9','','0','29494','1','account');
INSERT INTO `trn_dtl_views` VALUES ('475','16','CRV','2026-01-08','122','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('476','16','CRV','2026-01-08','40','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('477','16','CRV','2026-01-08','41','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('478','16','CRV','2026-01-08','42','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('479','16','CRV','2026-01-08','43','','0','200000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('480','16','CRV','2026-01-08','44','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('481','16','CRV','2026-01-08','45','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('482','16','CRV','2026-01-08','47','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('483','16','CRV','2026-01-08','49','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('484','16','CRV','2026-01-08','50','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('485','16','CRV','2026-01-08','46','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('486','16','CRV','2026-01-08','51','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('487','16','CRV','2026-01-08','54','','0','5000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('488','16','CRV','2026-01-08','56','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('489','16','CRV','2026-01-08','59','','0','9000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('490','16','CRV','2026-01-08','37','','0','35000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('491','16','CRV','2026-01-08','53','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('492','16','CRV','2026-01-08','58','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('493','16','CRV','2026-01-08','52','','0','16500.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('496','70','SIN','2026-01-14','37','','52690.68','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('497','10','SIN','2026-01-14','38','','13494.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('499','72','SIN','2026-01-14','52','','13494.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('501','10','SIN','2026-01-14','49','','22755.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('502','10','SIN','2026-01-14','43','','42777.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('503','10','SIN','2026-01-14','50','','15876.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('506','10','SIN','2026-01-14','53','','24152.69','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('507','77','SIN','2026-01-14','40','','23166.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('508','10','SIN','2026-01-14','41','','7200.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('510','69','SIN','2026-01-13','147','','80240.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('511','10','SIN','2026-01-14','59','','8279.04','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('513','17','CRV','2026-01-15','91','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('514','18','CRV','2026-01-12','64','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('515','18','CRV','2026-01-12','87','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('516','18','CRV','2026-01-12','87','JazzCash','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('517','18','CRV','2026-01-12','98','','0','18000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('518','18','CRV','2026-01-12','98','Raast','0','32000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('519','18','CRV','2026-01-12','92','JazzCash','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('520','18','CRV','2026-01-12','66','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('521','18','CRV','2026-01-12','83','Faisal','0','70000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('522','18','CRV','2026-01-12','69','','0','40000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('523','18','CRV','2026-01-12','73','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('524','18','CRV','2026-01-12','75','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('525','18','CRV','2026-01-12','85','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('526','18','CRV','2026-01-12','74','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('527','18','CRV','2026-01-12','81','','0','130000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('528','18','CRV','2026-01-12','72','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('529','18','CRV','2026-01-12','72','Meezan','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('530','18','CRV','2026-01-12','86','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('531','18','CRV','2026-01-12','70','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('532','18','CRV','2026-01-12','78','Meezan','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('533','18','CRV','2026-01-12','98','','0','3940.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('534','18','CRV','2026-01-12','105','Raast','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('535','18','CRV','2026-01-12','90','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('536','19','CRV','2026-01-15','77','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('537','10','SIN','2026-01-18','72','','57600.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('541','20','CRV','2026-01-12','163','','0','16470.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('542','10','SIN','2026-01-12','75','','78937.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('543','10','SIN','2026-01-18','70','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('544','10','SIN','2026-01-18','73','','22402.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('545','10','SIN','2026-01-18','92','','14700.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('546','10','SIN','2026-01-18','81','','107931.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('547','10','SIN','2026-01-18','66','','105516.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('549','90','SIN','2026-01-18','78','','37620.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('550','91','SIN','2026-01-18','105','','33696.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('551','92','SIN','2026-01-18','101','','41504.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('553','93','SIN','2026-01-18','98','','32130.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('554','94','SIN','2026-01-18','90','','48870.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('555','1','OB','2026-01-01','86','','45440','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('556','1','OB','2026-01-01','9','','0','45440','1','account');
INSERT INTO `trn_dtl_views` VALUES ('557','95','SIN','2026-01-18','86','','12150.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('559','96','SIN','2026-01-18','67','','20790.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('561','8','SIN','2026-01-04','87','','63795.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('562','98','SIN','2026-01-18','87','','50520.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('564','99','SIN','2026-01-18','82','','101685.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('569','22','CRV','2026-01-05','100','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('570','23','CRV','2026-01-12','100','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('571','100','SIN','2026-01-13','100','','167196.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('573','102','SIN','2026-01-18','77','','107625.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('574','83','SIN','2026-01-18','85','','69380.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('575','100','SIN','2026-01-18','68','','54816.30','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('576','100','SIN','2026-01-18','80','','118368.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('577','100','SIN','2026-01-18','69','','47745.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('578','24','CRV','2026-01-12','94','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('579','100','SIN','2026-01-18','94','','14400.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('580','100','SIN','2026-01-18','29','','31248.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('581','100','SIN','2026-01-18','71','','23814.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('582','1','OB','2026-01-01','88','','139708','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('583','1','OB','2026-01-01','9','','0','139708','1','account');
INSERT INTO `trn_dtl_views` VALUES ('584','25','CRV','2026-01-13','88','','0','139708.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('586','100','SIN','2026-01-19','64','','7830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('587','26','CRV','2026-01-17','89','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('588','100','SIN','2026-01-17','89','','22815.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('589','100','SIN','2026-01-19','136','','75276.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('592','109','SIN','2026-01-19','88','','148809.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('593','1','OB','2026-01-01','110','','901833','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('594','1','OB','2026-01-01','9','','0','901833','1','account');
INSERT INTO `trn_dtl_views` VALUES ('595','27','CRV','2026-01-17','110','','0','850000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('597','73','SIN','2026-01-14','45','','27323.10','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('598','1','OB','2026-01-01','137','','24852','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('599','1','OB','2026-01-01','9','','0','24852','1','account');
INSERT INTO `trn_dtl_views` VALUES ('600','28','CRV','2026-01-02','137','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('601','100','SIN','2026-01-19','137','','18360.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('602','29','CRV','2026-01-15','122','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('603','29','CRV','2026-01-15','40','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('604','29','CRV','2026-01-15','42','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('605','29','CRV','2026-01-15','44','Meezan','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('606','29','CRV','2026-01-15','47','','0','7000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('607','29','CRV','2026-01-15','49','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('608','29','CRV','2026-01-15','50','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('609','29','CRV','2026-01-15','54','','0','5000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('610','29','CRV','2026-01-15','59','','0','55000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('611','30','CRV','2026-01-17','58','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('612','31','CRV','2026-01-20','41','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('613','31','CRV','2026-01-20','43','','0','150000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('615','100','SIN','2026-01-21','45','','21609.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('616','100','SIN','2026-01-21','122','','51978.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('617','114','SIN','2026-01-21','43','','202801.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('618','100','SIN','2026-01-21','41','','18378.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('619','100','SIN','2026-01-21','40','','21150.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('620','100','SIN','2026-01-21','49','','11907.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('621','100','SIN','2026-01-21','44','','191091.18','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('622','100','SIN','2026-01-21','58','','170742.85','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('625','32','SIN','2026-01-10','133','','78577.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('626','100','SIN','2026-01-21','133','','78577.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('628','32','CRV','2026-01-19','64','','0','27000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('629','32','CRV','2026-01-19','64','Meezan','0','43000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('630','32','CRV','2026-01-19','87','Meezan','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('631','32','CRV','2026-01-19','94','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('632','32','CRV','2026-01-19','67','Meezan','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('633','32','CRV','2026-01-19','92','JazzCash','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('634','32','CRV','2026-01-19','68','Meezan','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('635','32','CRV','2026-01-19','82','Meezan','0','300000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('636','32','CRV','2026-01-19','69','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('637','32','CRV','2026-01-19','73','Meezan','0','10100.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('638','32','CRV','2026-01-19','73','','0','14900.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('639','32','CRV','2026-01-19','158','Meezan','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('640','32','CRV','2026-01-19','75','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('641','32','CRV','2026-01-19','71','','0','35000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('642','32','CRV','2026-01-19','79','','0','35000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('643','32','CRV','2026-01-19','81','Meezan','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('644','32','CRV','2026-01-19','84','Meezan','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('645','32','CRV','2026-01-19','72','Meezan','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('646','32','CRV','2026-01-19','98','Meezan','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('647','32','CRV','2026-01-19','101','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('648','32','CRV','2026-01-19','100','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('649','32','CRV','2026-01-19','104','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('650','32','CRV','2026-01-19','105','Meezan','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('651','32','CRV','2026-01-19','90','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('652','33','CRV','2026-01-20','72','Meezan','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('655','35','CRV','2026-01-01','164','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('656','100','SIN','2026-01-23','164','','17928.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('657','36','CRV','2026-01-13','164','testing','0','13000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('658','22','SIN','2026-01-07','39','','9335.09','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('660','124','SIN','2026-01-24','68','','98254.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('661','100','SIN','2026-01-24','92','','15915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('663','1','OB','2026-01-01','83','','193204','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('664','1','OB','2026-01-01','9','','0','193204','1','account');
INSERT INTO `trn_dtl_views` VALUES ('665','126','SIN','2026-01-24','83','','79575.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('667','127','SIN','2026-01-19','64','','124405.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('669','100','SIN','2026-01-19','66','','12150.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('671','130','SIN','2026-01-24','94','','79320.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('672','100','SIN','2026-01-25','72','','117075.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('673','100','SIN','2026-01-25','80','','94068.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('674','100','SIN','2026-01-25','73','','30615.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('675','100','SIN','2026-01-25','89','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('676','100','SIN','2026-01-20','75','','12150.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('677','100','SIN','2026-01-25','86','','8640.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('678','100','SIN','2026-01-25','98','','36585.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('679','100','SIN','2026-01-25','105','','12150.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('680','37','CRV','2026-01-18','69','Breakage','0','5537.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('681','100','SIN','2026-01-25','69','','35580.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('682','100','SIN','2026-01-25','90','','32940.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('683','100','SIN','2026-01-25','71','','128331.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('684','100','SIN','2026-01-25','67','','66753.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('685','100','SIN','2026-01-25','158','','15000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('686','100','SIN','2026-01-25','82','','86127.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('687','100','SIN','2026-01-21','29','','65463.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('688','1','OB','2026-01-01','84','','142823','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('689','1','OB','2026-01-01','9','','0','142823','1','account');
INSERT INTO `trn_dtl_views` VALUES ('690','100','SIN','2026-01-25','84','','115200.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('691','100','SIN','2026-01-25','29','','136654.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('694','149','SIN','2026-01-25','82','','137061.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('696','100','SIN','2026-01-25','92','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('697','100','SIN','2026-01-25','84','','172800.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('698','100','SIN','2026-01-25','90','','16830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('699','100','SIN','2026-01-25','85','','43200.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('700','38','CRV','2026-01-01','153','','0','7654.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('701','100','SIN','2026-01-25','153','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('707','157','SIN','2026-01-25','166','','33398.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('708','100','SIN','2026-01-25','91','','246920.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('709','156','SIN','2026-01-25','165','','24273.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('710','150','SIN','2026-01-25','72','','55240.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('711','128','SIN','2026-01-24','87','','66483.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('712','31','SIN','2026-01-08','109','','45396.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('713','100','SIN','2026-01-26','81','','82080.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('715','160','SIN','2026-01-26','145','','33466.61','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('716','1','OB','2026-01-01','103','','629419','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('717','1','OB','2026-01-01','9','','0','629419','1','account');
INSERT INTO `trn_dtl_views` VALUES ('718','100','SIN','2026-01-26','103','','156158.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('719','100','SIN','2026-01-26','167','','52328.70','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('720','39','CRV','2026-01-26','109','','0','45400.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('721','100','SIN','2026-01-27','109','','66348.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('724','164','SIN','2026-01-27','110','','1741086.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('725','100','SIN','2026-01-28','163','','16470.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('726','40','CRV','2026-01-22','122','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('727','40','CRV','2026-01-22','41','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('728','40','CRV','2026-01-22','42','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('729','40','CRV','2026-01-22','44','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('730','40','CRV','2026-01-22','45','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('731','40','CRV','2026-01-22','47','','0','7000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('732','40','CRV','2026-01-22','49','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('733','40','CRV','2026-01-22','51','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('734','40','CRV','2026-01-22','57','','0','5000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('735','40','CRV','2026-01-22','59','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('736','40','CRV','2026-01-22','37','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('737','40','CRV','2026-01-22','53','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('738','40','CRV','2026-01-22','61','','0','5000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('739','40','CRV','2026-01-22','123','','0','20000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('740','41','CRV','2026-01-21','40','JazzCash','0','3500.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('741','41','CRV','2026-01-21','39','JazzCash','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('742','39','CRV','2026-01-26','39','','0','20000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('743','40','CRV','2026-01-20','50','','0','10000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('744','40','CRV','2026-01-22','41','','0','20000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('745','41','CRV','2026-01-27','40','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('746','42','CRV','2026-01-28','43','','0','150000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('748','166','SIN','2026-01-28','50','','43306.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('749','100','SIN','2026-01-28','37','','60685.13','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('751','100','SIN','2026-01-28','51','','37467.36','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('752','100','SIN','2026-01-28','46','','29211.84','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('754','170','SIN','2026-01-28','40','','39366.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('755','100','SIN','2026-01-28','49','','41660.98','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('757','172','SIN','2026-01-28','60','','51685.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('758','100','SIN','2026-01-28','47','','12700.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('759','100','SIN','2026-01-28','53','','62710.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('760','100','SIN','2026-01-28','57','','52126.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('761','100','SIN','2026-01-28','43','','122392.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('762','100','SIN','2026-01-28','39','','47987.86','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('763','100','SIN','2026-01-28','45','','17463.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('764','100','SIN','2026-01-28','38','','8731.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('766','43','CRV','2026-01-27','153','','0','16500.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('767','100','SIN','2026-01-28','153','','38196.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('768','100','SIN','2026-01-28','139','','36774.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('769','180','SIN','2026-01-28','122','','37008.36','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('770','29','SIN','2026-01-06','118','','31220.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('771','100','SIN','2026-01-14','118','','23937.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('772','100','SIN','2026-01-28','118','','66850.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','','','0','261000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','','','0','202000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','2','','63000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','','','0','1351.35','8','cash');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','9','','0','83.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('197','3','SIN','2025-12-19','156','','0','20000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('202','1','OB','2026-01-01','','','0','20917.8','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('203','1','OB','2026-01-01','','','20917.8','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('204','1','OB','2026-01-01','','','0','499253','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('205','1','OB','2026-01-01','','','499253','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('206','1','OB','2026-01-01','','','0','31471','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('207','1','OB','2026-01-01','','','31471','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('208','1','OB','2026-01-01','','','0','164862','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('209','1','OB','2026-01-01','','','164862','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('210','1','OB','2026-01-01','','','0','184701','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('211','1','OB','2026-01-01','','','184701','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('212','1','OB','2026-01-01','','','0','160979','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('213','1','OB','2026-01-01','','','160979','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('214','1','OB','2026-01-01','','','0','779710','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('215','1','OB','2026-01-01','','','779710','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('216','1','OB','2026-01-01','','','0','1453069','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('217','1','OB','2026-01-01','','','1453069','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('218','1','OB','2026-01-01','','','0','1250635','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('219','1','OB','2026-01-01','','','1250635','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('220','1','OB','2026-01-01','','','0','161041','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('221','1','OB','2026-01-01','','','161041','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('222','1','OB','2026-01-01','','','0','46399','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('223','1','OB','2026-01-01','','','46399','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('224','1','OB','2026-01-01','','','0','117515','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('225','1','OB','2026-01-01','','','117515','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('226','1','OB','2026-01-01','','','0','22106','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('227','1','OB','2026-01-01','','','22106','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('228','1','SIN','2026-01-03','2','','0','19130.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('229','1','OB','2026-01-01','','','0','114304','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('230','1','OB','2026-01-01','','','114304','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('231','2','SIN','2026-01-04','2','','0','74760.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('232','1','OB','2026-01-01','','','0','459343','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('233','1','OB','2026-01-01','','','459343','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('234','3','SIN','2026-01-04','2','','0','7830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('235','1','OB','2026-01-01','','','0','605118','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('236','1','OB','2026-01-01','','','605118','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('237','4','SIN','2026-01-04','2','','0','45900.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('238','1','OB','2026-01-01','','','0','197168','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('239','1','OB','2026-01-01','','','197168','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('240','5','SIN','2026-01-04','2','','0','18630.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('241','1','OB','2026-01-01','','','0','85143','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('242','1','OB','2026-01-01','','','85143','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('243','6','SIN','2026-01-04','2','','0','48600.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('247','1','OB','2026-01-01','','','0','110752','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('248','1','OB','2026-01-01','','','110752','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('250','1','OB','2026-01-01','','','0','332903','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('251','1','OB','2026-01-01','','','332903','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('252','9','SIN','2026-01-04','2','','0','12915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('253','1','OB','2026-01-01','','','0','206022','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('254','1','OB','2026-01-01','','','206022','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('256','1','CRV','2026-01-03','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('257','10','SIN','2026-01-04','2','','0','83785.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('258','1','OB','2026-01-01','','','0','1072290','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('259','1','OB','2026-01-01','','','1072290','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('260','10','SIN','2026-01-04','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('261','1','OB','2026-01-01','','','0','88668','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('262','1','OB','2026-01-01','','','88668','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('263','1','OB','2026-01-01','','','0','347332','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('264','1','OB','2026-01-01','','','347332','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('265','10','SIN','2026-01-04','2','','0','15915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('266','10','SIN','2026-01-04','2','','0','6300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('267','1','OB','2026-01-01','','','0','689487','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('268','1','OB','2026-01-01','','','689487','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('269','10','SIN','2026-01-04','2','','0','69380.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('270','1','OB','2026-01-01','','','0','149620','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('271','1','OB','2026-01-01','','','149620','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('272','1','OB','2026-01-01','','','0','39600','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('273','1','OB','2026-01-01','','','39600','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('274','10','SIN','2026-01-06','2','','0','16848.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('275','1','OB','2026-01-01','','','0','5612','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('276','1','OB','2026-01-01','','','5612','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('277','10','SIN','2026-01-06','2','','0','32037.77','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('280','1','OB','2026-01-01','','','0','189033','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('281','1','OB','2026-01-01','','','189033','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('282','1','OB','2026-01-01','','','0','65561','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('283','1','OB','2026-01-01','','','65561','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('284','1','OB','2026-01-01','','','0','143670','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('285','1','OB','2026-01-01','','','143670','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('286','1','OB','2026-01-01','','','0','307647','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('287','1','OB','2026-01-01','','','307647','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('288','1','OB','2026-01-01','','','0','22755','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('289','1','OB','2026-01-01','','','22755','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('290','1','OB','2026-01-01','','','0','84977','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('291','1','OB','2026-01-01','','','84977','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('292','1','OB','2026-01-01','','','0','325980','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('293','1','OB','2026-01-01','','','325980','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('294','1','OB','2026-01-01','','','0','25696','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('295','1','OB','2026-01-01','','','25696','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('296','1','OB','2026-01-01','','','0','208699','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('297','1','OB','2026-01-01','','','208699','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('298','1','OB','2026-01-01','','','0','60839','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('299','1','OB','2026-01-01','','','60839','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('300','1','OB','2026-01-01','','','0','102801','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('301','1','OB','2026-01-01','','','102801','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('302','1','OB','2026-01-01','','','0','71213','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('303','1','OB','2026-01-01','','','71213','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('304','1','OB','2026-01-01','','','0','161050','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('305','1','OB','2026-01-01','','','161050','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('307','2','CRV','2026-01-01','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('308','3','CRV','2026-01-01','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('309','3','CRV','2026-01-01','157','','23000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('310','3','CRV','2026-01-01','157','Meezan Bank','100000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('311','3','CRV','2026-01-01','157','','7000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('312','3','CRV','2026-01-01','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('313','3','CRV','2026-01-01','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('314','3','CRV','2026-01-01','157','','21000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('315','3','CRV','2026-01-01','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('316','3','CRV','2026-01-01','157','Meezan','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('317','3','CRV','2026-01-01','157','HBL','35000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('318','3','CRV','2026-01-01','157','Meezan','22700.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('319','3','CRV','2026-01-01','157','Meezan Bank','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('321','17','SIN','2026-01-07','2','','0','19364.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('322','10','SIN','2026-01-07','2','','0','16511.04','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('323','10','SIN','2026-01-01','2','','0','9261.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('325','10','SIN','2026-01-07','2','','0','21242.09','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('327','10','SIN','2026-01-07','2','','0','9720.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('328','10','SIN','2026-01-07','2','','0','48423.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('329','10','SIN','2026-01-01','2','','0','8568.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('331','26','SIN','2026-01-07','2','','0','70436.52','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('332','10','SIN','2026-01-07','2','','0','11907.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('333','20','SIN','2026-01-07','2','','0','48866.33','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('334','4','CRV','2026-01-06','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('335','10','SIN','2026-01-07','2','','0','90681.95','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('336','1','OB','2026-01-01','','','0','139963','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('337','1','OB','2026-01-01','','','139963','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('339','10','SIN','2026-01-07','2','','0','111375.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('340','1','OB','2026-01-01','','','0','240680','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('341','1','OB','2026-01-01','','','240680','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('342','1','OB','2026-01-01','','','0','8348','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('343','1','OB','2026-01-01','','','8348','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('344','1','OB','2026-01-01','','','0','172654','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('345','1','OB','2026-01-01','','','172654','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('346','1','OB','2026-01-01','','','0','82662','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('347','1','OB','2026-01-01','','','82662','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('348','1','OB','2026-01-01','','','0','126441','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('349','1','OB','2026-01-01','','','126441','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('350','1','OB','2026-01-01','','','0','126307','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('351','1','OB','2026-01-01','','','126307','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('352','1','OB','2026-01-01','','','0','85590','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('353','1','OB','2026-01-01','','','85590','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('354','1','OB','2026-01-01','','','0','979451','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('355','1','OB','2026-01-01','','','979451','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('356','1','OB','2026-01-01','','','0','71461','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('357','1','OB','2026-01-01','','','71461','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('358','1','OB','2026-01-01','','','0','517418','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('359','1','OB','2026-01-01','','','517418','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('360','1','OB','2026-01-01','','','0','172039','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('361','1','OB','2026-01-01','','','172039','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('362','1','OB','2026-01-01','','','0','201957','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('363','1','OB','2026-01-01','','','201957','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('364','1','OB','2026-01-01','','','0','574335','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('365','1','OB','2026-01-01','','','574335','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('366','1','OB','2026-01-01','','','0','838626','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('367','1','OB','2026-01-01','','','838626','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('373','5','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('374','5','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('375','5','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('376','5','CRV','2026-01-05','157','','40000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('377','5','CRV','2026-01-05','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('378','5','CRV','2026-01-05','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('380','5','CRV','2026-01-05','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('381','5','CRV','2026-01-05','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('382','10','SIN','2026-01-03','2','','0','15915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('383','1','OB','2026-01-01','','','0','40723','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('384','1','OB','2026-01-01','','','40723','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('385','6','CRV','2026-01-01','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('386','7','CRV','2026-01-11','157','','89500.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('387','8','CRV','2026-01-05','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('388','8','CRV','2026-01-05','157','','13000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('389','8','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('390','8','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('391','8','CRV','2026-01-05','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('392','8','CRV','2026-01-05','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('393','8','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('394','8','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('395','8','CRV','2026-01-05','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('396','9','CRV','2026-01-07','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('397','9','CRV','2026-01-07','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('398','1','OB','2026-01-01','','','0','96303','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('399','1','OB','2026-01-01','','','96303','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('400','10','CRV','2026-01-11','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('401','10','CRV','2026-01-11','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('402','11','CRV','2026-01-04','157','','150000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('403','10','CRV','2026-01-11','157','','150000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('404','11','CRV','2026-01-08','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('405','11','CRV','2026-01-08','157','','59000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('408','1','OB','2026-01-01','','','0','167363','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('409','1','OB','2026-01-01','','','167363','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('410','35','SIN','2026-01-11','2','','0','92475.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('411','10','SIN','2026-01-11','2','','0','21420.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('412','10','SIN','2026-01-11','2','','0','40500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('413','10','SIN','2026-01-11','2','','0','58292.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('415','39','SIN','2026-01-11','2','','0','165618.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('417','1','OB','2026-01-01','','','0','90181','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('418','1','OB','2026-01-01','','','90181','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('419','10','SIN','2026-01-11','2','','0','6300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('420','10','SIN','2026-01-11','2','','0','66765.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('421','10','SIN','2026-01-11','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('424','10','SIN','2026-01-11','2','','0','157685.10','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('425','1','OB','2026-01-01','','','0','59575','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('426','1','OB','2026-01-01','','','59575','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('427','10','SIN','2026-01-11','2','','0','16830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('428','44','SIN','2026-01-11','2','','0','78210.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('429','10','SIN','2026-01-11','2','','0','43530.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('430','12','CRV','2026-01-11','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('431','1','OB','2026-01-01','','','0','53566','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('432','1','OB','2026-01-01','','','53566','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('433','10','SIN','2026-01-11','2','','0','37665.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('435','10','SIN','2026-01-11','2','','0','40305.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('436','1','OB','2026-01-01','','','0','58020','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('437','1','OB','2026-01-01','','','58020','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('438','10','SIN','2026-01-11','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('439','10','SIN','2026-01-11','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('442','10','SIN','2026-01-11','2','','0','157068.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('443','10','SIN','2026-01-11','2','','0','70842.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('446','10','SIN','2026-01-11','2','','0','17280.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('449','13','CRV','2026-01-11','157','','272000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('451','59','SIN','2026-01-11','2','','0','44436.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('452','10','SIN','2026-01-12','2','','0','6415.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('454','61','SIN','2026-01-12','2','','0','99360.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('455','10','SIN','2026-01-12','2','','0','27382.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('456','10','SIN','2026-01-12','2','','0','78300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('457','10','SIN','2026-01-12','2','','0','87000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('459','1','OB','2026-01-01','','','0','204100','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('460','1','OB','2026-01-01','','','204100','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('461','10','SIN','2026-01-11','2','','0','105300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('462','40','SIN','2026-01-11','2','','0','308208.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('463','49','SIN','2026-01-06','2','','0','141298.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('464','56','SIN','2026-01-11','2','','0','50516.55','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('465','58','SIN','2026-01-11','2','','0','54712.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('466','10','SIN','2026-01-12','2','','0','16470.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('467','10','SIN','2026-01-12','2','','0','31730.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('468','1','OB','2026-01-01','','','0','238711','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('469','1','OB','2026-01-01','','','238711','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('470','15','CRV','2026-01-06','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('471','10','SIN','2026-01-13','2','','0','73191.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('472','1','OB','2026-01-01','','','0','29494','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('473','1','OB','2026-01-01','','','29494','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('475','16','CRV','2026-01-08','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('476','16','CRV','2026-01-08','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('477','16','CRV','2026-01-08','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('478','16','CRV','2026-01-08','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('479','16','CRV','2026-01-08','157','','200000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('480','16','CRV','2026-01-08','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('481','16','CRV','2026-01-08','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('482','16','CRV','2026-01-08','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('483','16','CRV','2026-01-08','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('484','16','CRV','2026-01-08','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('485','16','CRV','2026-01-08','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('486','16','CRV','2026-01-08','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('487','16','CRV','2026-01-08','157','','5000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('488','16','CRV','2026-01-08','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('489','16','CRV','2026-01-08','157','','9000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('490','16','CRV','2026-01-08','157','','35000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('491','16','CRV','2026-01-08','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('492','16','CRV','2026-01-08','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('493','16','CRV','2026-01-08','157','','16500.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('496','70','SIN','2026-01-14','2','','0','52690.68','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('497','10','SIN','2026-01-14','2','','0','13494.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('499','72','SIN','2026-01-14','2','','0','13494.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('501','10','SIN','2026-01-14','2','','0','22755.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('502','10','SIN','2026-01-14','2','','0','42777.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('503','10','SIN','2026-01-14','2','','0','15876.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('506','10','SIN','2026-01-14','2','','0','24152.69','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('507','77','SIN','2026-01-14','2','','0','23166.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('508','10','SIN','2026-01-14','2','','0','7200.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('510','69','SIN','2026-01-13','2','','0','80240.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('511','10','SIN','2026-01-14','2','','0','8279.04','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('513','17','CRV','2026-01-15','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('514','18','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('515','18','CRV','2026-01-12','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('516','18','CRV','2026-01-12','157','JazzCash','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('517','18','CRV','2026-01-12','157','','18000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('518','18','CRV','2026-01-12','157','Raast','32000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('519','18','CRV','2026-01-12','157','JazzCash','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('520','18','CRV','2026-01-12','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('521','18','CRV','2026-01-12','157','Faisal','70000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('522','18','CRV','2026-01-12','157','','40000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('523','18','CRV','2026-01-12','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('524','18','CRV','2026-01-12','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('525','18','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('526','18','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('527','18','CRV','2026-01-12','157','','130000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('528','18','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('529','18','CRV','2026-01-12','157','Meezan','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('530','18','CRV','2026-01-12','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('531','18','CRV','2026-01-12','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('532','18','CRV','2026-01-12','157','Meezan','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('533','18','CRV','2026-01-12','157','','3940.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('534','18','CRV','2026-01-12','157','Raast','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('535','18','CRV','2026-01-12','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('536','19','CRV','2026-01-15','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('537','10','SIN','2026-01-18','2','','0','57600.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('541','20','CRV','2026-01-12','157','','16470.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('542','10','SIN','2026-01-12','2','','0','78937.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('543','10','SIN','2026-01-18','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('544','10','SIN','2026-01-18','2','','0','22402.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('545','10','SIN','2026-01-18','2','','0','14700.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('546','10','SIN','2026-01-18','2','','0','107931.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('547','10','SIN','2026-01-18','2','','0','105516.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('549','90','SIN','2026-01-18','2','','0','37620.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('550','91','SIN','2026-01-18','2','','0','33696.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('551','92','SIN','2026-01-18','2','','0','41504.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('553','93','SIN','2026-01-18','2','','0','32130.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('554','94','SIN','2026-01-18','2','','0','48870.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('555','1','OB','2026-01-01','','','0','45440','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('556','1','OB','2026-01-01','','','45440','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('557','95','SIN','2026-01-18','2','','0','12150.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('559','96','SIN','2026-01-18','2','','0','20790.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('561','8','SIN','2026-01-04','2','','0','63795.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('562','98','SIN','2026-01-18','2','','0','50520.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('564','99','SIN','2026-01-18','2','','0','101685.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('569','22','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('570','23','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('571','100','SIN','2026-01-13','2','','0','167196.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('573','102','SIN','2026-01-18','2','','0','107625.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('574','83','SIN','2026-01-18','2','','0','69380.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('575','100','SIN','2026-01-18','2','','0','54816.30','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('576','100','SIN','2026-01-18','2','','0','118368.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('577','100','SIN','2026-01-18','2','','0','47745.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('578','24','CRV','2026-01-12','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('579','100','SIN','2026-01-18','2','','0','14400.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('580','100','SIN','2026-01-18','2','','0','31248.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('581','100','SIN','2026-01-18','2','','0','23814.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('582','1','OB','2026-01-01','','','0','139708','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('583','1','OB','2026-01-01','','','139708','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('584','25','CRV','2026-01-13','157','','139708.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('586','100','SIN','2026-01-19','2','','0','7830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('587','26','CRV','2026-01-17','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('588','100','SIN','2026-01-17','2','','0','22815.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('589','100','SIN','2026-01-19','2','','0','75276.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('592','109','SIN','2026-01-19','2','','0','148809.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('593','1','OB','2026-01-01','','','0','901833','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('594','1','OB','2026-01-01','','','901833','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('595','27','CRV','2026-01-17','157','','850000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('597','73','SIN','2026-01-14','2','','0','27323.10','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('598','1','OB','2026-01-01','','','0','24852','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('599','1','OB','2026-01-01','','','24852','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('600','28','CRV','2026-01-02','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('601','100','SIN','2026-01-19','2','','0','18360.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('602','29','CRV','2026-01-15','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('603','29','CRV','2026-01-15','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('604','29','CRV','2026-01-15','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('605','29','CRV','2026-01-15','157','Meezan','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('606','29','CRV','2026-01-15','157','','7000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('607','29','CRV','2026-01-15','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('608','29','CRV','2026-01-15','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('609','29','CRV','2026-01-15','157','','5000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('610','29','CRV','2026-01-15','157','','55000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('611','30','CRV','2026-01-17','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('612','31','CRV','2026-01-20','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('613','31','CRV','2026-01-20','157','','150000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('615','100','SIN','2026-01-21','2','','0','21609.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('616','100','SIN','2026-01-21','2','','0','51978.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('617','114','SIN','2026-01-21','2','','0','202801.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('618','100','SIN','2026-01-21','2','','0','18378.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('619','100','SIN','2026-01-21','2','','0','21150.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('620','100','SIN','2026-01-21','2','','0','11907.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('621','100','SIN','2026-01-21','2','','0','191091.18','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('622','100','SIN','2026-01-21','2','','0','170742.85','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('625','32','SIN','2026-01-10','2','','0','78577.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('626','100','SIN','2026-01-21','2','','0','78577.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('628','32','CRV','2026-01-19','157','','27000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('629','32','CRV','2026-01-19','157','Meezan','43000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('630','32','CRV','2026-01-19','157','Meezan','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('631','32','CRV','2026-01-19','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('632','32','CRV','2026-01-19','157','Meezan','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('633','32','CRV','2026-01-19','157','JazzCash','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('634','32','CRV','2026-01-19','157','Meezan','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('635','32','CRV','2026-01-19','157','Meezan','300000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('636','32','CRV','2026-01-19','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('637','32','CRV','2026-01-19','157','Meezan','10100.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('638','32','CRV','2026-01-19','157','','14900.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('639','32','CRV','2026-01-19','157','Meezan','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('640','32','CRV','2026-01-19','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('641','32','CRV','2026-01-19','157','','35000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('642','32','CRV','2026-01-19','157','','35000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('643','32','CRV','2026-01-19','157','Meezan','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('644','32','CRV','2026-01-19','157','Meezan','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('645','32','CRV','2026-01-19','157','Meezan','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('646','32','CRV','2026-01-19','157','Meezan','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('647','32','CRV','2026-01-19','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('648','32','CRV','2026-01-19','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('649','32','CRV','2026-01-19','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('650','32','CRV','2026-01-19','157','Meezan','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('651','32','CRV','2026-01-19','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('652','33','CRV','2026-01-20','157','Meezan','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('655','35','CRV','2026-01-01','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('656','100','SIN','2026-01-23','2','','0','17928.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('657','36','CRV','2026-01-13','157','testing','13000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('658','22','SIN','2026-01-07','2','','0','9335.09','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('660','124','SIN','2026-01-24','2','','0','98254.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('661','100','SIN','2026-01-24','2','','0','15915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('663','1','OB','2026-01-01','','','0','193204','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('664','1','OB','2026-01-01','','','193204','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('665','126','SIN','2026-01-24','2','','0','79575.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('667','127','SIN','2026-01-19','2','','0','124405.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('669','100','SIN','2026-01-19','2','','0','12150.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('671','130','SIN','2026-01-24','2','','0','79320.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('672','100','SIN','2026-01-25','2','','0','117075.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('673','100','SIN','2026-01-25','2','','0','94068.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('674','100','SIN','2026-01-25','2','','0','30615.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('675','100','SIN','2026-01-25','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('676','100','SIN','2026-01-20','2','','0','12150.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('677','100','SIN','2026-01-25','2','','0','8640.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('678','100','SIN','2026-01-25','2','','0','36585.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('679','100','SIN','2026-01-25','2','','0','12150.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('680','37','CRV','2026-01-18','157','Breakage','5537.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('681','100','SIN','2026-01-25','2','','0','35580.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('682','100','SIN','2026-01-25','2','','0','32940.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('683','100','SIN','2026-01-25','2','','0','128331.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('684','100','SIN','2026-01-25','2','','0','66753.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('685','100','SIN','2026-01-25','2','','0','15000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('686','100','SIN','2026-01-25','2','','0','86127.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('687','100','SIN','2026-01-21','2','','0','65463.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('688','1','OB','2026-01-01','','','0','142823','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('689','1','OB','2026-01-01','','','142823','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('690','100','SIN','2026-01-25','2','','0','115200.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('691','100','SIN','2026-01-25','2','','0','136654.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('694','149','SIN','2026-01-25','2','','0','137061.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('696','100','SIN','2026-01-25','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('697','100','SIN','2026-01-25','2','','0','172800.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('698','100','SIN','2026-01-25','2','','0','16830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('699','100','SIN','2026-01-25','2','','0','43200.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('700','38','CRV','2026-01-01','157','','7654.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('701','100','SIN','2026-01-25','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('707','157','SIN','2026-01-25','2','','0','33398.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('708','100','SIN','2026-01-25','2','','0','246920.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('709','156','SIN','2026-01-25','2','','0','24273.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('710','150','SIN','2026-01-25','2','','0','55240.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('711','128','SIN','2026-01-24','2','','0','66483.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('712','31','SIN','2026-01-08','2','','0','45396.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('713','100','SIN','2026-01-26','2','','0','82080.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('715','160','SIN','2026-01-26','2','','0','33466.61','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('716','1','OB','2026-01-01','','','0','629419','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('717','1','OB','2026-01-01','','','629419','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('718','100','SIN','2026-01-26','2','','0','156158.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('719','100','SIN','2026-01-26','2','','0','52328.70','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('720','39','CRV','2026-01-26','157','','45400.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('721','100','SIN','2026-01-27','2','','0','66348.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('724','164','SIN','2026-01-27','2','','0','1741086.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('725','100','SIN','2026-01-28','2','','0','16470.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('726','40','CRV','2026-01-22','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('727','40','CRV','2026-01-22','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('728','40','CRV','2026-01-22','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('729','40','CRV','2026-01-22','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('730','40','CRV','2026-01-22','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('731','40','CRV','2026-01-22','157','','7000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('732','40','CRV','2026-01-22','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('733','40','CRV','2026-01-22','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('734','40','CRV','2026-01-22','157','','5000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('735','40','CRV','2026-01-22','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('736','40','CRV','2026-01-22','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('737','40','CRV','2026-01-22','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('738','40','CRV','2026-01-22','157','','5000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('739','40','CRV','2026-01-22','157','','20000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('740','41','CRV','2026-01-21','157','JazzCash','3500.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('741','41','CRV','2026-01-21','157','JazzCash','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('742','39','CRV','2026-01-26','157','','20000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('743','40','CRV','2026-01-20','157','','10000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('744','40','CRV','2026-01-22','157','','20000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('745','41','CRV','2026-01-27','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('746','42','CRV','2026-01-28','157','','150000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('748','166','SIN','2026-01-28','2','','0','43306.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('749','100','SIN','2026-01-28','2','','0','60685.13','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('751','100','SIN','2026-01-28','2','','0','37467.36','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('752','100','SIN','2026-01-28','2','','0','29211.84','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('754','170','SIN','2026-01-28','2','','0','39366.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('755','100','SIN','2026-01-28','2','','0','41660.98','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('757','172','SIN','2026-01-28','2','','0','51685.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('758','100','SIN','2026-01-28','2','','0','12700.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('759','100','SIN','2026-01-28','2','','0','62710.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('760','100','SIN','2026-01-28','2','','0','52126.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('761','100','SIN','2026-01-28','2','','0','122392.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('762','100','SIN','2026-01-28','2','','0','47987.86','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('763','100','SIN','2026-01-28','2','','0','17463.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('764','100','SIN','2026-01-28','2','','0','8731.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('766','43','CRV','2026-01-27','157','','16500.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('767','100','SIN','2026-01-28','2','','0','38196.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('768','100','SIN','2026-01-28','2','','0','36774.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('769','180','SIN','2026-01-28','2','','0','37008.36','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('770','29','SIN','2026-01-06','2','','0','31220.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('771','100','SIN','2026-01-14','2','','0','23937.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('772','100','SIN','2026-01-28','2','','0','66850.00','1','cash');


DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `units` VALUES ('6','Carton','1','2025-10-25 18:57:46','2025-10-25 18:57:46');
INSERT INTO `units` VALUES ('8','KG','7','2025-10-27 19:18:50','2025-10-27 19:18:50');
INSERT INTO `units` VALUES ('9','mm','8','2025-11-10 21:38:21','2025-11-10 21:38:21');
INSERT INTO `units` VALUES ('11','Bundle','1','2025-12-11 18:27:16','2025-12-11 18:27:16');
INSERT INTO `units` VALUES ('12','Bora','1','2025-12-11 18:27:52','2025-12-11 18:27:52');
INSERT INTO `units` VALUES ('13','PCS','7','2025-12-19 16:23:06','2025-12-19 16:23:06');


DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE `user_permission` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint unsigned NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `read` int NOT NULL,
  `write` int NOT NULL,
  `update` int NOT NULL,
  `delete` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_permission` VALUES ('1','134','1','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('2','134','2','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('3','134','3','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('4','134','4','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('5','134','5','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('6','134','6','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('7','134','7','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('8','134','8','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('9','134','9','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('10','134','10','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('11','134','11','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('12','134','12','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('13','134','13','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('14','134','14','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('15','134','15','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('16','134','16','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('17','134','17','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('18','134','18','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('19','134','19','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('20','134','20','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('21','134','21','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('22','134','22','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('23','134','23','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('24','134','24','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('25','134','25','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('26','134','26','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('27','134','27','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('28','134','28','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('29','134','29','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('30','134','30','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('31','134','31','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('32','134','32','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('33','134','33','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('34','134','34','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('35','134','35','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('36','134','36','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('37','135','1','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('38','135','2','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('39','135','3','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('40','135','4','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('41','135','5','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('42','135','6','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('43','135','7','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('44','135','8','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('45','135','9','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('46','135','10','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('47','135','11','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('48','135','12','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('49','135','13','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('50','135','14','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('51','135','15','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('52','135','16','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('53','135','17','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('54','135','18','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('55','135','19','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('56','135','20','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('57','135','21','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('58','135','22','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('59','135','23','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('60','135','24','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('61','135','25','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('62','135','26','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('63','135','27','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('64','135','28','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('65','135','29','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('66','135','30','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('67','135','31','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('68','135','32','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('69','135','33','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('70','135','34','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('71','135','35','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('72','135','36','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('145','137','1','9','1','0','0','0','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('146','137','2','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('147','137','3','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('148','137','4','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('149','137','5','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('150','137','6','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('151','137','7','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('152','137','8','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('153','137','9','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('154','137','10','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('155','137','11','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('156','137','12','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('157','137','13','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('158','137','14','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('159','137','15','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('160','137','16','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('161','137','17','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('162','137','18','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('163','137','19','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('164','137','20','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('165','137','21','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('166','137','22','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('167','137','23','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('168','137','24','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('169','137','25','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('170','137','26','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('171','137','27','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('172','137','28','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('173','137','29','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('174','137','30','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('175','137','31','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('176','137','32','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('177','137','33','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('178','137','34','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('179','137','35','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('180','137','36','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('334','143','32','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('335','143','34','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('336','143','35','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('367','139','1','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('368','139','2','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('369','139','3','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('370','139','4','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('371','139','5','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('372','139','6','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('373','139','7','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('374','139','8','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('375','139','9','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('376','139','10','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('377','139','11','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('378','139','12','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('379','139','13','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('380','139','14','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('381','139','15','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('382','139','16','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('383','139','17','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('384','139','18','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('385','139','19','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('386','139','20','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('387','139','21','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('388','139','22','1','1','1','1','1','2025-10-10 00:08:31','2025-10-10 00:08:31');
INSERT INTO `user_permission` VALUES ('389','139','23','1','1','1','1','1','2025-10-10 00:08:32','2025-10-10 00:08:32');
INSERT INTO `user_permission` VALUES ('390','139','24','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('391','139','25','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('392','139','26','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('393','139','27','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('394','139','28','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('395','139','29','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('396','139','30','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('397','139','31','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('398','139','32','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('399','139','33','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('400','139','34','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('401','139','35','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('402','139','36','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('403','145','1','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('404','145','2','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('405','145','3','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('406','145','4','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('407','145','5','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('408','145','6','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('409','145','7','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('410','145','8','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('411','145','9','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('412','145','10','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('413','145','11','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('414','145','12','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('415','145','13','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('416','145','14','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('417','145','15','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('418','145','16','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('419','145','17','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('420','145','18','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('421','145','19','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('422','145','20','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('423','145','21','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('424','145','22','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('425','145','23','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('426','145','24','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('427','145','25','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('428','145','26','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('429','145','27','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('430','145','28','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('431','145','29','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('432','145','30','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('433','145','31','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('434','145','32','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('435','145','33','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('436','145','34','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('437','145','36','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('488','141','1','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('489','141','2','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('490','141','3','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('491','141','4','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('492','141','5','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('493','141','6','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('494','141','7','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('495','141','8','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('496','141','9','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('497','141','10','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('498','141','11','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('499','141','12','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('500','141','13','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('501','141','14','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('502','141','15','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('503','141','16','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('504','141','17','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('505','141','18','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('506','141','19','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('507','141','20','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('508','141','21','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('509','141','22','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('510','141','23','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('511','141','24','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('512','141','25','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('513','141','26','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('514','141','27','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('515','141','28','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('516','141','29','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('517','141','30','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('518','141','31','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('519','141','32','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('520','141','33','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('521','141','34','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('522','141','36','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('523','146','1','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('524','146','2','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('525','146','3','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('526','146','4','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('527','146','5','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('528','146','6','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('529','146','7','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('530','146','8','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('531','146','9','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('532','146','10','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('533','146','11','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('534','146','12','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('535','146','13','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('536','146','14','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('537','146','15','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('538','146','16','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('539','146','17','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('540','146','18','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('541','146','19','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('542','146','20','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('543','146','21','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('544','146','22','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('545','146','23','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('546','146','24','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('547','146','25','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('548','146','26','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('549','146','27','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('550','146','28','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('551','146','29','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('552','146','30','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('553','146','31','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('554','146','32','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('555','146','33','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('556','146','34','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('557','146','36','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('558','142','1','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('559','142','2','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('560','142','3','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('561','142','4','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('562','142','5','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('563','142','6','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('564','142','7','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('565','142','8','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('566','142','9','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('567','142','10','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('568','142','11','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('569','142','12','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('570','142','13','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('571','142','14','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('572','142','15','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('573','142','16','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('574','142','17','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('575','142','18','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('576','142','19','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('577','142','20','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('578','142','21','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('579','142','22','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('580','142','23','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('581','142','24','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('582','142','25','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('583','142','26','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('584','142','27','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('585','142','28','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('586','142','29','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('587','142','30','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('588','142','31','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('589','142','32','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('590','142','33','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('591','142','34','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('592','142','36','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('594','1','1','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('595','1','2','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('596','1','3','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('597','1','4','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('598','1','5','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('599','1','6','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('600','1','7','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('601','1','8','1','1','1','1','1','2025-11-06 02:00:05','2025-11-16 01:40:15');
INSERT INTO `user_permission` VALUES ('602','1','9','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('603','1','10','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('604','1','11','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('605','1','12','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('606','1','13','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('607','1','14','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('608','1','15','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('609','1','16','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('610','1','17','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('611','1','18','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('612','1','19','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('613','1','20','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('614','1','21','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('615','1','22','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('616','1','24','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('617','1','25','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('618','1','26','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('619','1','36','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('620','1','37','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('621','135','1','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('622','135','2','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('623','135','3','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('624','135','4','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('625','135','5','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('626','135','6','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('627','135','7','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('628','135','8','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('629','135','9','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('630','135','10','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('631','135','11','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('632','135','12','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('633','135','13','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('634','135','14','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account` tinyint(1) DEFAULT NULL,
  `report` tinyint(1) DEFAULT NULL,
  `billing` tinyint(1) DEFAULT NULL,
  `delivery_challan` tinyint(1) DEFAULT NULL,
  `waste_sale` tinyint(1) DEFAULT NULL,
  `gate_pass` tinyint(1) DEFAULT NULL,
  `gate_ex` tinyint DEFAULT NULL,
  `purchase` tinyint(1) DEFAULT NULL,
  `inventory` tinyint(1) DEFAULT NULL,
  `product_registration` tinyint(1) DEFAULT NULL,
  `job_sheet` tinyint(1) DEFAULT NULL,
  `attendance_system` tinyint(1) DEFAULT NULL,
  `setup` tinyint(1) DEFAULT NULL,
  `setup_department` tinyint(1) DEFAULT NULL,
  `employee_department` tinyint(1) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `employee` tinyint(1) DEFAULT NULL,
  `wage_calculator` tinyint(1) DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1','1','Admin','superadmin@example.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','saYBJVOqLycCyYPEJbVjiOZCKPav0zETh3NLjs7LfDjho7gqOct7Zaprykng','2024-11-11 02:00:37','2025-07-29 01:07:02','','0','1');
INSERT INTO `users` VALUES ('99','1','Demo account','demo@gmail.com','0','1','0','1','0','1','0','1','0','1','1','1','0','0','1','$2y$12$FVF5Odqw0BiIPEcm1awHo.2h.qgQib60BUHM0ytmI59FP1kD/Ouzq','','Nt2zwqK23VxGdKXuGvBdDMu6iM1lysVdpmtusAey2nxyB2vjZJ3yIkoCZSAx','2025-04-16 01:07:51','2025-08-02 20:10:32','0','0','2');
INSERT INTO `users` VALUES ('127','3','Super Admin','admin@gmail.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','FJx353IEpjCwOZhXXF0D98CnnzGQYIpJJx5kIit8u3JsNTyRYM30qjIKBVEu','2025-07-29 01:07:55','2025-08-02 12:43:06','0','0','6');
INSERT INTO `users` VALUES ('128','0','ADMIN','','','','','','','','','','','','','','','','','','','','','','','','6');
INSERT INTO `users` VALUES ('133','1','Admin PremierTax','testing@gmail.com','','','','','','','','','','','','','','','','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','UIR77Yuj4NQoq2nJzlPd6MqGc4Eilm6kHz55V42zrv3UJZrC822JDP6bNwZ1','2025-09-20 14:31:38','2025-09-20 14:31:38','','','7');
INSERT INTO `users` VALUES ('135','0','checker','checker@gmail.com','','','','','','','','','','','','','','','','$2y$12$mbsiJxMffgyecJbj2TyVv.IrA61beiGt9psdl0xKcRUVCdUDaw0Qi','','','2025-11-06 02:09:49','2025-11-06 02:09:49','','','7');
INSERT INTO `users` VALUES ('136','1','Demo Wali','demowali@softix.com','','','','','','','','','','','','','','','','$2y$12$yKx.otTBaI.BnE7Zb14BY.egFQXOGrIF5FcC5duha0qw9w5NIpZKS','','','2025-11-10 13:53:44','2025-11-10 13:53:44','','','8');
INSERT INTO `users` VALUES ('137','1','SHahaan','shahaanltd@gmail.com','','','','','','','','','','','','','','','','$2y$12$MSY/g6jjiuxzYazpisJ34e3wReNJgggT1OTiz86EF2egFjTLFyE0.','','','2025-12-03 18:06:08','2025-12-03 18:06:08','','','9');


DROP TABLE IF EXISTS `workspace`;
CREATE TABLE `workspace` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `logo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `workspace` VALUES ('1','MK PLASTIC','','2026-01-25 22:38:34','uploads/1762760229mk.png','mkplasticgrw@gmail.com','Alam Chowk, Guranwala','','+92339 786 MK MK');
INSERT INTO `workspace` VALUES ('6','ADMIN','','','','','','','');
INSERT INTO `workspace` VALUES ('7','Premiertax','2025-09-20 14:29:16','2025-09-20 14:29:16','','','','','');
INSERT INTO `workspace` VALUES ('8','DEMO WALI','2025-11-10 13:53:22','2025-11-10 13:53:22','','','','','');
INSERT INTO `workspace` VALUES ('9','Shahaan Ltd','2025-12-03 17:49:18','2025-12-03 17:49:18','','','','','');


