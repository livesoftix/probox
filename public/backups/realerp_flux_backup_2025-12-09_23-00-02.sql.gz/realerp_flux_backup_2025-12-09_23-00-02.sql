-- Backup of realerp_flux on 2025-12-09_23-00-02

DROP TABLE IF EXISTS `account_masters`;
CREATE TABLE `account_masters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `opening_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `level2_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `account_masters` VALUES ('1','Purchase Debit Account','2025-09-17','0001','1','5','2025-09-18 00:57:32','2025-09-18 00:57:32');
INSERT INTO `account_masters` VALUES ('2','Allied Bank LTD','2025-09-17','0001','1','3','2025-09-18 00:58:29','2025-09-18 00:58:29');
INSERT INTO `account_masters` VALUES ('3','Cashier Account','2025-09-17','0001','1','4','2025-09-18 00:58:48','2025-09-18 00:58:56');
INSERT INTO `account_masters` VALUES ('6','Sale debit ACCOUNT','2025-09-18','0001','1','7','2025-09-18 12:34:43','2025-09-18 12:34:43');
INSERT INTO `account_masters` VALUES ('9','Testing Account','2025-09-21','0001','1','9','2025-09-22 01:06:20','2025-09-22 01:06:20');
INSERT INTO `account_masters` VALUES ('13','testuser Supplier','2025-09-22 18:55:12','0001','1','6','2025-09-22 18:55:12','2025-09-22 18:55:12');
INSERT INTO `account_masters` VALUES ('14','testuser Customer','2025-09-22 19:02:06','0001','1','8','2025-09-22 19:02:06','2025-09-22 19:02:06');
INSERT INTO `account_masters` VALUES ('16','Abc employee','2025-10-01','0001','1','11','2025-10-01 14:43:57','2025-10-01 14:43:57');
INSERT INTO `account_masters` VALUES ('17','Stock Account','2025-10-15','0001','7','16','2025-10-15 12:12:56','2025-10-15 12:12:56');
INSERT INTO `account_masters` VALUES ('18','DONE Supplier','2025-10-17 17:25:24','0001','7','13','2025-10-17 12:25:24','2025-10-17 12:25:24');
INSERT INTO `account_masters` VALUES ('20','Expense Account','2025-10-18','0001','7','17','2025-10-18 07:09:51','2025-10-18 07:09:51');
INSERT INTO `account_masters` VALUES ('22','Faizan Rajput Customer','2025-10-23 09:39:18','0003','1','8','2025-10-23 09:39:18','2025-10-23 09:39:18');
INSERT INTO `account_masters` VALUES ('28','Talha','2025-10-27 19:35:13','0001','7','12','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `account_masters` VALUES ('29','MA Plastic','2025-11-01 15:00:50','0004','1','8','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `account_masters` VALUES ('30','Supplier ABC','2025-11-07 00:20:07','0002','1','6','2025-11-07 00:20:07','2025-11-07 00:20:07');
INSERT INTO `account_masters` VALUES ('32','Raw Material Inventory','2025-11-10','0001','8','19','2025-11-10 14:10:36','2025-11-10 14:10:36');
INSERT INTO `account_masters` VALUES ('33','Office Supply','2025-11-10','0001','8','18','2025-11-10 14:16:17','2025-11-10 21:24:28');
INSERT INTO `account_masters` VALUES ('34','Mirza Muhammad Wali Baig','2025-11-10 21:35:11','0002','8','19','2025-11-10 21:35:11','2025-11-10 21:35:11');
INSERT INTO `account_masters` VALUES ('35','Mirza Muhammad Wali Baig','2025-11-10 21:48:39','0002','8','18','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `account_masters` VALUES ('37','Hafiz & Tariq','2025-11-23 17:21:32','0005','1','8','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `account_masters` VALUES ('38','Lucky Plastic','2025-11-23 17:24:38','0006','1','8','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `account_masters` VALUES ('39','Baber Plastic','2025-11-23 17:26:13','0007','1','8','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `account_masters` VALUES ('40','Sultan Crockery','2025-11-23 17:30:15','0008','1','8','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `account_masters` VALUES ('41','Imran Shani Basement','2025-11-23 17:31:29','0009','1','8','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `account_masters` VALUES ('42','Aneeq Plastic','2025-11-23 17:32:05','0010','1','8','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `account_masters` VALUES ('43','MAI Plastic','2025-11-23 17:32:44','0011','1','8','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `account_masters` VALUES ('44','Sheikh Mushtaq Plastic','2025-11-23 17:34:41','0012','1','8','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `account_masters` VALUES ('45','Subhan Plastic','2025-11-23 17:36:06','0013','1','8','2025-11-23 17:36:06','2025-11-23 17:36:06');
INSERT INTO `account_masters` VALUES ('46','Nawab Plastic','2025-11-23 17:40:44','0014','1','8','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `account_masters` VALUES ('47','Punjab Traders','2025-11-23 17:41:43','0015','1','8','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `account_masters` VALUES ('48','Madni Traders','2025-11-23 17:42:23','0016','1','8','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `account_masters` VALUES ('49','Umar Plastic','2025-11-23 17:46:18','0017','1','8','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `account_masters` VALUES ('50','Sajjad & Sons','2025-11-23 17:51:23','0018','1','8','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `account_masters` VALUES ('51','Chacha Dori Wala','2025-11-23 17:55:45','0019','1','8','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `account_masters` VALUES ('52','Kashif Crockery','2025-11-23 17:58:11','0020','1','8','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `account_masters` VALUES ('53','Zia Plastic','2025-11-23 17:59:17','0021','1','8','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `account_masters` VALUES ('54','Haider Plastic','2025-11-23 18:00:54','0022','1','8','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `account_masters` VALUES ('56','Al-Madad Plastic','2025-11-23 18:04:08','0024','1','8','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `account_masters` VALUES ('57','Mubarak Plastic','2025-11-23 18:57:17','0025','1','8','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `account_masters` VALUES ('58','Malik Ehsan Plastic','2025-11-23 18:59:48','0026','1','8','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `account_masters` VALUES ('59','Noshahi Qadri','2025-12-01 18:18:47','0027','1','8','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `account_masters` VALUES ('60','Saddique Traders','2025-12-01 18:19:52','0028','1','8','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `account_masters` VALUES ('61','Rafaqat Plastic','2025-12-01 18:26:46','0029','1','8','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `account_masters` VALUES ('62','Muneer Sb','2025-12-01 18:27:34','0030','1','8','2025-12-01 18:27:34','2025-12-01 18:27:34');
INSERT INTO `account_masters` VALUES ('63','Asif Plastic','2025-12-01 18:28:48','0031','1','8','2025-12-01 18:28:48','2025-12-01 18:28:48');
INSERT INTO `account_masters` VALUES ('64','ABD Plastic','2025-12-01 18:44:17','0032','1','8','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `account_masters` VALUES ('65','Ghazi Plastic','2025-12-01 18:45:49','0033','1','8','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `account_masters` VALUES ('66','Azan Plastic','2025-12-01 18:52:20','0034','1','8','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `account_masters` VALUES ('67','Sulman Plastic','2025-12-02 18:18:36','0035','1','8','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `account_masters` VALUES ('68','Waqas Plastic','2025-12-02 18:22:00','0036','1','8','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `account_masters` VALUES ('69','Raza Kitchenware','2025-12-02 18:22:59','0037','1','8','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `account_masters` VALUES ('70','Bin Bashir Plastic','2025-12-02 18:24:15','0038','1','8','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `account_masters` VALUES ('71','Khan Plastic','2025-12-02 18:45:45','0039','1','8','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `account_masters` VALUES ('72','Nadeem Traders','2025-12-02 18:57:01','0040','1','8','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `account_masters` VALUES ('73','Fajar Plastic','2025-12-02 19:01:13','0041','1','8','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `account_masters` VALUES ('74','Latif Crockery','2025-12-02 19:02:41','0042','1','8','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `account_masters` VALUES ('75','Haji Akram Traders','2025-12-02 19:25:22','0043','1','8','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `account_masters` VALUES ('77','Talha Plastic','2025-12-02 19:35:16','0045','1','8','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `account_masters` VALUES ('78','Mansha Plastic','2025-12-02 19:38:33','0046','1','8','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `account_masters` VALUES ('79','Zameer Plastic','2025-12-02 19:39:19','0047','1','8','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `account_masters` VALUES ('80','Shan Traders','2025-12-03 18:02:46','0048','1','8','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `account_masters` VALUES ('81','Mubarak Sheesha','2025-12-03 18:04:07','0049','1','8','2025-12-03 18:04:07','2025-12-03 18:04:07');
INSERT INTO `account_masters` VALUES ('82','Hafiz Abdullah','2025-12-03 18:04:48','0050','1','8','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `account_masters` VALUES ('83','M Taha Plastic','2025-12-03 18:10:24','0051','1','8','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `account_masters` VALUES ('84','Irfan Sulman Plastic','2025-12-03 19:11:54','0052','1','8','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `account_masters` VALUES ('85','Ahsan Plastic','2025-12-03 19:12:39','0053','1','8','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `account_masters` VALUES ('86','Shakar Plastic','2025-12-03 19:13:29','0054','1','8','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `account_masters` VALUES ('87','Iqbal Shaker Plastic','2025-12-03 19:14:45','0055','1','8','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `account_masters` VALUES ('88','Shoaib Traders','2025-12-03 19:16:05','0056','1','8','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `account_masters` VALUES ('89','Itefaq Traders','2025-12-03 19:34:22','0057','1','8','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `account_masters` VALUES ('90','Sufiyan Al Fajar Plastic','2025-12-03 19:34:51','0058','1','8','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `account_masters` VALUES ('91','Farhan Al Fajar Plastic','2025-12-03 19:38:02','0059','1','8','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `account_masters` VALUES ('92','Chand Plastic','2025-12-03 19:38:40','0060','1','8','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `account_masters` VALUES ('94','Umar Bhai Bhai Plastic','2025-12-04 19:37:34','0061','1','8','2025-12-04 19:37:34','2025-12-04 19:37:34');
INSERT INTO `account_masters` VALUES ('95','Extra','2025-12-04 19:45:06','0062','1','8','2025-12-04 19:45:06','2025-12-04 19:45:06');
INSERT INTO `account_masters` VALUES ('96','Extra','2025-12-04 19:45:20','0063','1','8','2025-12-04 19:45:20','2025-12-04 19:45:20');
INSERT INTO `account_masters` VALUES ('97','Extra','2025-12-04 19:45:40','0064','1','8','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `account_masters` VALUES ('98','Bhai Bhai Plastic','2025-12-04 19:51:40','0065','1','8','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `account_masters` VALUES ('99','Nawab Bartan Store','2025-12-04 19:53:29','0066','1','8','2025-12-04 19:53:29','2025-12-04 19:53:29');
INSERT INTO `account_masters` VALUES ('100','Suleman Plastic','2025-12-04 19:55:32','0067','1','8','2025-12-04 19:55:32','2025-12-04 19:55:32');
INSERT INTO `account_masters` VALUES ('101','Hafiz Bilal','2025-12-04 19:55:53','0068','1','8','2025-12-04 19:55:53','2025-12-04 19:55:53');
INSERT INTO `account_masters` VALUES ('102','Arif AA Plastic','2025-12-04 20:06:06','0069','1','8','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `account_masters` VALUES ('103','Farhad Sb','2025-12-06 11:36:13','0070','1','8','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `account_masters` VALUES ('104','M Ashraf Plastic','2025-12-06 11:45:48','0071','1','8','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `account_masters` VALUES ('105','Al Khair Plastic','2025-12-06 11:46:35','0072','1','8','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `account_masters` VALUES ('106','Bajor Plastic','2025-12-06 11:47:54','0073','1','8','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `account_masters` VALUES ('107','Nazer Plastic','2025-12-06 11:48:42','0074','1','8','2025-12-06 11:48:42','2025-12-06 11:48:42');
INSERT INTO `account_masters` VALUES ('108','Plastic Point','2025-12-06 11:49:35','0075','1','8','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `account_masters` VALUES ('109','Zaheer Plastic','2025-12-06 11:50:31','0076','1','8','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `account_masters` VALUES ('110','Sheikh Imran Plastic','2025-12-06 11:51:19','0077','1','8','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `account_masters` VALUES ('111','Gulshan Plastic','2025-12-06 11:52:11','0078','1','8','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `account_masters` VALUES ('112','Dilawar Plastic','2025-12-06 12:04:43','0079','1','8','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `account_masters` VALUES ('113','Fahad Ashfaq','2025-12-06 18:55:45','0080','1','8','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `account_masters` VALUES ('114','Mian Shahid Plastic','2025-12-06 18:56:54','0081','1','8','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `account_masters` VALUES ('115','Mian Abdul Razaq','2025-12-06 18:59:22','0082','1','8','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `account_masters` VALUES ('116','Sajad Plastic','2025-12-06 19:00:26','0083','1','8','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `account_masters` VALUES ('117','Mushtaq Brothers','2025-12-06 19:08:41','0084','1','8','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `account_masters` VALUES ('118','Ishfaq Mushtaq Plastic','2025-12-06 19:10:20','0085','1','8','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `account_masters` VALUES ('119','Sartaj Plastic','2025-12-06 19:13:56','0086','1','8','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `account_masters` VALUES ('120','Arif Plastic','2025-12-06 19:14:31','0087','1','8','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `account_masters` VALUES ('121','Swabi Crockery','2025-12-06 19:15:16','0088','1','8','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `account_masters` VALUES ('122','Ali Plastic','2025-12-06 19:36:41','0089','1','8','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `account_masters` VALUES ('123','Amir Plastic','2025-12-06 19:37:44','0090','1','8','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `account_masters` VALUES ('124','Hafiz Plastic','2025-12-06 19:40:48','0091','1','8','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `account_masters` VALUES ('126','Fauji Bartan Store','2025-12-06 19:44:06','0093','1','8','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `account_masters` VALUES ('128','Naseer Plastic','2025-12-06 19:46:31','0095','1','8','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `account_masters` VALUES ('129','Azeem Atari','2025-12-06 19:51:03','0096','1','8','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `account_masters` VALUES ('130','A Tawakal Plastic','2025-12-09 18:45:46','0097','1','8','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `account_masters` VALUES ('131','Shabeer Plastic','2025-12-09 18:46:38','0098','1','8','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `account_masters` VALUES ('132','Bila Brothers','2025-12-09 18:47:36','0099','1','8','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `account_masters` VALUES ('133','Zaryab Bartan Store','2025-12-09 18:49:45','0100','1','8','2025-12-09 18:49:45','2025-12-09 18:49:45');
INSERT INTO `account_masters` VALUES ('134','Pak China Crockery','2025-12-09 18:50:55','0101','1','8','2025-12-09 18:50:55','2025-12-09 18:50:55');
INSERT INTO `account_masters` VALUES ('135','Zaryal Khan','2025-12-09 18:51:31','0102','1','8','2025-12-09 18:51:31','2025-12-09 18:51:31');
INSERT INTO `account_masters` VALUES ('136','China Sale Center','2025-12-09 18:52:35','0103','1','8','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `account_masters` VALUES ('137','Saleem Plastic','2025-12-09 18:53:14','0104','1','8','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `account_masters` VALUES ('138','Raza Plastic','2025-12-09 20:17:08','0105','1','8','2025-12-09 20:17:08','2025-12-09 20:17:08');


DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` VALUES ('11','Talha','','','','Faizan','','','28','7','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `customers` VALUES ('12','MA Plastic','Gujranwala','Alam Chowk','','03446115519','','','29','1','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `customers` VALUES ('13','Mirza Muhammad Wali Baig','Gujranwala','Gujranwala, rahwali, Kashmir colony, house no.244/25','','03251568863','','','35','8','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `customers` VALUES ('15','Hafiz & Tariq','Lahore','','','03347022248','','','37','1','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `customers` VALUES ('16','Lucky Plastic','Lahore','','','03224252751','','','38','1','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `customers` VALUES ('17','Baber Plastic','Lahore','','','03214656210','','','39','1','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `customers` VALUES ('18','Sultan Crockery','Lahore','','','03224004826','','','40','1','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `customers` VALUES ('19','Imran Shani Basement','Lahore','','','03218894066','','','41','1','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `customers` VALUES ('20','Aneeq Plastic','Lahore','','','03024330398','','','42','1','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `customers` VALUES ('21','MAI Plastic','Lahore','','','03092232224','','','43','1','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `customers` VALUES ('22','Sheikh Mushtaq Plastic','Lahore','','','03099117726','','','44','1','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `customers` VALUES ('23','Subhan Plastic','Lahore','','','03014024432','','','45','1','2025-11-23 17:36:07','2025-11-23 17:36:07');
INSERT INTO `customers` VALUES ('24','Nawab Plastic','Lahore','','','03000432852','','','46','1','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `customers` VALUES ('25','Punjab Traders','Lahore','','','03084751026','','','47','1','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `customers` VALUES ('26','Madni Traders','Lahore','','','03034432896','','','48','1','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `customers` VALUES ('27','Umar Plastic','Lahore','','','03044018158','','','49','1','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `customers` VALUES ('28','Sajjad & Sons','Lahore','','','03234748194','','','50','1','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `customers` VALUES ('29','Chacha Dori Wala','Lahore','','','03244253653','','','51','1','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `customers` VALUES ('30','Kashif Crockery','Lahore','','','03054097607','','','52','1','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `customers` VALUES ('31','Zia Plastic','Lahore','','','03228007053','','','53','1','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `customers` VALUES ('32','Haider Plastic','Lahore','','','03334536476','','','54','1','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `customers` VALUES ('34','Al-Madad Plastic','Lahore','','','03214263909','','','56','1','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `customers` VALUES ('35','Mubarak Plastic','Lahore','','','03229486984','','','57','1','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `customers` VALUES ('36','Malik Ehsan Plastic','Lahore','','','03214655001','','','58','1','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `customers` VALUES ('37','Noshahi Qadri','Lahore','','','03096605105','','','59','1','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `customers` VALUES ('38','Saddique Traders','Lahore','','','03004255488','','','60','1','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `customers` VALUES ('39','Rafaqat Plastic','Lahore','','','03211671661','','','61','1','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `customers` VALUES ('40','Muneer Sb','Lahore','','','03004244186','','','62','1','2025-12-01 18:27:34','2025-12-01 18:35:58');
INSERT INTO `customers` VALUES ('41','Asif Plastic','Noor Gali, Lahore','','','03214260098','','','63','1','2025-12-01 18:28:48','2025-12-02 18:05:09');
INSERT INTO `customers` VALUES ('42','ABD Plastic','Alam Chowk, Gujranwala','','','03018838164','','','64','1','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `customers` VALUES ('43','Ghazi Plastic','Alam Chowk, Gujranwala','','','03456811257','','','65','1','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `customers` VALUES ('44','Azan Plastic','Alam Chowk, Gujranwala','','','03334697700','','','66','1','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `customers` VALUES ('45','Sulman Plastic','Alam Chowk, Gujranwala','','','03446575017','','','67','1','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `customers` VALUES ('46','Waqas Plastic','Alam Chowk, Gujranwala','','','03066401660','','','68','1','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `customers` VALUES ('47','Raza Kitchenware','Alam Chowk, Gujranwala','','','03126412995','','','69','1','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `customers` VALUES ('48','Bin Bashir Plastic','Alam Chowk, Gujranwala','','','03107345310','','','70','1','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `customers` VALUES ('49','Khan Plastic','Alam Chowk, Gujranwala','','','03216495351','','','71','1','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `customers` VALUES ('50','Nadeem Traders','Alam Chowk, Gujranwala','','','03421679610','','','72','1','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `customers` VALUES ('51','Fajar Plastic','Alam Chowk, Gujranwala','','','03480163684','','','73','1','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `customers` VALUES ('52','Latif Crockery','Alam Chowk, Gujranwala','','','03129647925','','','74','1','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `customers` VALUES ('53','Haji Akram Traders','Alam Chowk, Gujranwala','','','03005551741','','','75','1','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `customers` VALUES ('55','Talha Plastic','Alam Chowk, Gujranwala','','','03216492229','','','77','1','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `customers` VALUES ('56','Mansha Plastic','Alam Chowk, Gujranwala','','','03197181508','','','78','1','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `customers` VALUES ('57','Zameer Plastic','Alam Chowk, Gujranwala','','','03006460799','','','79','1','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `customers` VALUES ('58','Shan Traders','Alam Chowk, Gujranwala','','','03205436229','','','80','1','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `customers` VALUES ('59','Mubarak Sheesha','Alam Chowk, Gujranwala','','','03096710402','','','81','1','2025-12-03 18:04:07','2025-12-03 18:04:07');
INSERT INTO `customers` VALUES ('60','Hafiz Abdullah','Alam Chowk, Gujranwala','','','03496281208','','','82','1','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `customers` VALUES ('61','M Taha Plastic','Alam Chowk, Gujranwala','','','03200471840','','','83','1','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `customers` VALUES ('62','Irfan Sulman Plastic','Alam Chowk, Gujranwala','','','03144243128','','','84','1','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `customers` VALUES ('63','Ahsan Plastic','Alam Chowk, Gujranwala','','','03070183476','','','85','1','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `customers` VALUES ('64','Shakar Plastic','Alam Chowk, Gujranwala','','','03217150849','','','86','1','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `customers` VALUES ('65','Iqbal Shaker Plastic','Alam Chowk, Gujranwala','','','03280234237','','','87','1','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `customers` VALUES ('66','Shoaib Traders','Alam Chowk, Gujranwala','','','03005006478','','','88','1','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `customers` VALUES ('67','Itefaq Traders','Alam Chowk, Gujranwala','','','03004085189','','','89','1','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `customers` VALUES ('68','Sufiyan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03013182275','','','90','1','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `customers` VALUES ('69','Farhan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03227600077','','','91','1','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `customers` VALUES ('70','Chand Plastic','Alam Chowk, Gujranwala','','','03041241700','','','92','1','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `customers` VALUES ('72','Umar Bhai Bhai Plastic','Alam Chowk, Gujranwala','','','03426014070','','','94','1','2025-12-04 19:37:34','2025-12-09 19:58:20');
INSERT INTO `customers` VALUES ('73','Master Plastic','Alam Chowk, Gujranwala','','','03707099846','','','95','1','2025-12-04 19:45:06','2025-12-06 19:17:44');
INSERT INTO `customers` VALUES ('74','Extra','Alam Chowk, Gujranwala','','','0332223','','','96','1','2025-12-04 19:45:20','2025-12-04 19:45:20');
INSERT INTO `customers` VALUES ('75','Extra','Alam Chowk, Gujranwala','','','0332223','','','97','1','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `customers` VALUES ('76','Bhai Bhai Plastic','Khiali Darwaza, Gujranwala','','','03237486600','','','98','1','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `customers` VALUES ('77','Nawab Bartan Store','Khiali Darwaza, Gujranwala','','','03059999456','','','99','1','2025-12-04 19:53:29','2025-12-09 19:58:49');
INSERT INTO `customers` VALUES ('78','Suleman Plastic','Khiali Darwaza, Gujranwala','','','03082809552','','','100','1','2025-12-04 19:55:32','2025-12-09 19:59:34');
INSERT INTO `customers` VALUES ('79','Hafiz Bilal','Khiali Darwaza, Gujranwala','','','03060360126','','','101','1','2025-12-04 19:55:53','2025-12-09 20:00:04');
INSERT INTO `customers` VALUES ('80','Arif AA Plastic','Guranwala','','','03216405344','','','102','1','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `customers` VALUES ('81','Farhad Sb','Gujranwala','','','03217150849','','','103','1','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `customers` VALUES ('82','M Ashraf Plastic','Muslim Road, Gujranwala','','','03207835189','','','104','1','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `customers` VALUES ('83','Al Khair Plastic','Muslim Road, Gujranwala','','','03216400025','','','105','1','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `customers` VALUES ('84','Bajor Plastic','Karachi','','','03170805866','','','106','1','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `customers` VALUES ('85','Nazer Plastic','Landhi, Karachi','','','03332226851','','','107','1','2025-12-06 11:48:42','2025-12-09 20:00:50');
INSERT INTO `customers` VALUES ('86','Plastic Point','New, Karachi','','','03222030176','','','108','1','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `customers` VALUES ('87','Zaheer Plastic','Lee Market, Karachi','','','03332292780','','','109','1','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `customers` VALUES ('88','Sheikh Imran Plastic','Jona Market, Karachi','','','03333949228','','','110','1','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `customers` VALUES ('89','Gulshan Plastic','New Karachi','','','03158486252','','','111','1','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `customers` VALUES ('90','Dilawar Plastic','Landhi, Karachi','','','03332821426','','','112','1','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `customers` VALUES ('91','Fahad Ashfaq','Kotla','','','03245853791','','','113','1','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `customers` VALUES ('92','Mian Shahid Plastic','Lala Moosa','','','03478134855','','','114','1','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `customers` VALUES ('93','Mian Abdul Razaq','Lala Moosa','','','03144411341','','','115','1','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `customers` VALUES ('94','Sajad Plastic','Dinga','','','03456945048','','','116','1','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `customers` VALUES ('95','Mushtaq Brothers','Mardan','','','03321565300','','','117','1','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `customers` VALUES ('96','Ishfaq Mushtaq Plastic','Mardan','','','03149780127','','','118','1','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `customers` VALUES ('97','Sartaj Plastic','Mardan','','','03005725121','','','119','1','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `customers` VALUES ('98','Arif Plastic','Swabi','','','03120900981','','','120','1','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `customers` VALUES ('99','Swabi Crockery','Swabi','','','03471979388','','','121','1','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `customers` VALUES ('100','Ali Plastic','Shahdra','','','03004695613','','','122','1','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `customers` VALUES ('101','Amir Plastic','Baigham Kot','','','03214457644','','','123','1','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `customers` VALUES ('102','Hafiz Plastic','Raiwind','','','03014748132','','','124','1','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `customers` VALUES ('104','Fauji Bartan Store','Raiwind','','','03004058257','','','126','1','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `customers` VALUES ('106','Naseer Plastic','Raiwind','','','03069716413','','','128','1','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `customers` VALUES ('107','Azeem Atari','Raiwind','','','03234982902','','','129','1','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `customers` VALUES ('108','A Tawakal Plastic','Qainchi, Lahore','','','03084295626','','','130','1','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `customers` VALUES ('109','Shabeer Plastic','Qasoor','','','03236758687','','','131','1','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `customers` VALUES ('110','Bila Brothers','Rawalpindi','','','03005120936','','','132','1','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `customers` VALUES ('111','Zaryab Bartan Store','Rawalpindi','','','03484582462','','','133','1','2025-12-09 18:49:45','2025-12-09 20:01:47');
INSERT INTO `customers` VALUES ('112','Pak China Crockery','Islamabad','','','03365069852','','','134','1','2025-12-09 18:50:55','2025-12-09 20:02:32');
INSERT INTO `customers` VALUES ('113','Zaryal Khan','Peshawar','','','03119012200','','','135','1','2025-12-09 18:51:31','2025-12-09 20:03:03');
INSERT INTO `customers` VALUES ('114','China Sale Center','Ahmadpur Sharkia','','','03062611675','','','136','1','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `customers` VALUES ('115','Saleem Plastic','Multan','','','03067845688','','','137','1','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `customers` VALUES ('116','Raza Plastic','Haroonabad','','','03009185706','','','138','1','2025-12-09 20:17:08','2025-12-09 20:17:08');


DROP TABLE IF EXISTS `erp_params`;
CREATE TABLE `erp_params` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_level` bigint unsigned DEFAULT NULL,
  `employee_level` bigint DEFAULT NULL,
  `employee_advance` bigint DEFAULT NULL,
  `bank_level` bigint unsigned DEFAULT NULL,
  `supplier_level` bigint unsigned DEFAULT NULL,
  `purchase_account` bigint unsigned DEFAULT NULL,
  `purchase_return_account` int DEFAULT NULL,
  `sale_ac` bigint unsigned DEFAULT NULL,
  `customer_level` bigint unsigned DEFAULT NULL,
  `cash_acc` bigint unsigned DEFAULT NULL,
  `pur_freight` bigint unsigned DEFAULT NULL,
  `pur_freight_exp` int DEFAULT NULL,
  `sale_freight` int DEFAULT NULL,
  `sale_freight_exp` int DEFAULT NULL,
  `salary_level` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `purchase_debit_account` bigint unsigned DEFAULT NULL,
  `saleCreditAccount` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `erp_params_saledebitaccount_foreign` (`saleCreditAccount`),
  CONSTRAINT `erp_params_saledebitaccount_foreign` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sale_debit_account` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `erp_params` VALUES ('3','4','','','3','6','','','','8','2','','','','','','2025-09-18 00:51:19','2025-10-27 14:29:03','1','9','2');
INSERT INTO `erp_params` VALUES ('4','15','','','14','13','17','','','12','','','','','','','2025-10-15 12:13:14','2025-10-17 12:55:48','7','17','');
INSERT INTO `erp_params` VALUES ('5','18','','','18','19','','','','18','','','','','','','2025-11-10 14:15:38','2025-11-10 21:48:18','8','','');


DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `groups` VALUES ('1','Capital','01','','');
INSERT INTO `groups` VALUES ('2','Liabilities','02','','');
INSERT INTO `groups` VALUES ('3','Assets','03','','');
INSERT INTO `groups` VALUES ('4','Revenue','04','','');
INSERT INTO `groups` VALUES ('5','Expenses','05','','');


DROP TABLE IF EXISTS `item_detail`;
CREATE TABLE `item_detail` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `crt_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crt_qty` bigint unsigned DEFAULT NULL,
  `crt_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_detail` VALUES ('21','9','7','20x12 Tester','120','20000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('22','9','7','32x12','250','50000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('26','10','1','1*108','108','12420','2025-11-01 17:15:17','2025-11-01 17:15:17');
INSERT INTO `item_detail` VALUES ('33','14','8','20x12','12','12','2025-11-10 21:39:53','2025-11-10 21:39:53');
INSERT INTO `item_detail` VALUES ('35','11','1','1*108','108','8964','2025-12-07 11:34:26','2025-12-07 11:34:26');
INSERT INTO `item_detail` VALUES ('36','12','1','1*72','72','0','2025-12-07 11:35:18','2025-12-07 11:35:18');
INSERT INTO `item_detail` VALUES ('37','13','1','1*72','72','13320','2025-12-07 11:40:08','2025-12-07 11:40:08');
INSERT INTO `item_detail` VALUES ('38','16','1','1*72','72','7128','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_detail` VALUES ('39','17','1','1*72','72','10584','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_detail` VALUES ('40','18','1','1*72','72','0','2025-12-07 12:15:34','2025-12-07 12:15:34');


DROP TABLE IF EXISTS `item_master`;
CREATE TABLE `item_master` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `purchase_rate` bigint unsigned DEFAULT NULL,
  `sale_rate` bigint unsigned DEFAULT NULL,
  `qty_pcs` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_master` VALUES ('9','TESTE ITEM','6','8','100','200','100','7','2025-10-27 19:13:27','2025-10-27 19:22:23');
INSERT INTO `item_master` VALUES ('10','3 Liter Pure','10','6','0','115','108','1','2025-10-27 19:43:14','2025-10-27 19:43:14');
INSERT INTO `item_master` VALUES ('11','3 Liter Semi','10','6','0','83','108','1','2025-10-27 19:44:21','2025-10-27 19:44:21');
INSERT INTO `item_master` VALUES ('12','3 Liter Silver','10','6','0','0','72','1','2025-10-27 20:13:12','2025-12-07 11:35:18');
INSERT INTO `item_master` VALUES ('13','6 Liter Pure','10','6','0','185','72','1','2025-11-08 16:10:29','2025-12-07 11:40:08');
INSERT INTO `item_master` VALUES ('14','DROSPA 25 X 2ml AMPOULES INJECTION','13','9','123','123','123','8','2025-11-10 21:39:11','2025-11-10 21:39:44');
INSERT INTO `item_master` VALUES ('16','6 Liter Semi','10','6','0','99','72','1','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_master` VALUES ('17','6 Liter Trim','10','6','0','147','72','1','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_master` VALUES ('18','6 Liter Silver','10','6','0','0','72','1','2025-12-07 12:15:34','2025-12-07 12:15:34');


DROP TABLE IF EXISTS `item_types`;
CREATE TABLE `item_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_types` VALUES ('1','','Shampoo','2025-09-17 18:33:21','2025-09-17 18:33:21','2');
INSERT INTO `item_types` VALUES ('5','fp','Shampo','2025-10-15 08:35:53','2025-10-15 08:38:30','7');
INSERT INTO `item_types` VALUES ('6','rp','ShampoRAW','2025-10-15 10:16:16','2025-10-15 10:16:16','7');
INSERT INTO `item_types` VALUES ('10','','Buckets','2025-10-25 18:54:20','2025-10-25 18:54:20','1');
INSERT INTO `item_types` VALUES ('13','','laminations','2025-11-10 21:36:03','2025-11-10 21:36:10','8');


DROP TABLE IF EXISTS `level1s`;
CREATE TABLE `level1s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level1s` VALUES ('2','Current Assets','01','3','2025-09-17 18:49:15','2025-09-17 18:49:15','2');
INSERT INTO `level1s` VALUES ('3','Current Assets','01','3','2025-09-18 00:40:07','2025-11-08 00:44:53','1');
INSERT INTO `level1s` VALUES ('4','Direct Expense','01','5','2025-09-18 00:55:45','2025-09-18 00:55:45','1');
INSERT INTO `level1s` VALUES ('5','Current Liabilities','01','2','2025-09-18 01:09:06','2025-09-18 01:09:06','1');
INSERT INTO `level1s` VALUES ('6','Current Revenue','01','4','2025-09-18 12:33:46','2025-09-18 12:33:46','1');
INSERT INTO `level1s` VALUES ('7','Current Assets','01','3','2025-09-20 14:32:26','2025-09-20 14:32:26','7');
INSERT INTO `level1s` VALUES ('8','Current Liabilities','01','2','2025-09-20 14:32:38','2025-09-20 14:32:38','7');
INSERT INTO `level1s` VALUES ('9','Capital','01','1','2025-09-22 01:03:53','2025-10-25 18:32:57','1');
INSERT INTO `level1s` VALUES ('11','Direct Expense','01','5','2025-10-15 12:12:20','2025-10-15 12:12:20','7');
INSERT INTO `level1s` VALUES ('12','Current Asset','01','3','2025-11-10 14:06:48','2025-11-10 14:09:09','8');
INSERT INTO `level1s` VALUES ('13','Long-Term Liabilities','01','2','2025-11-10 14:07:06','2025-11-10 14:07:06','8');
INSERT INTO `level1s` VALUES ('14','Sales Revenue','01','4','2025-11-10 14:07:21','2025-11-10 14:07:21','8');


DROP TABLE IF EXISTS `level2s`;
CREATE TABLE `level2s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level2_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level2s` VALUES ('2','Bank Accounts','001','2','2025-09-17 18:50:09','2025-09-17 18:50:09','2');
INSERT INTO `level2s` VALUES ('3','Bank Accounts','001','3','2025-09-18 00:53:57','2025-09-18 00:53:57','1');
INSERT INTO `level2s` VALUES ('4','Cash Accounts','002','3','2025-09-18 00:54:07','2025-09-18 00:54:07','1');
INSERT INTO `level2s` VALUES ('5','Purchase Debit Level','001','4','2025-09-18 00:56:18','2025-09-18 00:56:18','1');
INSERT INTO `level2s` VALUES ('6','Suppliers','001','5','2025-09-18 01:09:20','2025-09-18 01:09:20','1');
INSERT INTO `level2s` VALUES ('7','Sale Credit Accunts','001','6','2025-09-18 12:34:10','2025-09-22 10:44:03','1');
INSERT INTO `level2s` VALUES ('8','Customer','002','5','2025-09-18 16:21:49','2025-09-18 16:21:49','1');
INSERT INTO `level2s` VALUES ('9','Caiptal Account','001','9','2025-09-22 01:05:14','2025-10-25 18:33:23','1');
INSERT INTO `level2s` VALUES ('11','Employees','003','5','2025-10-01 14:43:39','2025-10-01 14:43:39','1');
INSERT INTO `level2s` VALUES ('12','Customers','001','7','2025-10-15 12:10:40','2025-10-15 12:10:59','7');
INSERT INTO `level2s` VALUES ('13','Supplier','002','8','2025-10-15 12:10:51','2025-10-15 12:10:51','7');
INSERT INTO `level2s` VALUES ('14','Bank Accounts','002','7','2025-10-15 12:11:30','2025-10-15 12:11:30','7');
INSERT INTO `level2s` VALUES ('15','Cash Accounts','003','7','2025-10-15 12:11:44','2025-10-15 12:11:44','7');
INSERT INTO `level2s` VALUES ('16','Purchase Accounts','001','11','2025-10-15 12:12:39','2025-10-15 12:12:39','7');
INSERT INTO `level2s` VALUES ('17','Expense','002','11','2025-10-18 07:09:16','2025-10-18 07:09:16','7');
INSERT INTO `level2s` VALUES ('18','Cash & Banks','001','12','2025-11-10 14:09:33','2025-11-10 21:23:02','8');
INSERT INTO `level2s` VALUES ('19','Inventory','002','12','2025-11-10 14:09:50','2025-11-10 14:09:50','8');


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1','2019_12_14_000001_create_personal_access_tokens_table','1');
INSERT INTO `migrations` VALUES ('2','2025_09_18_120600_create_purchase_return_masters_table','2');
INSERT INTO `migrations` VALUES ('3','2025_09_18_120750_create_purchase_return_invoices_table','2');
INSERT INTO `migrations` VALUES ('4','2025_09_18_134602_create_customers_table','3');
INSERT INTO `migrations` VALUES ('5','2025_09_18_135718_create_sale_invoice_table','4');
INSERT INTO `migrations` VALUES ('6','2025_09_18_140058_create_sale_invoice_return_table','4');
INSERT INTO `migrations` VALUES ('7','2025_09_19_172738_create_sale_return_masters_table','5');
INSERT INTO `migrations` VALUES ('8','2025_09_19_184055_create_sale_return_invoices_table','5');
INSERT INTO `migrations` VALUES ('9','2025_09_20_155910_add_cid_to_item_logs_table','6');
INSERT INTO `migrations` VALUES ('10','2025_10_15_133111_add_item_type_to_item_type_table','7');
INSERT INTO `migrations` VALUES ('11','2025_10_15_151806_add_col_to_item_masters_table','8');
INSERT INTO `migrations` VALUES ('16','2025_10_15_152737_create_production_master_table','9');
INSERT INTO `migrations` VALUES ('17','2025_10_15_153012_create_production_detail_table','9');
INSERT INTO `migrations` VALUES ('20','2025_10_15_170406_create_consumption_masters_table','10');
INSERT INTO `migrations` VALUES ('21','2025_10_15_170412_create_consumption_details_table','10');
INSERT INTO `migrations` VALUES ('22','2025_10_16_003713_create_stock_adj_master_table','11');
INSERT INTO `migrations` VALUES ('23','2025_10_16_003734_create_stock_adj_table','11');
INSERT INTO `migrations` VALUES ('24','2025_10_16_005456_add_col_open_qty_to_item_masters_table','12');
INSERT INTO `migrations` VALUES ('27','2025_10_16_123138_create_production_consumed_table','13');
INSERT INTO `migrations` VALUES ('28','2025_10_17_191353_update_col_supplier_table','14');
INSERT INTO `migrations` VALUES ('29','2025_10_18_102053_add_col_to_production_master_table','15');
INSERT INTO `migrations` VALUES ('30','2025_10_18_115508_create_expense_detail_table','16');
INSERT INTO `migrations` VALUES ('31','2025_10_18_115646_create_expense_masters_table','16');
INSERT INTO `migrations` VALUES ('32','2025_10_22_011511_create_store_table','17');
INSERT INTO `migrations` VALUES ('34','2025_10_22_012808_create_item_master_table','18');
INSERT INTO `migrations` VALUES ('35','2025_10_22_013455_item_detail_table','19');
INSERT INTO `migrations` VALUES ('36','2025_10_22_023123_add_col_crt_qty_to_item_detail_table','20');
INSERT INTO `migrations` VALUES ('37','2025_10_22_125703_create_sale_invoices_table','21');
INSERT INTO `migrations` VALUES ('38','2025_10_22_125729_create_sale_invoice_items_table','22');
INSERT INTO `migrations` VALUES ('39','2025_10_22_130403_add_col_to_sale_invoice_items_table','23');
INSERT INTO `migrations` VALUES ('40','2025_10_22_130431_add_col_to_sale_invoices_table','23');
INSERT INTO `migrations` VALUES ('41','2025_10_22_140206_add_col_to_sale_invoices_table','24');
INSERT INTO `migrations` VALUES ('42','2025_10_22_140302_add_col_to_sale_invoice_items_table','25');
INSERT INTO `migrations` VALUES ('43','2025_10_22_170145_drop_col_to_sale_invoice_items_table','26');
INSERT INTO `migrations` VALUES ('44','2025_10_22_185204_add_col_to_sale_invoice_items_table','27');
INSERT INTO `migrations` VALUES ('45','2025_10_22_185548_drop_col_to_sale_invoice_items_table','28');
INSERT INTO `migrations` VALUES ('46','2025_10_22_192840_add_col_to_sale_invoice_table','29');
INSERT INTO `migrations` VALUES ('47','2025_10_22_200851_create_purchase_invoice_table','30');
INSERT INTO `migrations` VALUES ('48','2025_10_22_201052_create_purchase_invoice_item_table','31');
INSERT INTO `migrations` VALUES ('49','2025_10_23_000629_create_sale_return_invoice_table','32');
INSERT INTO `migrations` VALUES ('50','2025_10_23_000716_create_sale_return_invoice_item_table','32');
INSERT INTO `migrations` VALUES ('51','2025_10_23_015807_create_purchase_return_invoice_table','33');
INSERT INTO `migrations` VALUES ('52','2025_10_23_015816_create_purchase_return_invoice_item_table','33');
INSERT INTO `migrations` VALUES ('53','2025_10_23_170510_create_opening_stocks_table','34');
INSERT INTO `migrations` VALUES ('54','2025_10_23_181824_create_stock_adjustment_table','35');
INSERT INTO `migrations` VALUES ('55','2025_10_23_183745_add_col_to_sale_return_details_table','35');
INSERT INTO `migrations` VALUES ('56','2025_10_23_183950_add_col_to_purchase_invoice_details_table','35');
INSERT INTO `migrations` VALUES ('57','2025_10_23_184021_add_col_to_purchase_return_details_table','35');
INSERT INTO `migrations` VALUES ('58','2025_10_24_121456_add_p_qty_to_sale_invoice_details','36');
INSERT INTO `migrations` VALUES ('59','2025_10_24_121534_add_p_qty_to_purchase_invoice_details','36');
INSERT INTO `migrations` VALUES ('60','2025_10_24_121613_add_p_qty_to_purchase_return_details','36');
INSERT INTO `migrations` VALUES ('61','2025_10_24_121620_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('62','2025_10_24_125612_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('63','2025_10_24_144509_add_p_qty_to_opening_stocks_table','36');
INSERT INTO `migrations` VALUES ('64','2025_10_24_144607_add_p_qty_to_stock_adjustment_table','36');
INSERT INTO `migrations` VALUES ('65','2025_11_05_011214_add_col_to_purchase_invoice_masters_table','37');
INSERT INTO `migrations` VALUES ('66','2025_11_05_011427_add_col_to_sale_invoices_masters_table','37');


DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `module` VALUES ('1','Level1','','');
INSERT INTO `module` VALUES ('2','Level2','','');
INSERT INTO `module` VALUES ('3','Chart Of Account','','');
INSERT INTO `module` VALUES ('4','Cash Payment','','');
INSERT INTO `module` VALUES ('5','Cash Receipt','','');
INSERT INTO `module` VALUES ('6','Bank Payment','','');
INSERT INTO `module` VALUES ('7','Bank Receipt','','');
INSERT INTO `module` VALUES ('8','Journal Voucher','','');
INSERT INTO `module` VALUES ('9','Opening Balance','','');
INSERT INTO `module` VALUES ('10','Ledger','','');
INSERT INTO `module` VALUES ('11','Cash Book','','');
INSERT INTO `module` VALUES ('12','Payables','','');
INSERT INTO `module` VALUES ('13','Recieveable','','');
INSERT INTO `module` VALUES ('14','Trial Balance','','');
INSERT INTO `module` VALUES ('15','Purchase Invoice','','');
INSERT INTO `module` VALUES ('16','Purchase Return Invoice','','');
INSERT INTO `module` VALUES ('17','Supplier','','');
INSERT INTO `module` VALUES ('18','Sale Invoice','','');
INSERT INTO `module` VALUES ('19','Sale Return Invoice','','');
INSERT INTO `module` VALUES ('20','Customer','','');
INSERT INTO `module` VALUES ('21','Item Category','','');
INSERT INTO `module` VALUES ('22','Units','','');
INSERT INTO `module` VALUES ('23','Store','','');
INSERT INTO `module` VALUES ('24','Item Registration','','');
INSERT INTO `module` VALUES ('25','Stock Adjustment','','');
INSERT INTO `module` VALUES ('26','Stock Report','','');
INSERT INTO `module` VALUES ('27','ERP Parameters','','');
INSERT INTO `module` VALUES ('28','Item Registration Log','','');
INSERT INTO `module` VALUES ('29','App Module','','');
INSERT INTO `module` VALUES ('30','View Company','','');
INSERT INTO `module` VALUES ('36','Store Wise Report','2025-10-05 22:18:19','2025-10-05 22:18:19');
INSERT INTO `module` VALUES ('37','Brand Name','','');
INSERT INTO `module` VALUES ('39','Opening Stock','','');


DROP TABLE IF EXISTS `opening_stocks`;
CREATE TABLE `opening_stocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `opening_stocks` VALUES ('2','7','9','22','3','2025-10-27','1.00','0.00','50000.00','100.00','50000.00','','2025-10-27 19:23:27','2025-10-27 19:23:27','250');


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_details`;
CREATE TABLE `purchase_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_masters`;
CREATE TABLE `purchase_invoice_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_return_details`;
CREATE TABLE `purchase_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_details` VALUES ('11','1','1','11','1','7','24','0.00','0.00','0.00','1.00','83.00','83.00','0.00','83.00','2025-11-10 23:14:24','2025-11-10 23:14:24','2025-11-10','108');


DROP TABLE IF EXISTS `purchase_return_masters`;
CREATE TABLE `purchase_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_masters` VALUES ('11','1','2025-11-10','7','','0.00','0.00','0.00','83.00','-3358.00','1','2025-11-10 23:14:24','2025-11-10 23:14:24');


DROP TABLE IF EXISTS `purchase_returns`;
CREATE TABLE `purchase_returns` (
  `id` bigint unsigned NOT NULL,
  `vorcher_no` int NOT NULL,
  `width` float NOT NULL,
  `lenght` float NOT NULL,
  `grammage` float NOT NULL,
  `qty` float NOT NULL,
  `rate` float NOT NULL,
  `total_wt` float NOT NULL,
  `amount` float NOT NULL,
  `item_code` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `freight` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `rights`;
CREATE TABLE `rights` (
  `id` int NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `app_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add` tinyint(1) DEFAULT '0',
  `del` tinyint(1) DEFAULT '0',
  `edit` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_invoice_details`;
CREATE TABLE `sale_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoice_details` VALUES ('51','1','3','9','21','100.00','200.00','20000.00','12.00','20000.00','240000.00','0.00','260000.00','2025-11-05 02:02:24','2025-11-05 02:02:24','7','11','2025-10-28','120');
INSERT INTO `sale_invoice_details` VALUES ('54','2','3','9','21','0.00','200.00','0.00','10.00','20000.00','200000.00','0.00','200000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','11','2025-11-05','120');
INSERT INTO `sale_invoice_details` VALUES ('57','1','4','14','33','11.00','123.00','1353.00','1.00','12.00','12.00','1.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','13','2025-11-10','12');
INSERT INTO `sale_invoice_details` VALUES ('63','1','2','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2025-12-02 18:08:54','2025-12-02 18:08:54','1','15','2025-12-01','108');
INSERT INTO `sale_invoice_details` VALUES ('64','2','1','12','25','50.00','185.00','9250.00','2.00','185.00','370.00','10.00','8658.00','2025-12-03 19:24:09','2025-12-03 19:24:09','1','16','2025-12-01','72');


DROP TABLE IF EXISTS `sale_invoices_masters`;
CREATE TABLE `sale_invoices_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) DEFAULT NULL,
  `grand_crt_total` decimal(16,2) DEFAULT NULL,
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_balance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoices_masters` VALUES ('26','1','2025-10-28','11','','','','0.00','260000.00','2025-10-28 19:43:09','2025-11-05 02:02:24','7','0','1000');
INSERT INTO `sale_invoices_masters` VALUES ('33','2','2025-11-05','11','','','','0.00','202000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','261000','2000');
INSERT INTO `sale_invoices_masters` VALUES ('36','1','2025-11-10','13','red','','','0.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','0','0');
INSERT INTO `sale_invoices_masters` VALUES ('39','1','2025-12-01','15','','','','0.00','12178.00','2025-12-02 18:08:54','2025-12-02 18:08:54','1','0','1000');
INSERT INTO `sale_invoices_masters` VALUES ('40','2','2025-12-03','16','','','','2.00','8635.00','2025-12-03 19:24:09','2025-12-03 19:24:09','1','0','150');


DROP TABLE IF EXISTS `sale_return_details`;
CREATE TABLE `sale_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_return_details` VALUES ('15','1','1','10','1','15','26','0.00','115.00','0.00','1.00','12420.00','12420.00','0.00','12420.00','2025-12-02 12:52:07','2025-12-02 12:52:07','2025-12-02','108');


DROP TABLE IF EXISTS `sale_return_masters`;
CREATE TABLE `sale_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_return_invoice_invoice_no_unique` (`invoice_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_return_masters` VALUES ('11','1','2025-12-02','15','','0.00','0.00','0.00','12420.00','13420.00','1','2025-12-02 12:52:07','2025-12-02 12:52:07');


DROP TABLE IF EXISTS `sale_type`;
CREATE TABLE `sale_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_type` VALUES ('1','Taxable','2','2025-09-17 18:40:38','2025-09-17 18:40:38');
INSERT INTO `sale_type` VALUES ('3','Taxable','1','2025-09-22 10:34:37','2025-09-22 10:34:37');
INSERT INTO `sale_type` VALUES ('5','Exempt','1','2025-09-23 17:24:32','2025-09-23 17:24:32');
INSERT INTO `sale_type` VALUES ('7','Exempt','7','2025-10-15 10:20:19','2025-10-15 10:20:19');


DROP TABLE IF EXISTS `stock_adj_details`;
CREATE TABLE `stock_adj_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adj_details` VALUES ('2','1','7','-100','100','0','7','2025-10-17 21:12:41','2025-10-17 21:12:41');
INSERT INTO `stock_adj_details` VALUES ('3','2','7','-20','100','0','7','2025-10-17 21:13:05','2025-10-17 21:13:05');


DROP TABLE IF EXISTS `stock_adj_masters`;
CREATE TABLE `stock_adj_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` bigint unsigned NOT NULL,
  `v_date` date NOT NULL,
  `prepared_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `stock_adjustment`;
CREATE TABLE `stock_adjustment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adjustment` VALUES ('5','7','9','22','3','2025-10-27','-1.00','100.00','50000.00','100.00','-40000.00','','2025-10-27 19:25:13','2025-10-27 19:25:13','250');


DROP TABLE IF EXISTS `stock_qty`;
;

INSERT INTO `stock_qty` VALUES ('51','1','2025-10-28','9','0','0','0','1540','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('54','2','2025-11-05','9','0','0','0','1200','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('57','1','2025-11-10','14','0','0','0','23','0','0','12','4','8','SALE');
INSERT INTO `stock_qty` VALUES ('63','1','2025-12-01','10','0','0','0','108','0','0','108','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('64','2','2025-12-01','12','0','0','0','194','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('15','1','2025-12-02','10','0','0','0','0','108','0','108','1','1','SALE_RETURN');
INSERT INTO `stock_qty` VALUES ('11','1','2025-11-10','11','0','0','108','0','0','0','108','1','1','PURCHASE_RETURN');
INSERT INTO `stock_qty` VALUES ('2','1','2025-10-27','9','250','0','0','0','0','0','250','3','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('5','5','2025-10-27','9','0','0','0','0','0','-150','250','3','7','STOCK_ADJUSTMENT');


DROP TABLE IF EXISTS `store`;
CREATE TABLE `store` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store` VALUES ('1','Unit 1(1st Floor)','1','2025-10-21 20:22:12','2025-10-25 18:53:26');
INSERT INTO `store` VALUES ('2','Unit 1(2nd Floor)','1','2025-10-25 18:53:56','2025-10-25 18:53:56');
INSERT INTO `store` VALUES ('3','Tester','7','2025-10-27 19:12:18','2025-10-27 19:12:18');
INSERT INTO `store` VALUES ('4','Zenobias','8','2025-11-10 21:35:42','2025-11-10 21:35:51');
INSERT INTO `store` VALUES ('5','cache','8','2025-11-10 21:36:24','2025-11-10 21:36:24');
INSERT INTO `store` VALUES ('6','Unit 2(1st Floor)','1','2025-12-07 11:28:36','2025-12-07 11:28:53');


DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `supplier` VALUES ('3','Gujranwala','Gujranwala','30000-00000-0','03377777000','testuser@gmail.com','12121213','13','2025-09-22 18:55:12','2025-09-22 18:55:26','1','testuser');
INSERT INTO `supplier` VALUES ('4','DONE','DOBNE','1829182918','19289182198','faizan@gmail.com','112112','18','2025-10-17 12:25:24','2025-10-17 12:25:24','7','DONE');
INSERT INTO `supplier` VALUES ('7','Grw','','','123','','','30','2025-11-07 00:20:07','2025-11-07 00:20:07','1','Supplier ABC');
INSERT INTO `supplier` VALUES ('8','Gujranwala','house 25/433 , Kashmir colony, Rahwali,Pakistan','','03251568863','','','34','2025-11-10 21:35:11','2025-11-10 21:35:20','8','Wali Baig');


DROP TABLE IF EXISTS `trn_dtl`;
CREATE TABLE `trn_dtl` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preparedby` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `cash_id` bigint unsigned DEFAULT NULL,
  `r_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pre_bal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trn_dtl` VALUES ('152','SIN','1','2025-10-28','','261000.00','0','','Admin PremierTax','28','','1','','','7','2025-10-28 19:43:09','2025-11-05 02:01:18');
INSERT INTO `trn_dtl` VALUES ('156','SIN','2','2025-11-05','','202000.00','0','','Admin PremierTax','28','','2','','','7','2025-11-05 02:02:59','2025-11-05 02:05:38');
INSERT INTO `trn_dtl` VALUES ('157','CPV','1','2025-11-06','','25000.00','0','N','Admin','9','3','','','','1','2025-11-07 00:37:00','2025-11-07 00:37:00');
INSERT INTO `trn_dtl` VALUES ('159','BPV','1','2025-11-06','','36000.00','0','N','Admin','3','2','','','','1','2025-11-07 00:44:22','2025-11-07 00:44:22');
INSERT INTO `trn_dtl` VALUES ('160','BRV','1','2025-11-06','','0','63000.00','N','Admin','6','2','','','','1','2025-11-07 00:45:38','2025-11-07 00:45:38');
INSERT INTO `trn_dtl` VALUES ('166','CPV','2','2025-11-08','','122121.00','0','unofficial','Admin','2','3','','','','1','2025-11-08 15:50:53','2025-11-08 16:01:24');
INSERT INTO `trn_dtl` VALUES ('188','SIN','1','2025-11-10','','1351.35','0','','Demo Wali','35','','1','','','8','2025-11-10 21:58:15','2025-11-10 21:58:15');
INSERT INTO `trn_dtl` VALUES ('190','PRN','1','2025-11-10','','83.00','0','','Admin','30','9','1','','','1','2025-11-10 23:14:24','2025-11-10 23:14:24');
INSERT INTO `trn_dtl` VALUES ('193','CPV','3','2025-11-16','','20000.00','0','N','Admin','29','3','','','','1','2025-11-16 18:48:40','2025-11-16 18:48:40');
INSERT INTO `trn_dtl` VALUES ('194','SIN','1','2025-12-01','','12178.00','0','','Admin','37','2','1','','','1','2025-12-01 23:21:52','2025-12-02 18:08:54');
INSERT INTO `trn_dtl` VALUES ('195','SRN','1','2025-12-02','','0','12420.00','','Admin','37','2','1','','','1','2025-12-02 12:52:07','2025-12-02 12:52:07');
INSERT INTO `trn_dtl` VALUES ('196','SIN','2','2025-12-03','','8635.00','0','','Admin','38','2','2','','','1','2025-12-03 19:24:09','2025-12-03 19:24:09');


DROP TABLE IF EXISTS `trn_dtl_views`;
;

INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','28','','261000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','28','','202000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('157','1','CPV','2025-11-06','9','','25000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('159','1','BPV','2025-11-06','3','','36000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','6','','0','63000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('166','2','CPV','2025-11-08','2','','122121.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','35','','1351.35','0','8','account');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','30','','83.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('193','3','CPV','2025-11-16','29','','20000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('194','1','SIN','2025-12-01','37','','12178.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('195','1','SRN','2025-12-02','37','','0','12420.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('196','2','SIN','2025-12-03','38','','8635.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','','','0','261000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','','','0','202000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('157','1','CPV','2025-11-06','3','','0','25000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('159','1','BPV','2025-11-06','2','','0','36000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','2','','63000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('166','2','CPV','2025-11-08','3','','0','122121.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','','','0','1351.35','8','cash');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','9','','0','83.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('193','3','CPV','2025-11-16','3','','0','20000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('194','1','SIN','2025-12-01','2','','0','12178.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('195','1','SRN','2025-12-02','2','','12420.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('196','2','SIN','2025-12-03','2','','0','8635.00','1','cash');


DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `units` VALUES ('6','Carton','1','2025-10-25 18:57:46','2025-10-25 18:57:46');
INSERT INTO `units` VALUES ('8','KG','7','2025-10-27 19:18:50','2025-10-27 19:18:50');
INSERT INTO `units` VALUES ('9','mm','8','2025-11-10 21:38:21','2025-11-10 21:38:21');


DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE `user_permission` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint unsigned NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `read` int NOT NULL,
  `write` int NOT NULL,
  `update` int NOT NULL,
  `delete` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_permission` VALUES ('1','134','1','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('2','134','2','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('3','134','3','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('4','134','4','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('5','134','5','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('6','134','6','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('7','134','7','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('8','134','8','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('9','134','9','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('10','134','10','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('11','134','11','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('12','134','12','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('13','134','13','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('14','134','14','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('15','134','15','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('16','134','16','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('17','134','17','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('18','134','18','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('19','134','19','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('20','134','20','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('21','134','21','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('22','134','22','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('23','134','23','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('24','134','24','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('25','134','25','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('26','134','26','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('27','134','27','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('28','134','28','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('29','134','29','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('30','134','30','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('31','134','31','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('32','134','32','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('33','134','33','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('34','134','34','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('35','134','35','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('36','134','36','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('37','135','1','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('38','135','2','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('39','135','3','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('40','135','4','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('41','135','5','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('42','135','6','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('43','135','7','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('44','135','8','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('45','135','9','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('46','135','10','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('47','135','11','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('48','135','12','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('49','135','13','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('50','135','14','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('51','135','15','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('52','135','16','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('53','135','17','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('54','135','18','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('55','135','19','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('56','135','20','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('57','135','21','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('58','135','22','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('59','135','23','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('60','135','24','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('61','135','25','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('62','135','26','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('63','135','27','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('64','135','28','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('65','135','29','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('66','135','30','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('67','135','31','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('68','135','32','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('69','135','33','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('70','135','34','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('71','135','35','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('72','135','36','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('145','137','1','9','1','0','0','0','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('146','137','2','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('147','137','3','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('148','137','4','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('149','137','5','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('150','137','6','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('151','137','7','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('152','137','8','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('153','137','9','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('154','137','10','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('155','137','11','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('156','137','12','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('157','137','13','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('158','137','14','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('159','137','15','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('160','137','16','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('161','137','17','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('162','137','18','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('163','137','19','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('164','137','20','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('165','137','21','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('166','137','22','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('167','137','23','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('168','137','24','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('169','137','25','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('170','137','26','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('171','137','27','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('172','137','28','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('173','137','29','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('174','137','30','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('175','137','31','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('176','137','32','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('177','137','33','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('178','137','34','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('179','137','35','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('180','137','36','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('334','143','32','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('335','143','34','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('336','143','35','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('367','139','1','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('368','139','2','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('369','139','3','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('370','139','4','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('371','139','5','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('372','139','6','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('373','139','7','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('374','139','8','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('375','139','9','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('376','139','10','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('377','139','11','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('378','139','12','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('379','139','13','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('380','139','14','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('381','139','15','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('382','139','16','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('383','139','17','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('384','139','18','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('385','139','19','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('386','139','20','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('387','139','21','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('388','139','22','1','1','1','1','1','2025-10-10 00:08:31','2025-10-10 00:08:31');
INSERT INTO `user_permission` VALUES ('389','139','23','1','1','1','1','1','2025-10-10 00:08:32','2025-10-10 00:08:32');
INSERT INTO `user_permission` VALUES ('390','139','24','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('391','139','25','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('392','139','26','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('393','139','27','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('394','139','28','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('395','139','29','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('396','139','30','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('397','139','31','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('398','139','32','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('399','139','33','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('400','139','34','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('401','139','35','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('402','139','36','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('403','145','1','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('404','145','2','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('405','145','3','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('406','145','4','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('407','145','5','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('408','145','6','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('409','145','7','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('410','145','8','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('411','145','9','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('412','145','10','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('413','145','11','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('414','145','12','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('415','145','13','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('416','145','14','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('417','145','15','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('418','145','16','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('419','145','17','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('420','145','18','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('421','145','19','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('422','145','20','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('423','145','21','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('424','145','22','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('425','145','23','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('426','145','24','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('427','145','25','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('428','145','26','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('429','145','27','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('430','145','28','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('431','145','29','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('432','145','30','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('433','145','31','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('434','145','32','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('435','145','33','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('436','145','34','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('437','145','36','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('488','141','1','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('489','141','2','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('490','141','3','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('491','141','4','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('492','141','5','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('493','141','6','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('494','141','7','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('495','141','8','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('496','141','9','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('497','141','10','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('498','141','11','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('499','141','12','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('500','141','13','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('501','141','14','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('502','141','15','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('503','141','16','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('504','141','17','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('505','141','18','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('506','141','19','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('507','141','20','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('508','141','21','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('509','141','22','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('510','141','23','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('511','141','24','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('512','141','25','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('513','141','26','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('514','141','27','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('515','141','28','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('516','141','29','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('517','141','30','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('518','141','31','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('519','141','32','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('520','141','33','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('521','141','34','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('522','141','36','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('523','146','1','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('524','146','2','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('525','146','3','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('526','146','4','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('527','146','5','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('528','146','6','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('529','146','7','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('530','146','8','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('531','146','9','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('532','146','10','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('533','146','11','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('534','146','12','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('535','146','13','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('536','146','14','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('537','146','15','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('538','146','16','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('539','146','17','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('540','146','18','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('541','146','19','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('542','146','20','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('543','146','21','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('544','146','22','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('545','146','23','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('546','146','24','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('547','146','25','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('548','146','26','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('549','146','27','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('550','146','28','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('551','146','29','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('552','146','30','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('553','146','31','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('554','146','32','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('555','146','33','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('556','146','34','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('557','146','36','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('558','142','1','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('559','142','2','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('560','142','3','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('561','142','4','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('562','142','5','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('563','142','6','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('564','142','7','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('565','142','8','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('566','142','9','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('567','142','10','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('568','142','11','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('569','142','12','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('570','142','13','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('571','142','14','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('572','142','15','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('573','142','16','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('574','142','17','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('575','142','18','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('576','142','19','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('577','142','20','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('578','142','21','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('579','142','22','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('580','142','23','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('581','142','24','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('582','142','25','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('583','142','26','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('584','142','27','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('585','142','28','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('586','142','29','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('587','142','30','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('588','142','31','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('589','142','32','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('590','142','33','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('591','142','34','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('592','142','36','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('594','1','1','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('595','1','2','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('596','1','3','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('597','1','4','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('598','1','5','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('599','1','6','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('600','1','7','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('601','1','8','1','1','1','1','1','2025-11-06 02:00:05','2025-11-16 01:40:15');
INSERT INTO `user_permission` VALUES ('602','1','9','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('603','1','10','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('604','1','11','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('605','1','12','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('606','1','13','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('607','1','14','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('608','1','15','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('609','1','16','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('610','1','17','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('611','1','18','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('612','1','19','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('613','1','20','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('614','1','21','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('615','1','22','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('616','1','24','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('617','1','25','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('618','1','26','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('619','1','36','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('620','1','37','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('621','135','1','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('622','135','2','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('623','135','3','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('624','135','4','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('625','135','5','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('626','135','6','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('627','135','7','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('628','135','8','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('629','135','9','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('630','135','10','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('631','135','11','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('632','135','12','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('633','135','13','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('634','135','14','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account` tinyint(1) DEFAULT NULL,
  `report` tinyint(1) DEFAULT NULL,
  `billing` tinyint(1) DEFAULT NULL,
  `delivery_challan` tinyint(1) DEFAULT NULL,
  `waste_sale` tinyint(1) DEFAULT NULL,
  `gate_pass` tinyint(1) DEFAULT NULL,
  `gate_ex` tinyint DEFAULT NULL,
  `purchase` tinyint(1) DEFAULT NULL,
  `inventory` tinyint(1) DEFAULT NULL,
  `product_registration` tinyint(1) DEFAULT NULL,
  `job_sheet` tinyint(1) DEFAULT NULL,
  `attendance_system` tinyint(1) DEFAULT NULL,
  `setup` tinyint(1) DEFAULT NULL,
  `setup_department` tinyint(1) DEFAULT NULL,
  `employee_department` tinyint(1) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `employee` tinyint(1) DEFAULT NULL,
  `wage_calculator` tinyint(1) DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1','1','Admin','superadmin@example.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','W9Og5tv7zAw5U92lF9NfKPdH8bF0E2wGXjMT8JzCMsn31kQRrClW7ybSY2wA','2024-11-11 02:00:37','2025-07-29 01:07:02','','0','1');
INSERT INTO `users` VALUES ('99','1','Demo account','demo@gmail.com','0','1','0','1','0','1','0','1','0','1','1','1','0','0','1','$2y$12$FVF5Odqw0BiIPEcm1awHo.2h.qgQib60BUHM0ytmI59FP1kD/Ouzq','','Nt2zwqK23VxGdKXuGvBdDMu6iM1lysVdpmtusAey2nxyB2vjZJ3yIkoCZSAx','2025-04-16 01:07:51','2025-08-02 20:10:32','0','0','2');
INSERT INTO `users` VALUES ('127','3','Super Admin','admin@gmail.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','DtnwjcEvWWy2XzgK8vPQNPmSXByoLCchIcFZT1XPyZWibJbLidAbWYToENHk','2025-07-29 01:07:55','2025-08-02 12:43:06','0','0','6');
INSERT INTO `users` VALUES ('128','0','ADMIN','','','','','','','','','','','','','','','','','','','','','','','','6');
INSERT INTO `users` VALUES ('133','1','Admin PremierTax','testing@gmail.com','','','','','','','','','','','','','','','','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','','2025-09-20 14:31:38','2025-09-20 14:31:38','','','7');
INSERT INTO `users` VALUES ('135','0','checker','checker@gmail.com','','','','','','','','','','','','','','','','$2y$12$mbsiJxMffgyecJbj2TyVv.IrA61beiGt9psdl0xKcRUVCdUDaw0Qi','','','2025-11-06 02:09:49','2025-11-06 02:09:49','','','7');
INSERT INTO `users` VALUES ('136','1','Demo Wali','demowali@softix.com','','','','','','','','','','','','','','','','$2y$12$yKx.otTBaI.BnE7Zb14BY.egFQXOGrIF5FcC5duha0qw9w5NIpZKS','','','2025-11-10 13:53:44','2025-11-10 13:53:44','','','8');
INSERT INTO `users` VALUES ('137','1','SHahaan','shahaanltd@gmail.com','','','','','','','','','','','','','','','','$2y$12$MSY/g6jjiuxzYazpisJ34e3wReNJgggT1OTiz86EF2egFjTLFyE0.','','','2025-12-03 18:06:08','2025-12-03 18:06:08','','','9');


DROP TABLE IF EXISTS `workspace`;
CREATE TABLE `workspace` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `logo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `workspace` VALUES ('1','MKPLASTIC','','2025-11-10 12:37:09','uploads/1762760229mk.png');
INSERT INTO `workspace` VALUES ('6','ADMIN','','','');
INSERT INTO `workspace` VALUES ('7','Premiertax','2025-09-20 14:29:16','2025-09-20 14:29:16','');
INSERT INTO `workspace` VALUES ('8','DEMO WALI','2025-11-10 13:53:22','2025-11-10 13:53:22','');
INSERT INTO `workspace` VALUES ('9','Shahaan Ltd','2025-12-03 17:49:18','2025-12-03 17:49:18','');


