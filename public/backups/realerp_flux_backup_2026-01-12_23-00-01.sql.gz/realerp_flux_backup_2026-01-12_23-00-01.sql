-- Backup of realerp_flux on 2026-01-12_23-00-01

DROP TABLE IF EXISTS `account_masters`;
CREATE TABLE `account_masters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `opening_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `level2_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `account_masters` VALUES ('2','Allied Bank LTD','2025-09-17','0001','1','3','2025-09-18 00:58:29','2025-09-18 00:58:29');
INSERT INTO `account_masters` VALUES ('6','Sale debit ACCOUNT','2025-09-18','0001','1','7','2025-09-18 12:34:43','2025-09-18 12:34:43');
INSERT INTO `account_masters` VALUES ('9','Capital account','2025-09-21','0001','1','9','2025-09-22 01:06:20','2026-01-01 19:40:02');
INSERT INTO `account_masters` VALUES ('17','Stock Account','2025-10-15','0001','7','16','2025-10-15 12:12:56','2025-10-15 12:12:56');
INSERT INTO `account_masters` VALUES ('18','DONE Supplier','2025-10-17 17:25:24','0001','7','13','2025-10-17 12:25:24','2025-10-17 12:25:24');
INSERT INTO `account_masters` VALUES ('20','Expense Account','2025-10-18','0001','7','17','2025-10-18 07:09:51','2025-10-18 07:09:51');
INSERT INTO `account_masters` VALUES ('28','Talha','2025-10-27 19:35:13','0001','7','12','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `account_masters` VALUES ('29','MA Plastic','2025-11-01 15:00:50','0004','1','8','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `account_masters` VALUES ('30','Supplier ABC','2025-11-07 00:20:07','0002','1','6','2025-11-07 00:20:07','2025-11-07 00:20:07');
INSERT INTO `account_masters` VALUES ('32','Raw Material Inventory','2025-11-10','0001','8','19','2025-11-10 14:10:36','2025-11-10 14:10:36');
INSERT INTO `account_masters` VALUES ('33','Office Supply','2025-11-10','0001','8','18','2025-11-10 14:16:17','2025-11-10 21:24:28');
INSERT INTO `account_masters` VALUES ('34','Mirza Muhammad Wali Baig','2025-11-10 21:35:11','0002','8','19','2025-11-10 21:35:11','2025-11-10 21:35:11');
INSERT INTO `account_masters` VALUES ('35','Mirza Muhammad Wali Baig','2025-11-10 21:48:39','0002','8','18','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `account_masters` VALUES ('37','Hafiz & Tariq','2025-11-23 17:21:32','0005','1','8','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `account_masters` VALUES ('38','Lucky Plastic','2025-11-23 17:24:38','0006','1','8','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `account_masters` VALUES ('39','Baber Plastic','2025-11-23 17:26:13','0007','1','8','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `account_masters` VALUES ('40','Sultan Crockery','2025-11-23 17:30:15','0008','1','8','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `account_masters` VALUES ('41','Imran Shani Basement','2025-11-23 17:31:29','0009','1','8','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `account_masters` VALUES ('42','Aneeq Plastic','2025-11-23 17:32:05','0010','1','8','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `account_masters` VALUES ('43','MAI Plastic','2025-11-23 17:32:44','0011','1','8','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `account_masters` VALUES ('44','Sheikh Mushtaq Plastic','2025-11-23 17:34:41','0012','1','8','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `account_masters` VALUES ('45','Subhan Plastic','2025-11-23 17:36:06','0013','1','8','2025-11-23 17:36:06','2025-11-23 17:36:06');
INSERT INTO `account_masters` VALUES ('46','Nawab Plastic','2025-11-23 17:40:44','0014','1','8','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `account_masters` VALUES ('47','Punjab Traders','2025-11-23 17:41:43','0015','1','8','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `account_masters` VALUES ('48','Madni Traders','2025-11-23 17:42:23','0016','1','8','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `account_masters` VALUES ('49','Umar Plastic','2025-11-23 17:46:18','0017','1','8','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `account_masters` VALUES ('50','Sajjad & Sons','2025-11-23 17:51:23','0018','1','8','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `account_masters` VALUES ('51','Chacha Dori Wala','2025-11-23 17:55:45','0019','1','8','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `account_masters` VALUES ('52','Kashif Crockery','2025-11-23 17:58:11','0020','1','8','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `account_masters` VALUES ('53','Zia Plastic','2025-11-23 17:59:17','0021','1','8','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `account_masters` VALUES ('54','Haider Plastic','2025-11-23 18:00:54','0022','1','8','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `account_masters` VALUES ('56','Al-Madad Plastic','2025-11-23 18:04:08','0024','1','8','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `account_masters` VALUES ('57','Mubarak Plastic','2025-11-23 18:57:17','0025','1','8','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `account_masters` VALUES ('58','Malik Ehsan Plastic','2025-11-23 18:59:48','0026','1','8','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `account_masters` VALUES ('59','Noshahi Qadri','2025-12-01 18:18:47','0027','1','8','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `account_masters` VALUES ('60','Saddique Traders','2025-12-01 18:19:52','0028','1','8','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `account_masters` VALUES ('61','Rafaqat Plastic','2025-12-01 18:26:46','0029','1','8','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `account_masters` VALUES ('62','Muneer Sb','2025-12-01 18:27:34','0030','1','8','2025-12-01 18:27:34','2025-12-01 18:27:34');
INSERT INTO `account_masters` VALUES ('63','Asif Plastic','2025-12-01 18:28:48','0031','1','8','2025-12-01 18:28:48','2025-12-01 18:28:48');
INSERT INTO `account_masters` VALUES ('64','ABD Plastic','2025-12-01 18:44:17','0032','1','8','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `account_masters` VALUES ('65','Ghazi Plastic','2025-12-01 18:45:49','0033','1','8','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `account_masters` VALUES ('66','Azan Plastic','2025-12-01 18:52:20','0034','1','8','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `account_masters` VALUES ('67','Sulman Plastic','2025-12-02 18:18:36','0035','1','8','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `account_masters` VALUES ('68','Waqas Plastic','2025-12-02 18:22:00','0036','1','8','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `account_masters` VALUES ('69','Raza Kitchenware','2025-12-02 18:22:59','0037','1','8','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `account_masters` VALUES ('70','Bin Bashir Plastic','2025-12-02 18:24:15','0038','1','8','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `account_masters` VALUES ('71','Khan Plastic','2025-12-02 18:45:45','0039','1','8','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `account_masters` VALUES ('72','Nadeem Traders','2025-12-02 18:57:01','0040','1','8','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `account_masters` VALUES ('73','Fajar Plastic','2025-12-02 19:01:13','0041','1','8','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `account_masters` VALUES ('74','Latif Crockery','2025-12-02 19:02:41','0042','1','8','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `account_masters` VALUES ('75','Haji Akram Traders','2025-12-02 19:25:22','0043','1','8','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `account_masters` VALUES ('77','Talha Plastic','2025-12-02 19:35:16','0045','1','8','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `account_masters` VALUES ('78','Mansha Plastic','2025-12-02 19:38:33','0046','1','8','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `account_masters` VALUES ('79','Zameer Plastic','2025-12-02 19:39:19','0047','1','8','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `account_masters` VALUES ('80','Shan Traders','2025-12-03 18:02:46','0048','1','8','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `account_masters` VALUES ('81','Mubarak Sheesha','2025-12-03 18:04:07','0049','1','8','2025-12-03 18:04:07','2025-12-03 18:04:07');
INSERT INTO `account_masters` VALUES ('82','Hafiz Abdullah','2025-12-03 18:04:48','0050','1','8','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `account_masters` VALUES ('83','M Taha Plastic','2025-12-03 18:10:24','0051','1','8','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `account_masters` VALUES ('84','Irfan Sulman Plastic','2025-12-03 19:11:54','0052','1','8','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `account_masters` VALUES ('85','Ahsan Plastic','2025-12-03 19:12:39','0053','1','8','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `account_masters` VALUES ('86','Shakar Plastic','2025-12-03 19:13:29','0054','1','8','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `account_masters` VALUES ('87','Iqbal Shaker Plastic','2025-12-03 19:14:45','0055','1','8','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `account_masters` VALUES ('88','Shoaib Traders','2025-12-03 19:16:05','0056','1','8','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `account_masters` VALUES ('89','Itefaq Traders','2025-12-03 19:34:22','0057','1','8','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `account_masters` VALUES ('90','Sufiyan Al Fajar Plastic','2025-12-03 19:34:51','0058','1','8','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `account_masters` VALUES ('91','Farhan Al Fajar Plastic','2025-12-03 19:38:02','0059','1','8','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `account_masters` VALUES ('92','Chand Plastic','2025-12-03 19:38:40','0060','1','8','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `account_masters` VALUES ('94','Umar Bhai Bhai Plastic','2025-12-04 19:37:34','0061','1','8','2025-12-04 19:37:34','2025-12-04 19:37:34');
INSERT INTO `account_masters` VALUES ('96','Extra','2025-12-04 19:45:20','0063','1','8','2025-12-04 19:45:20','2025-12-04 19:45:20');
INSERT INTO `account_masters` VALUES ('97','Extra','2025-12-04 19:45:40','0064','1','8','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `account_masters` VALUES ('98','Bhai Bhai Plastic','2025-12-04 19:51:40','0065','1','8','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `account_masters` VALUES ('99','Nawab Bartan Store','2025-12-04 19:53:29','0066','1','8','2025-12-04 19:53:29','2025-12-04 19:53:29');
INSERT INTO `account_masters` VALUES ('100','Suleman Plastic','2025-12-04 19:55:32','0067','1','8','2025-12-04 19:55:32','2025-12-04 19:55:32');
INSERT INTO `account_masters` VALUES ('101','Hafiz Bilal','2025-12-04 19:55:53','0068','1','8','2025-12-04 19:55:53','2025-12-04 19:55:53');
INSERT INTO `account_masters` VALUES ('102','Arif AA Plastic','2025-12-04 20:06:06','0069','1','8','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `account_masters` VALUES ('103','Farhad Sb','2025-12-06 11:36:13','0070','1','8','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `account_masters` VALUES ('104','M Ashraf Plastic','2025-12-06 11:45:48','0071','1','8','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `account_masters` VALUES ('105','Al Khair Plastic','2025-12-06 11:46:35','0072','1','8','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `account_masters` VALUES ('106','Bajor Plastic','2025-12-06 11:47:54','0073','1','8','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `account_masters` VALUES ('107','Nazer Plastic','2025-12-06 11:48:42','0074','1','8','2025-12-06 11:48:42','2025-12-06 11:48:42');
INSERT INTO `account_masters` VALUES ('108','Plastic Point','2025-12-06 11:49:35','0075','1','8','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `account_masters` VALUES ('109','Zaheer Plastic','2025-12-06 11:50:31','0076','1','8','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `account_masters` VALUES ('110','Sheikh Imran Plastic','2025-12-06 11:51:19','0077','1','8','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `account_masters` VALUES ('111','Gulshan Plastic','2025-12-06 11:52:11','0078','1','8','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `account_masters` VALUES ('112','Dilawar Plastic','2025-12-06 12:04:43','0079','1','8','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `account_masters` VALUES ('113','Fahad Ashfaq','2025-12-06 18:55:45','0080','1','8','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `account_masters` VALUES ('114','Mian Shahid Plastic','2025-12-06 18:56:54','0081','1','8','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `account_masters` VALUES ('115','Mian Abdul Razaq','2025-12-06 18:59:22','0082','1','8','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `account_masters` VALUES ('116','Sajad Plastic','2025-12-06 19:00:26','0083','1','8','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `account_masters` VALUES ('117','Mushtaq Brothers','2025-12-06 19:08:41','0084','1','8','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `account_masters` VALUES ('118','Ishfaq Mushtaq Plastic','2025-12-06 19:10:20','0085','1','8','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `account_masters` VALUES ('119','Sartaj Plastic','2025-12-06 19:13:56','0086','1','8','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `account_masters` VALUES ('120','Arif Plastic','2025-12-06 19:14:31','0087','1','8','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `account_masters` VALUES ('121','Swabi Crockery','2025-12-06 19:15:16','0088','1','8','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `account_masters` VALUES ('122','Ali Plastic','2025-12-06 19:36:41','0089','1','8','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `account_masters` VALUES ('123','Amir Plastic','2025-12-06 19:37:44','0090','1','8','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `account_masters` VALUES ('124','Hafiz Plastic','2025-12-06 19:40:48','0091','1','8','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `account_masters` VALUES ('126','Fauji Bartan Store','2025-12-06 19:44:06','0093','1','8','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `account_masters` VALUES ('128','Naseer Plastic','2025-12-06 19:46:31','0095','1','8','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `account_masters` VALUES ('129','Azeem Atari','2025-12-06 19:51:03','0096','1','8','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `account_masters` VALUES ('130','A Tawakal Plastic','2025-12-09 18:45:46','0097','1','8','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `account_masters` VALUES ('131','Shabeer Plastic','2025-12-09 18:46:38','0098','1','8','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `account_masters` VALUES ('132','Bila Brothers','2025-12-09 18:47:36','0099','1','8','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `account_masters` VALUES ('133','Zaryab Bartan Store','2025-12-09 18:49:45','0100','1','8','2025-12-09 18:49:45','2025-12-09 18:49:45');
INSERT INTO `account_masters` VALUES ('134','Pak China Crockery','2025-12-09 18:50:55','0101','1','8','2025-12-09 18:50:55','2025-12-09 18:50:55');
INSERT INTO `account_masters` VALUES ('135','Zaryal Khan','2025-12-09 18:51:31','0102','1','8','2025-12-09 18:51:31','2025-12-09 18:51:31');
INSERT INTO `account_masters` VALUES ('136','China Sale Center','2025-12-09 18:52:35','0103','1','8','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `account_masters` VALUES ('137','Saleem Plastic','2025-12-09 18:53:14','0104','1','8','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `account_masters` VALUES ('138','Raza Plastic','2025-12-09 20:17:08','0105','1','8','2025-12-09 20:17:08','2025-12-09 20:17:08');
INSERT INTO `account_masters` VALUES ('139','Ameen Plastic','2025-12-11 19:30:28','0106','1','8','2025-12-11 19:30:28','2025-12-11 19:30:28');
INSERT INTO `account_masters` VALUES ('140','Stylo Plastic','2025-12-11 19:32:54','0107','1','8','2025-12-11 19:32:54','2025-12-11 19:32:54');
INSERT INTO `account_masters` VALUES ('141','Faisal Plastic','2025-12-11 19:35:06','0108','1','8','2025-12-11 19:35:06','2025-12-11 19:35:06');
INSERT INTO `account_masters` VALUES ('142','Yousaf Gul','2025-12-11 19:35:50','0109','1','8','2025-12-11 19:35:50','2025-12-11 19:35:50');
INSERT INTO `account_masters` VALUES ('143','Azam Plastic','2025-12-11 19:36:37','0110','1','8','2025-12-11 19:36:37','2025-12-11 19:36:37');
INSERT INTO `account_masters` VALUES ('144','Naeem Plastic','2025-12-11 19:38:17','0111','1','8','2025-12-11 19:38:17','2025-12-11 19:38:17');
INSERT INTO `account_masters` VALUES ('145','Mubarak Ibrahim','2025-12-11 19:39:33','0112','1','8','2025-12-11 19:39:33','2025-12-11 19:39:33');
INSERT INTO `account_masters` VALUES ('146','Imran Plastic','2025-12-11 19:44:34','0113','1','8','2025-12-11 19:44:34','2025-12-11 19:44:34');
INSERT INTO `account_masters` VALUES ('147','Ansar Plastic','2025-12-11 19:45:10','0114','1','8','2025-12-11 19:45:10','2025-12-11 19:45:10');
INSERT INTO `account_masters` VALUES ('148','Chaudhary Plastic','2025-12-11 19:46:03','0115','1','8','2025-12-11 19:46:03','2025-12-11 19:46:03');
INSERT INTO `account_masters` VALUES ('149','Abdul Manan','2025-12-11 19:47:06','0116','1','8','2025-12-11 19:47:06','2025-12-11 19:47:06');
INSERT INTO `account_masters` VALUES ('150','Chishti Plastic','2025-12-11 19:48:28','0117','1','8','2025-12-11 19:48:28','2025-12-11 19:48:28');
INSERT INTO `account_masters` VALUES ('151','Awais Plastic','2025-12-11 19:49:22','0118','1','8','2025-12-11 19:49:22','2025-12-11 19:49:22');
INSERT INTO `account_masters` VALUES ('152','HZ Plastic','2025-12-11 19:50:23','0119','1','8','2025-12-11 19:50:23','2025-12-11 19:50:23');
INSERT INTO `account_masters` VALUES ('153','Kashif Plastic','2025-12-11 19:51:08','0120','1','8','2025-12-11 19:51:08','2025-12-11 19:51:08');
INSERT INTO `account_masters` VALUES ('154','Mohsin Hassan','2025-12-11 19:51:53','0121','1','8','2025-12-11 19:51:53','2025-12-11 19:51:53');
INSERT INTO `account_masters` VALUES ('155','Qaiser Plastic','2025-12-11 19:58:08','0122','1','8','2025-12-11 19:58:08','2025-12-11 19:58:08');
INSERT INTO `account_masters` VALUES ('156','Sale Account','2025-12-19','0001','7','23','2025-12-19 16:20:09','2025-12-19 16:20:09');
INSERT INTO `account_masters` VALUES ('157','Cash Account','2026-01-01','0001','1','4','2026-01-04 20:00:49','2026-01-04 20:00:49');
INSERT INTO `account_masters` VALUES ('158','Master Plastic','2026-01-11 18:56:48','0123','1','8','2026-01-11 18:56:48','2026-01-11 18:56:48');
INSERT INTO `account_masters` VALUES ('159','Saadi Plastic','2026-01-11 20:49:45','0124','1','8','2026-01-11 20:49:45','2026-01-11 20:49:45');
INSERT INTO `account_masters` VALUES ('160','Hassan Steel','2026-01-11 23:31:48','0125','1','8','2026-01-11 23:31:48','2026-01-11 23:31:48');
INSERT INTO `account_masters` VALUES ('161','Farhan Al Fajar','2026-01-12 00:20:34','0126','1','8','2026-01-12 00:20:34','2026-01-12 00:20:34');
INSERT INTO `account_masters` VALUES ('163','Emaan Traders','2026-01-12 18:39:15','0127','1','8','2026-01-12 18:39:15','2026-01-12 18:39:15');


DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` VALUES ('11','Talha','','','','Faizan','','','28','7','2025-10-27 19:35:13','2025-10-27 19:35:13');
INSERT INTO `customers` VALUES ('12','MA Plastic','Gujranwala','Alam Chowk','','03446115519','','','29','1','2025-11-01 15:00:50','2025-11-01 15:00:50');
INSERT INTO `customers` VALUES ('13','Mirza Muhammad Wali Baig','Gujranwala','Gujranwala, rahwali, Kashmir colony, house no.244/25','','03251568863','','','35','8','2025-11-10 21:48:39','2025-11-10 21:48:39');
INSERT INTO `customers` VALUES ('15','Hafiz & Tariq','Lahore','','','03347022248','','','37','1','2025-11-23 17:21:32','2025-11-23 17:21:32');
INSERT INTO `customers` VALUES ('16','Lucky Plastic','Lahore','','','03224252751','','','38','1','2025-11-23 17:24:38','2025-11-23 17:24:38');
INSERT INTO `customers` VALUES ('17','Baber Plastic','Lahore','','','03214656210','','','39','1','2025-11-23 17:26:13','2025-11-23 17:26:13');
INSERT INTO `customers` VALUES ('18','Sultan Crockery','Lahore','','','03224004826','','','40','1','2025-11-23 17:30:15','2025-11-23 17:30:15');
INSERT INTO `customers` VALUES ('19','Imran Shani Basement','Lahore','','','03218894066','','','41','1','2025-11-23 17:31:29','2025-11-23 17:31:29');
INSERT INTO `customers` VALUES ('20','Aneeq Plastic','Lahore','','','03024330398','','','42','1','2025-11-23 17:32:05','2025-11-23 17:32:05');
INSERT INTO `customers` VALUES ('21','MAI Plastic','Lahore','','','03092232224','','','43','1','2025-11-23 17:32:44','2025-11-23 17:32:44');
INSERT INTO `customers` VALUES ('22','Sheikh Mushtaq Plastic','Lahore','','','03099117726','','','44','1','2025-11-23 17:34:41','2025-11-23 17:34:41');
INSERT INTO `customers` VALUES ('23','Subhan Plastic','Lahore','','','03014024432','','','45','1','2025-11-23 17:36:07','2025-11-23 17:36:07');
INSERT INTO `customers` VALUES ('24','Nawab Plastic','Lahore','','','03000432852','','','46','1','2025-11-23 17:40:44','2025-11-23 17:40:44');
INSERT INTO `customers` VALUES ('25','Punjab Traders','Lahore','','','03084751026','','','47','1','2025-11-23 17:41:43','2025-11-23 17:41:43');
INSERT INTO `customers` VALUES ('26','Madni Traders','Lahore','','','03034432896','','','48','1','2025-11-23 17:42:23','2025-11-23 17:42:23');
INSERT INTO `customers` VALUES ('27','Umar Plastic','Lahore','','','03044018158','','','49','1','2025-11-23 17:46:18','2025-11-23 17:46:18');
INSERT INTO `customers` VALUES ('28','Sajjad & Sons','Lahore','','','03234748194','','','50','1','2025-11-23 17:51:23','2025-11-23 17:51:23');
INSERT INTO `customers` VALUES ('29','Chacha Dori Wala','Lahore','','','03244253653','','','51','1','2025-11-23 17:55:45','2025-11-23 17:55:45');
INSERT INTO `customers` VALUES ('30','Kashif Crockery','Lahore','','','03054097607','','','52','1','2025-11-23 17:58:11','2025-11-23 17:58:11');
INSERT INTO `customers` VALUES ('31','Zia Plastic','Lahore','','','03228007053','','','53','1','2025-11-23 17:59:17','2025-11-23 17:59:17');
INSERT INTO `customers` VALUES ('32','Haider Plastic','Lahore','','','03334536476','','','54','1','2025-11-23 18:00:54','2025-11-23 18:00:54');
INSERT INTO `customers` VALUES ('34','Al-Madad Plastic','Lahore','','','03214263909','','','56','1','2025-11-23 18:04:08','2025-11-23 18:04:08');
INSERT INTO `customers` VALUES ('35','Mubarak Plastic','Lahore','','','03229486984','','','57','1','2025-11-23 18:57:17','2025-11-23 18:57:17');
INSERT INTO `customers` VALUES ('36','Malik Ehsan Plastic','Lahore','','','03214655001','','','58','1','2025-11-23 18:59:48','2025-11-23 18:59:48');
INSERT INTO `customers` VALUES ('37','Noshahi Qadri','Lahore','','','03096605105','','','59','1','2025-12-01 18:18:47','2025-12-01 18:18:47');
INSERT INTO `customers` VALUES ('38','Saddique Traders','Lahore','','','03004255488','','','60','1','2025-12-01 18:19:52','2025-12-01 18:19:52');
INSERT INTO `customers` VALUES ('39','Rafaqat Plastic','Lahore','','','03211671661','','','61','1','2025-12-01 18:26:46','2025-12-01 18:26:46');
INSERT INTO `customers` VALUES ('40','Muneer Sb','Lahore','','','03004244186','','','62','1','2025-12-01 18:27:34','2025-12-01 18:35:58');
INSERT INTO `customers` VALUES ('41','Asif Plastic','Noor Gali, Lahore','','','03214260098','','','63','1','2025-12-01 18:28:48','2025-12-02 18:05:09');
INSERT INTO `customers` VALUES ('42','ABD Plastic','Alam Chowk, Gujranwala','','','03018838164','','','64','1','2025-12-01 18:44:17','2025-12-01 18:44:17');
INSERT INTO `customers` VALUES ('43','Ghazi Plastic','Alam Chowk, Gujranwala','','','03456811257','','','65','1','2025-12-01 18:45:49','2025-12-01 18:45:49');
INSERT INTO `customers` VALUES ('44','Azan Plastic','Alam Chowk, Gujranwala','','','03334697700','','','66','1','2025-12-01 18:52:20','2025-12-01 18:52:20');
INSERT INTO `customers` VALUES ('45','Sulman Plastic','Alam Chowk, Gujranwala','','','03446575017','','','67','1','2025-12-02 18:18:36','2025-12-02 18:18:36');
INSERT INTO `customers` VALUES ('46','Waqas Plastic','Alam Chowk, Gujranwala','','','03066401660','','','68','1','2025-12-02 18:22:00','2025-12-02 18:22:00');
INSERT INTO `customers` VALUES ('47','Raza Kitchenware','Alam Chowk, Gujranwala','','','03126412995','','','69','1','2025-12-02 18:22:59','2025-12-02 18:22:59');
INSERT INTO `customers` VALUES ('48','Bin Bashir Plastic','Alam Chowk, Gujranwala','','','03107345310','','','70','1','2025-12-02 18:24:15','2025-12-02 18:24:15');
INSERT INTO `customers` VALUES ('49','Khan Plastic','Alam Chowk, Gujranwala','','','03216495351','','','71','1','2025-12-02 18:45:45','2025-12-02 18:45:45');
INSERT INTO `customers` VALUES ('50','Nadeem Traders','Alam Chowk, Gujranwala','','','03421679610','','','72','1','2025-12-02 18:57:01','2025-12-02 18:57:01');
INSERT INTO `customers` VALUES ('51','Fajar Plastic','Alam Chowk, Gujranwala','','','03480163684','','','73','1','2025-12-02 19:01:13','2025-12-02 19:01:13');
INSERT INTO `customers` VALUES ('52','Latif Crockery','Alam Chowk, Gujranwala','','','03129647925','','','74','1','2025-12-02 19:02:41','2025-12-02 19:02:41');
INSERT INTO `customers` VALUES ('53','Haji Akram Traders','Alam Chowk, Gujranwala','','','03005551741','','','75','1','2025-12-02 19:25:22','2025-12-02 19:25:22');
INSERT INTO `customers` VALUES ('55','Talha Plastic','Alam Chowk, Gujranwala','','','03216492229','','','77','1','2025-12-02 19:35:16','2025-12-02 19:35:16');
INSERT INTO `customers` VALUES ('56','Mansha Plastic','Alam Chowk, Gujranwala','','','03197181508','','','78','1','2025-12-02 19:38:33','2025-12-02 19:38:33');
INSERT INTO `customers` VALUES ('57','Zameer Plastic','Alam Chowk, Gujranwala','','','03006460799','','','79','1','2025-12-02 19:39:19','2025-12-02 19:39:19');
INSERT INTO `customers` VALUES ('58','Shan Traders','Alam Chowk, Gujranwala','','','03205436229','','','80','1','2025-12-03 18:02:46','2025-12-03 18:02:46');
INSERT INTO `customers` VALUES ('59','Sheraz Traders','Alam Chowk, Gujranwala','','','03096710402','','','81','1','2025-12-03 18:04:07','2025-12-31 17:41:33');
INSERT INTO `customers` VALUES ('60','Hafiz Abdullah','Alam Chowk, Gujranwala','','','03496281208','','','82','1','2025-12-03 18:04:48','2025-12-03 18:04:48');
INSERT INTO `customers` VALUES ('61','M Taha Plastic','Alam Chowk, Gujranwala','','','03200471840','','','83','1','2025-12-03 18:10:24','2025-12-03 18:10:24');
INSERT INTO `customers` VALUES ('62','Irfan Sulman Plastic','Alam Chowk, Gujranwala','','','03144243128','','','84','1','2025-12-03 19:11:54','2025-12-03 19:11:54');
INSERT INTO `customers` VALUES ('63','Ahsan Plastic','Alam Chowk, Gujranwala','','','03070183476','','','85','1','2025-12-03 19:12:39','2025-12-03 19:12:39');
INSERT INTO `customers` VALUES ('64','Shakar Plastic','Alam Chowk, Gujranwala','','','03217150849','','','86','1','2025-12-03 19:13:29','2025-12-03 19:13:29');
INSERT INTO `customers` VALUES ('65','Iqbal Shaker Plastic','Alam Chowk, Gujranwala','','','03280234237','','','87','1','2025-12-03 19:14:45','2025-12-03 19:14:45');
INSERT INTO `customers` VALUES ('66','Shoaib Traders','Alam Chowk, Gujranwala','','','03005006478','','','88','1','2025-12-03 19:16:05','2025-12-03 19:16:05');
INSERT INTO `customers` VALUES ('67','Itefaq Traders','Alam Chowk, Gujranwala','','','03004085189','','','89','1','2025-12-03 19:34:22','2025-12-03 19:34:22');
INSERT INTO `customers` VALUES ('68','Sufiyan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03013182275','','','90','1','2025-12-03 19:34:51','2025-12-03 19:34:51');
INSERT INTO `customers` VALUES ('69','Farhan Al Fajar Plastic','Alam Chowk, Gujranwala','','','03227600077','','','91','1','2025-12-03 19:38:02','2025-12-03 19:38:02');
INSERT INTO `customers` VALUES ('70','Chand Plastic','Alam Chowk, Gujranwala','','','03041241700','','','92','1','2025-12-03 19:38:40','2025-12-03 19:38:40');
INSERT INTO `customers` VALUES ('72','Umar Bhai Bhai Plastic','Alam Chowk, Gujranwala','','','03426014070','','','94','1','2025-12-04 19:37:34','2025-12-09 19:58:20');
INSERT INTO `customers` VALUES ('74','Extra','Alam Chowk, Gujranwala','','','03707099846','','','96','1','2025-12-04 19:45:20','2026-01-04 17:17:41');
INSERT INTO `customers` VALUES ('75','Extra','Alam Chowk, Gujranwala','','','0332223','','','97','1','2025-12-04 19:45:40','2025-12-04 19:45:40');
INSERT INTO `customers` VALUES ('76','Bhai Bhai Plastic','Khiali Darwaza, Gujranwala','','','03237486600','','','98','1','2025-12-04 19:51:40','2025-12-04 19:51:40');
INSERT INTO `customers` VALUES ('77','Nawab Bartan Store','Khiali Darwaza, Gujranwala','','','03059999456','','','99','1','2025-12-04 19:53:29','2025-12-09 19:58:49');
INSERT INTO `customers` VALUES ('78','Suleman Plastic','Khiali Darwaza, Gujranwala','','','03082809552','','','100','1','2025-12-04 19:55:32','2025-12-09 19:59:34');
INSERT INTO `customers` VALUES ('79','Hafiz Bilal','Khiali Darwaza, Gujranwala','','','03060360126','','','101','1','2025-12-04 19:55:53','2025-12-09 20:00:04');
INSERT INTO `customers` VALUES ('80','Arif AA Plastic','Guranwala','','','03216405344','','','102','1','2025-12-04 20:06:06','2025-12-04 20:06:06');
INSERT INTO `customers` VALUES ('81','Farhad Sb','Gujranwala','','','03217150849','','','103','1','2025-12-06 11:36:13','2025-12-06 11:36:13');
INSERT INTO `customers` VALUES ('82','M Ashraf Plastic','Muslim Road, Gujranwala','','','03207835189','','','104','1','2025-12-06 11:45:48','2025-12-06 11:45:48');
INSERT INTO `customers` VALUES ('83','Al Khair Plastic','Muslim Road, Gujranwala','','','03216400025','','','105','1','2025-12-06 11:46:35','2025-12-06 11:46:35');
INSERT INTO `customers` VALUES ('84','Bajor Plastic','Karachi','','','03170805866','','','106','1','2025-12-06 11:47:54','2025-12-06 11:47:54');
INSERT INTO `customers` VALUES ('85','Nazer Plastic','Landhi, Karachi','','','03332226851','','','107','1','2025-12-06 11:48:42','2025-12-09 20:00:50');
INSERT INTO `customers` VALUES ('86','Plastic Point','New, Karachi','','','03222030176','','','108','1','2025-12-06 11:49:35','2025-12-06 11:49:35');
INSERT INTO `customers` VALUES ('87','Zaheer Plastic','Lee Market, Karachi','','','03332292780','','','109','1','2025-12-06 11:50:31','2025-12-06 11:50:31');
INSERT INTO `customers` VALUES ('88','Sheikh Imran Plastic','Jona Market, Karachi','','','03333949228','','','110','1','2025-12-06 11:51:19','2025-12-06 11:51:19');
INSERT INTO `customers` VALUES ('89','Gulshan Plastic','New Karachi','','','03158486252','','','111','1','2025-12-06 11:52:11','2025-12-06 11:52:11');
INSERT INTO `customers` VALUES ('90','Dilawar Plastic','Landhi, Karachi','','','03332821426','','','112','1','2025-12-06 12:04:43','2025-12-06 12:04:43');
INSERT INTO `customers` VALUES ('91','Fahad Ashfaq','Kotla','','','03245853791','','','113','1','2025-12-06 18:55:45','2025-12-06 18:55:45');
INSERT INTO `customers` VALUES ('92','Mian Shahid Plastic','Lala Moosa','','','03478134855','','','114','1','2025-12-06 18:56:54','2025-12-06 18:56:54');
INSERT INTO `customers` VALUES ('93','Mian Abdul Razaq','Lala Moosa','','','03144411341','','','115','1','2025-12-06 18:59:22','2025-12-06 18:59:22');
INSERT INTO `customers` VALUES ('94','Sajad Plastic','Dinga','','','03456945048','','','116','1','2025-12-06 19:00:26','2025-12-06 19:00:26');
INSERT INTO `customers` VALUES ('95','Mushtaq Brothers','Mardan','','','03321565300','','','117','1','2025-12-06 19:08:41','2025-12-06 19:08:41');
INSERT INTO `customers` VALUES ('96','Ishfaq Mushtaq Plastic','Mardan','','','03149780127','','','118','1','2025-12-06 19:10:20','2025-12-06 19:10:20');
INSERT INTO `customers` VALUES ('97','Sartaj Plastic','Mardan','','','03005725121','','','119','1','2025-12-06 19:13:56','2025-12-06 19:13:56');
INSERT INTO `customers` VALUES ('98','Arif Plastic','Swabi','','','03120900981','','','120','1','2025-12-06 19:14:31','2025-12-06 19:14:31');
INSERT INTO `customers` VALUES ('99','Swabi Crockery','Swabi','','','03471979388','','','121','1','2025-12-06 19:15:16','2025-12-06 19:15:16');
INSERT INTO `customers` VALUES ('100','Ali Plastic','Shahdra','','','03004695613','','','122','1','2025-12-06 19:36:41','2025-12-06 19:36:41');
INSERT INTO `customers` VALUES ('101','Amir Plastic','Baigham Kot','','','03214457644','','','123','1','2025-12-06 19:37:44','2025-12-06 19:37:44');
INSERT INTO `customers` VALUES ('102','Hafiz Plastic','Raiwind','','','03014748132','','','124','1','2025-12-06 19:40:48','2025-12-06 19:40:48');
INSERT INTO `customers` VALUES ('104','Fauji Bartan Store','Raiwind','','','03004058257','','','126','1','2025-12-06 19:44:06','2025-12-06 19:44:06');
INSERT INTO `customers` VALUES ('106','Naseer Plastic','Raiwind','','','03069716413','','','128','1','2025-12-06 19:46:31','2025-12-06 19:46:31');
INSERT INTO `customers` VALUES ('107','Azeem Atari','Raiwind','','','03234982902','','','129','1','2025-12-06 19:51:03','2025-12-06 19:51:03');
INSERT INTO `customers` VALUES ('108','A Tawakal Plastic','Qainchi, Lahore','','','03084295626','','','130','1','2025-12-09 18:45:46','2025-12-09 18:45:46');
INSERT INTO `customers` VALUES ('109','Shabeer Plastic','Qasoor','','','03236758687','','','131','1','2025-12-09 18:46:38','2025-12-09 18:46:38');
INSERT INTO `customers` VALUES ('110','Bila Brothers','Rawalpindi','','','03005120936','','','132','1','2025-12-09 18:47:36','2025-12-09 18:47:36');
INSERT INTO `customers` VALUES ('111','Zaryab Bartan Store','Rawalpindi','','','03484582462','','','133','1','2025-12-09 18:49:45','2025-12-09 20:01:47');
INSERT INTO `customers` VALUES ('112','Pak China Crockery','Islamabad','','','03365069852','','','134','1','2025-12-09 18:50:55','2025-12-09 20:02:32');
INSERT INTO `customers` VALUES ('113','Zaryal Khan','Peshawar','','','03119012200','','','135','1','2025-12-09 18:51:31','2025-12-09 20:03:03');
INSERT INTO `customers` VALUES ('114','China Sale Center','Ahmadpur Sharkia','','','03062611675','','','136','1','2025-12-09 18:52:35','2025-12-09 18:52:35');
INSERT INTO `customers` VALUES ('115','Saleem Plastic','Multan','','','03067845688','','','137','1','2025-12-09 18:53:14','2025-12-09 18:53:14');
INSERT INTO `customers` VALUES ('116','Raza Plastic','Haroonabad','','','03009185706','','','138','1','2025-12-09 20:17:08','2025-12-09 20:17:08');
INSERT INTO `customers` VALUES ('117','Ameen Plastic','Mandi Madrasa','','','03054815662','','','139','1','2025-12-11 19:30:28','2025-12-11 19:30:28');
INSERT INTO `customers` VALUES ('118','Stylo Plastic','Chowk Azam','','','03013270485','','','140','1','2025-12-11 19:32:54','2025-12-11 19:32:54');
INSERT INTO `customers` VALUES ('119','Faisal Plastic','Shakargarh','','','03007762865','','','141','1','2025-12-11 19:35:06','2025-12-11 19:35:06');
INSERT INTO `customers` VALUES ('120','Yousaf Gul','Texla','','','03025320449','','','142','1','2025-12-11 19:35:50','2025-12-11 19:35:50');
INSERT INTO `customers` VALUES ('121','Azam Plastic','Hujra Shah Muqeem','','','03026816580','','','143','1','2025-12-11 19:36:37','2025-12-11 19:36:37');
INSERT INTO `customers` VALUES ('122','Naeem Plastic','Khanpur','','','03337471054','','','144','1','2025-12-11 19:38:17','2025-12-11 19:38:17');
INSERT INTO `customers` VALUES ('123','Mubarak Ibrahim','Shahdadpur','','','03453755133','','','145','1','2025-12-11 19:39:33','2025-12-11 19:39:33');
INSERT INTO `customers` VALUES ('124','Imran Plastic','Harapa','','','03015427534','','','146','1','2025-12-11 19:44:34','2025-12-11 19:44:34');
INSERT INTO `customers` VALUES ('125','Ansar Plastic','Bhalwal','','','03005671818','','','147','1','2025-12-11 19:45:10','2025-12-11 19:45:10');
INSERT INTO `customers` VALUES ('126','Chaudhary Plastic','Multan','','','03116893787','','','148','1','2025-12-11 19:46:03','2025-12-11 19:46:03');
INSERT INTO `customers` VALUES ('127','Abdul Manan','Pasheen','','','03108906520','','','149','1','2025-12-11 19:47:06','2025-12-11 19:47:06');
INSERT INTO `customers` VALUES ('128','Chishti Plastic','Dharanwala','','','03017250436','','','150','1','2025-12-11 19:48:28','2025-12-11 19:48:28');
INSERT INTO `customers` VALUES ('129','Awais Plastic','Dharanwala','','','03013664068','','','151','1','2025-12-11 19:49:22','2025-12-11 19:49:22');
INSERT INTO `customers` VALUES ('130','HZ Plastic','Sargodha','','','03046547252','','','152','1','2025-12-11 19:50:23','2025-12-11 19:50:23');
INSERT INTO `customers` VALUES ('131','Kashif Plastic','Shakargarh','','','03007778616','','','153','1','2025-12-11 19:51:08','2025-12-11 19:51:08');
INSERT INTO `customers` VALUES ('132','Mohsin Hassan','Karachi','','','03212979439','','','154','1','2025-12-11 19:51:53','2025-12-11 19:51:53');
INSERT INTO `customers` VALUES ('133','Qaiser Plastic','Piplan','','','03017761401','','','155','1','2025-12-11 19:58:08','2025-12-11 19:58:08');
INSERT INTO `customers` VALUES ('134','Master Plastic','Alam Chowk, Gujranwala','','','031313','','','158','1','2026-01-11 18:56:48','2026-01-11 18:56:48');
INSERT INTO `customers` VALUES ('135','Saadi Plastic','Alam Chowk, Gujranwala','','','03122','','','159','1','2026-01-11 20:49:45','2026-01-11 20:49:45');
INSERT INTO `customers` VALUES ('136','Hassan Steel','Alam Chowk, Gujranwala','','','030313','','','160','1','2026-01-11 23:31:48','2026-01-11 23:31:48');
INSERT INTO `customers` VALUES ('137','Farhan Al Fajar','Alam Chowk, Gujranwala','','','03121','','','161','1','2026-01-12 00:20:34','2026-01-12 00:20:34');
INSERT INTO `customers` VALUES ('139','Emaan Traders','Gujranwala','','','0311254613','','','163','1','2026-01-12 18:39:15','2026-01-12 18:39:15');


DROP TABLE IF EXISTS `erp_params`;
CREATE TABLE `erp_params` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_level` bigint unsigned DEFAULT NULL,
  `employee_level` bigint DEFAULT NULL,
  `employee_advance` bigint DEFAULT NULL,
  `bank_level` bigint unsigned DEFAULT NULL,
  `supplier_level` bigint unsigned DEFAULT NULL,
  `purchase_account` bigint unsigned DEFAULT NULL,
  `purchase_return_account` int DEFAULT NULL,
  `sale_ac` bigint unsigned DEFAULT NULL,
  `customer_level` bigint unsigned DEFAULT NULL,
  `cash_acc` bigint unsigned DEFAULT NULL,
  `pur_freight` bigint unsigned DEFAULT NULL,
  `pur_freight_exp` int DEFAULT NULL,
  `sale_freight` int DEFAULT NULL,
  `sale_freight_exp` int DEFAULT NULL,
  `salary_level` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `purchase_debit_account` bigint unsigned DEFAULT NULL,
  `saleCreditAccount` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `erp_params_saledebitaccount_foreign` (`saleCreditAccount`),
  CONSTRAINT `erp_params_saledebitaccount_foreign` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sale_debit_account` FOREIGN KEY (`saleCreditAccount`) REFERENCES `account_masters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `erp_params` VALUES ('3','4','','','3','6','','','','8','2','','','','','','2025-09-18 00:51:19','2025-10-27 14:29:03','1','9','2');
INSERT INTO `erp_params` VALUES ('4','15','','','14','13','','','','12','','','','','','','2025-10-15 12:13:14','2025-12-19 16:20:40','7','17','156');
INSERT INTO `erp_params` VALUES ('5','18','','','18','19','','','','18','','','','','','','2025-11-10 14:15:38','2025-11-10 21:48:18','8','','');


DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `groups` VALUES ('1','Capital','01','','');
INSERT INTO `groups` VALUES ('2','Liabilities','02','','');
INSERT INTO `groups` VALUES ('3','Assets','03','','');
INSERT INTO `groups` VALUES ('4','Revenue','04','','');
INSERT INTO `groups` VALUES ('5','Expenses','05','','');


DROP TABLE IF EXISTS `item_detail`;
CREATE TABLE `item_detail` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `crt_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crt_qty` bigint unsigned DEFAULT NULL,
  `crt_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_detail` VALUES ('21','9','7','20x12 Tester','120','20000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('22','9','7','32x12','250','50000','2025-10-27 19:23:12','2025-10-27 19:23:12');
INSERT INTO `item_detail` VALUES ('26','10','1','1*108','108','12420','2025-11-01 17:15:17','2025-11-01 17:15:17');
INSERT INTO `item_detail` VALUES ('33','14','8','20x12','12','12','2025-11-10 21:39:53','2025-11-10 21:39:53');
INSERT INTO `item_detail` VALUES ('35','11','1','1*108','108','8964','2025-12-07 11:34:26','2025-12-07 11:34:26');
INSERT INTO `item_detail` VALUES ('36','12','1','1*72','72','0','2025-12-07 11:35:18','2025-12-07 11:35:18');
INSERT INTO `item_detail` VALUES ('37','13','1','1*72','72','13320','2025-12-07 11:40:08','2025-12-07 11:40:08');
INSERT INTO `item_detail` VALUES ('38','16','1','1*72','72','7128','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_detail` VALUES ('39','17','1','1*72','72','10584','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_detail` VALUES ('40','18','1','1*72','72','0','2025-12-07 12:15:34','2025-12-07 12:15:34');
INSERT INTO `item_detail` VALUES ('41','19','1','1*40','40','9520','2025-12-11 18:29:32','2025-12-11 18:29:32');
INSERT INTO `item_detail` VALUES ('42','20','1','1*40','40','5400','2025-12-11 18:31:38','2025-12-11 18:31:38');
INSERT INTO `item_detail` VALUES ('43','21','1','1*40','40','8000','2025-12-11 18:33:19','2025-12-11 18:33:19');
INSERT INTO `item_detail` VALUES ('44','22','1','1*40','40','0','2025-12-11 18:34:08','2025-12-11 18:34:08');
INSERT INTO `item_detail` VALUES ('45','23','1','1*40','40','13000','2025-12-11 18:36:17','2025-12-11 18:36:17');
INSERT INTO `item_detail` VALUES ('46','24','1','1*40','40','7000','2025-12-11 18:37:18','2025-12-11 18:37:18');
INSERT INTO `item_detail` VALUES ('47','25','1','1*40','40','10800','2025-12-11 18:38:14','2025-12-11 18:38:14');
INSERT INTO `item_detail` VALUES ('48','26','1','1*40','40','0','2025-12-11 19:02:53','2025-12-11 19:02:53');
INSERT INTO `item_detail` VALUES ('49','27','1','1*35','35','14350','2025-12-11 19:04:58','2025-12-11 19:04:58');
INSERT INTO `item_detail` VALUES ('50','28','1','1*35','35','8225','2025-12-11 19:25:53','2025-12-11 19:25:53');
INSERT INTO `item_detail` VALUES ('51','29','1','1*35','35','8925','2025-12-14 12:25:09','2025-12-14 12:25:09');
INSERT INTO `item_detail` VALUES ('52','30','1','1*40','40','12800','2025-12-14 12:32:03','2025-12-14 12:32:03');
INSERT INTO `item_detail` VALUES ('53','31','1','1*40','40','7600','2025-12-14 12:33:27','2025-12-14 12:33:27');
INSERT INTO `item_detail` VALUES ('54','32','1','1*40','40','8600','2025-12-14 12:35:00','2025-12-14 12:35:00');
INSERT INTO `item_detail` VALUES ('55','33','1','1*30','30','16050','2025-12-14 12:36:43','2025-12-14 12:36:43');
INSERT INTO `item_detail` VALUES ('56','34','1','1*30','30','9600','2025-12-14 12:38:37','2025-12-14 12:38:37');
INSERT INTO `item_detail` VALUES ('57','35','1','1*30','30','11100','2025-12-14 12:43:17','2025-12-14 12:43:17');
INSERT INTO `item_detail` VALUES ('58','36','1','1*35','35','15575','2025-12-14 12:45:29','2025-12-14 12:45:29');
INSERT INTO `item_detail` VALUES ('59','37','1','1*35','35','9450','2025-12-14 12:51:17','2025-12-14 12:51:17');
INSERT INTO `item_detail` VALUES ('60','38','1','1*35','35','10500','2025-12-14 12:52:16','2025-12-14 12:52:16');
INSERT INTO `item_detail` VALUES ('61','39','1','1*30','30','16800','2025-12-14 12:54:06','2025-12-14 12:54:06');
INSERT INTO `item_detail` VALUES ('62','40','1','1*30','30','10350','2025-12-14 12:56:18','2025-12-14 12:56:18');
INSERT INTO `item_detail` VALUES ('63','41','1','1*30','30','11700','2025-12-14 12:59:57','2025-12-14 12:59:57');
INSERT INTO `item_detail` VALUES ('64','42','1','1*35','35','16450','2025-12-14 13:06:36','2025-12-14 13:06:36');
INSERT INTO `item_detail` VALUES ('65','43','1','1*35','35','9800','2025-12-14 13:09:53','2025-12-14 13:09:53');
INSERT INTO `item_detail` VALUES ('66','44','1','1*35','35','11550','2025-12-14 13:29:09','2025-12-14 13:29:09');
INSERT INTO `item_detail` VALUES ('67','45','1','1*30','30','17100','2025-12-14 18:19:11','2025-12-14 18:19:11');
INSERT INTO `item_detail` VALUES ('68','46','1','1*30','30','15300','2025-12-14 18:20:52','2025-12-14 18:20:52');
INSERT INTO `item_detail` VALUES ('69','47','1','1*30','30','9360','2025-12-14 18:22:22','2025-12-14 18:22:22');
INSERT INTO `item_detail` VALUES ('70','48','1','1*192','192','13440','2025-12-14 18:23:23','2025-12-14 18:23:23');
INSERT INTO `item_detail` VALUES ('71','49','1','0','0','0','2025-12-14 18:26:26','2025-12-14 18:26:26');
INSERT INTO `item_detail` VALUES ('72','50','1','1*360','360','11700','2025-12-14 18:37:34','2025-12-14 18:37:34');
INSERT INTO `item_detail` VALUES ('73','51','1','1*60','60','10500','2025-12-17 19:45:40','2025-12-17 19:45:40');
INSERT INTO `item_detail` VALUES ('74','52','1','1*32','32','8640','2025-12-17 19:47:42','2025-12-17 19:47:42');
INSERT INTO `item_detail` VALUES ('75','53','1','1*56','56','8848','2025-12-17 19:48:31','2025-12-17 19:48:31');
INSERT INTO `item_detail` VALUES ('76','54','1','1*70','70','8820','2025-12-17 19:49:25','2025-12-17 19:49:25');
INSERT INTO `item_detail` VALUES ('77','55','1','1*96','96','15840','2025-12-17 20:00:40','2025-12-17 20:00:40');
INSERT INTO `item_detail` VALUES ('78','56','1','0','0','0','2025-12-18 18:20:08','2025-12-18 18:20:08');
INSERT INTO `item_detail` VALUES ('79','57','1','1*96','96','16320','2025-12-18 18:21:19','2025-12-18 18:21:19');
INSERT INTO `item_detail` VALUES ('80','58','1','1*90','90','13950','2025-12-18 18:22:19','2025-12-18 18:22:19');
INSERT INTO `item_detail` VALUES ('82','60','1','1*36','36','17280','2025-12-18 18:32:14','2025-12-18 18:32:14');
INSERT INTO `item_detail` VALUES ('83','61','1','1*36','36','9360','2025-12-18 18:35:18','2025-12-18 18:35:18');
INSERT INTO `item_detail` VALUES ('84','62','1','1*100','100','17500','2025-12-18 18:45:03','2025-12-18 18:45:03');
INSERT INTO `item_detail` VALUES ('85','63','1','1*120','120','16800','2025-12-18 18:46:20','2025-12-18 18:46:20');
INSERT INTO `item_detail` VALUES ('86','64','1','1*36','36','18000','2025-12-18 18:50:22','2025-12-18 18:50:22');
INSERT INTO `item_detail` VALUES ('87','65','1','1*36','36','10800','2025-12-18 18:58:02','2025-12-18 18:58:02');
INSERT INTO `item_detail` VALUES ('88','66','1','1*360','360','14040','2025-12-18 20:17:10','2025-12-18 20:17:10');
INSERT INTO `item_detail` VALUES ('89','67','1','1*300','300','17700','2025-12-18 20:20:26','2025-12-18 20:20:26');
INSERT INTO `item_detail` VALUES ('90','68','1','1*192','192','15936','2025-12-18 20:21:43','2025-12-18 20:21:43');
INSERT INTO `item_detail` VALUES ('91','69','1','1*144','144','16704','2025-12-18 20:24:26','2025-12-18 20:24:26');
INSERT INTO `item_detail` VALUES ('92','70','1','1*90','90','14220','2025-12-18 20:25:37','2025-12-18 20:25:37');
INSERT INTO `item_detail` VALUES ('93','71','1','1*72','72','17064','2025-12-18 20:26:48','2025-12-18 20:26:48');
INSERT INTO `item_detail` VALUES ('97','72','7','Sig 0W-20 12x 946mL','12','12000','2025-12-19 16:43:32','2025-12-19 16:43:32');
INSERT INTO `item_detail` VALUES ('98','72','7','Sig 0W20 Gal','4','16000','2025-12-19 16:43:32','2025-12-19 16:43:32');
INSERT INTO `item_detail` VALUES ('99','73','1','1*36','36','12960','2026-01-03 16:25:49','2026-01-03 16:25:49');
INSERT INTO `item_detail` VALUES ('100','74','1','0','0','0','2026-01-03 16:32:00','2026-01-03 16:32:00');
INSERT INTO `item_detail` VALUES ('101','75','1','1*48','48','16320','2026-01-03 16:34:00','2026-01-03 16:34:00');
INSERT INTO `item_detail` VALUES ('102','76','1','1*60','60','13200','2026-01-03 17:32:20','2026-01-03 17:32:20');
INSERT INTO `item_detail` VALUES ('103','77','1','1*64','64','14080','2026-01-03 17:33:50','2026-01-03 17:33:50');
INSERT INTO `item_detail` VALUES ('104','78','1','1*72','72','11520','2026-01-03 17:34:52','2026-01-03 17:34:52');
INSERT INTO `item_detail` VALUES ('105','79','1','1*64','64','9600','2026-01-03 17:44:34','2026-01-03 17:44:34');
INSERT INTO `item_detail` VALUES ('106','80','1','1*90','90','13500','2026-01-03 17:45:40','2026-01-03 17:45:40');
INSERT INTO `item_detail` VALUES ('107','81','1','1*60','60','8700','2026-01-03 17:50:09','2026-01-03 17:50:09');
INSERT INTO `item_detail` VALUES ('108','82','1','1*100','100','6500','2026-01-03 17:55:10','2026-01-03 17:55:10');
INSERT INTO `item_detail` VALUES ('109','83','1','1*72','72','5760','2026-01-03 17:56:48','2026-01-03 17:56:48');
INSERT INTO `item_detail` VALUES ('110','84','1','1*100','100','6500','2026-01-03 17:58:12','2026-01-03 17:58:12');
INSERT INTO `item_detail` VALUES ('111','85','1','1*100','100','8200','2026-01-03 18:00:44','2026-01-03 18:00:44');
INSERT INTO `item_detail` VALUES ('112','86','1','1*200','200','13000','2026-01-03 18:01:34','2026-01-03 18:01:34');
INSERT INTO `item_detail` VALUES ('113','87','1','1*100','100','7500','2026-01-03 18:03:37','2026-01-03 18:03:37');
INSERT INTO `item_detail` VALUES ('114','88','1','1*99','99','8415','2026-01-03 18:05:08','2026-01-03 18:05:08');
INSERT INTO `item_detail` VALUES ('115','89','1','1*60','60','9600','2026-01-03 18:06:01','2026-01-03 18:06:01');
INSERT INTO `item_detail` VALUES ('116','90','1','1*100','100','7500','2026-01-03 18:09:07','2026-01-03 18:09:07');
INSERT INTO `item_detail` VALUES ('117','91','1','1*180','180','12600','2026-01-03 18:19:43','2026-01-03 18:19:43');
INSERT INTO `item_detail` VALUES ('118','92','1','1*72','72','5760','2026-01-03 18:20:32','2026-01-03 18:20:32');
INSERT INTO `item_detail` VALUES ('119','93','1','1*60','60','7800','2026-01-03 18:24:03','2026-01-03 18:24:03');
INSERT INTO `item_detail` VALUES ('120','94','1','1*50','50','8000','2026-01-10 17:01:15','2026-01-10 17:01:15');
INSERT INTO `item_detail` VALUES ('121','95','1','1*180','180','11700','2026-01-11 21:05:16','2026-01-11 21:05:16');
INSERT INTO `item_detail` VALUES ('122','96','1','1*70','70','5250','2026-01-11 21:53:18','2026-01-11 21:53:18');
INSERT INTO `item_detail` VALUES ('123','59','1','1*90','90','14850','2026-01-11 23:07:18','2026-01-11 23:07:18');


DROP TABLE IF EXISTS `item_master`;
CREATE TABLE `item_master` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `purchase_rate` bigint unsigned DEFAULT NULL,
  `sale_rate` bigint unsigned DEFAULT NULL,
  `qty_pcs` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_master` VALUES ('9','TESTE ITEM','6','8','100','200','100','7','2025-10-27 19:13:27','2025-10-27 19:22:23');
INSERT INTO `item_master` VALUES ('10','3 Liter Pure','10','6','0','115','108','1','2025-10-27 19:43:14','2025-10-27 19:43:14');
INSERT INTO `item_master` VALUES ('11','3 Liter Semi','10','6','0','83','108','1','2025-10-27 19:44:21','2025-10-27 19:44:21');
INSERT INTO `item_master` VALUES ('12','3 Liter Silver','10','6','0','0','72','1','2025-10-27 20:13:12','2025-12-07 11:35:18');
INSERT INTO `item_master` VALUES ('13','6 Liter Pure','10','6','0','185','72','1','2025-11-08 16:10:29','2025-12-07 11:40:08');
INSERT INTO `item_master` VALUES ('14','DROSPA 25 X 2ml AMPOULES INJECTION','13','9','123','123','123','8','2025-11-10 21:39:11','2025-11-10 21:39:44');
INSERT INTO `item_master` VALUES ('16','6 Liter Semi','10','6','0','99','72','1','2025-12-07 11:44:03','2025-12-07 11:44:03');
INSERT INTO `item_master` VALUES ('17','6 Liter Trim','10','6','0','147','72','1','2025-12-07 11:45:26','2025-12-07 11:45:26');
INSERT INTO `item_master` VALUES ('18','6 Liter Silver','10','6','0','0','72','1','2025-12-07 12:15:34','2025-12-07 12:15:34');
INSERT INTO `item_master` VALUES ('19','9 Liter Pure','10','11','0','238','40','1','2025-12-11 18:29:32','2025-12-11 18:29:32');
INSERT INTO `item_master` VALUES ('20','9 Liter Semi','10','11','0','135','40','1','2025-12-11 18:31:38','2025-12-11 18:31:38');
INSERT INTO `item_master` VALUES ('21','9 Liter Trim','10','11','0','200','40','1','2025-12-11 18:33:19','2025-12-11 18:33:19');
INSERT INTO `item_master` VALUES ('22','9 Liter Silver','10','11','0','0','40','1','2025-12-11 18:34:08','2025-12-11 18:34:08');
INSERT INTO `item_master` VALUES ('23','14 Liter Pure','10','11','0','325','40','1','2025-12-11 18:36:17','2025-12-11 18:36:17');
INSERT INTO `item_master` VALUES ('24','14 Liter Semi','10','11','0','175','40','1','2025-12-11 18:37:18','2025-12-11 18:37:18');
INSERT INTO `item_master` VALUES ('25','14 Liter Trim','10','11','0','270','40','1','2025-12-11 18:38:14','2025-12-11 18:38:14');
INSERT INTO `item_master` VALUES ('26','14 Liter Silver','10','11','0','0','40','1','2025-12-11 19:02:53','2025-12-11 19:02:53');
INSERT INTO `item_master` VALUES ('27','17 Liter Pure','10','11','0','410','35','1','2025-12-11 19:04:58','2025-12-11 19:04:58');
INSERT INTO `item_master` VALUES ('28','17 Liter Semi','10','11','0','235','40','1','2025-12-11 19:25:53','2025-12-11 19:25:53');
INSERT INTO `item_master` VALUES ('29','17 Liter Silver','10','11','0','255','35','1','2025-12-14 12:25:09','2025-12-14 12:25:09');
INSERT INTO `item_master` VALUES ('30','17 Liter Pure BD','10','11','0','320','40','1','2025-12-14 12:32:03','2025-12-14 12:32:03');
INSERT INTO `item_master` VALUES ('31','17 Liter Semi BD','10','11','0','190','40','1','2025-12-14 12:33:27','2025-12-14 12:33:27');
INSERT INTO `item_master` VALUES ('32','17 Liter Silver BD','10','11','0','215','40','1','2025-12-14 12:35:00','2025-12-14 12:35:00');
INSERT INTO `item_master` VALUES ('33','20 Liter Pure','10','11','0','535','30','1','2025-12-14 12:36:43','2025-12-14 12:36:43');
INSERT INTO `item_master` VALUES ('34','20 Liter Semi','10','11','0','320','30','1','2025-12-14 12:38:37','2025-12-14 12:38:37');
INSERT INTO `item_master` VALUES ('35','20 Liter Silver','10','11','0','370','30','1','2025-12-14 12:43:17','2025-12-14 12:43:17');
INSERT INTO `item_master` VALUES ('36','20 Liter Pure BD','10','11','0','445','35','1','2025-12-14 12:45:29','2025-12-14 12:45:29');
INSERT INTO `item_master` VALUES ('37','20 Liter Semi BD','10','11','0','270','35','1','2025-12-14 12:51:17','2025-12-14 12:51:17');
INSERT INTO `item_master` VALUES ('38','20 Liter Silver BD','10','11','0','300','35','1','2025-12-14 12:52:16','2025-12-14 12:52:16');
INSERT INTO `item_master` VALUES ('39','27 Liter Pure','10','11','0','560','30','1','2025-12-14 12:54:06','2025-12-14 12:54:06');
INSERT INTO `item_master` VALUES ('40','27 Liter Semi','10','11','0','345','30','1','2025-12-14 12:56:17','2025-12-14 12:56:17');
INSERT INTO `item_master` VALUES ('41','27 Liter Silver','10','11','0','390','30','1','2025-12-14 12:59:57','2025-12-14 12:59:57');
INSERT INTO `item_master` VALUES ('42','27 Liter Pure BD','10','11','0','470','35','1','2025-12-14 13:06:36','2025-12-14 13:06:36');
INSERT INTO `item_master` VALUES ('43','27 Liter Semi BD','10','11','0','280','35','1','2025-12-14 13:09:53','2025-12-14 13:09:53');
INSERT INTO `item_master` VALUES ('44','27 Liter Silver BD','10','11','0','330','35','1','2025-12-14 13:29:09','2025-12-14 13:29:09');
INSERT INTO `item_master` VALUES ('45','Bath Mug Water Color','15','6','0','570','30','1','2025-12-14 18:19:11','2025-12-14 18:19:11');
INSERT INTO `item_master` VALUES ('46','Bath Mug Pure Band Color','15','6','0','510','30','1','2025-12-14 18:20:52','2025-12-14 18:20:52');
INSERT INTO `item_master` VALUES ('47','Bath Mug Semi','15','6','0','312','30','1','2025-12-14 18:22:22','2025-12-14 18:22:22');
INSERT INTO `item_master` VALUES ('48','Bath Mug Pure long Handle','15','6','0','70','192','1','2025-12-14 18:23:23','2025-12-14 18:23:23');
INSERT INTO `item_master` VALUES ('49','Bath Mug Pure IML','15','6','0','0','0','1','2025-12-14 18:26:26','2025-12-14 18:26:26');
INSERT INTO `item_master` VALUES ('50','Bath Mug Brown','15','6','0','33','360','1','2025-12-14 18:37:34','2025-12-14 18:37:34');
INSERT INTO `item_master` VALUES ('51','Jug Family Pure','16','6','0','175','60','1','2025-12-17 19:45:40','2025-12-17 19:45:40');
INSERT INTO `item_master` VALUES ('52','Jug Hot & Cool','15','6','0','270','32','1','2025-12-17 19:47:42','2025-12-17 19:47:42');
INSERT INTO `item_master` VALUES ('53','Jug Fridge Door','16','6','0','158','56','1','2025-12-17 19:48:31','2025-12-17 19:48:31');
INSERT INTO `item_master` VALUES ('54','Jug Flower','16','6','0','126','70','1','2025-12-17 19:49:25','2025-12-17 19:49:25');
INSERT INTO `item_master` VALUES ('55','Lunch Box Bounty','17','6','0','165','96','1','2025-12-17 20:00:40','2025-12-17 20:00:40');
INSERT INTO `item_master` VALUES ('56','Lunch Box Bounty Special','17','6','0','0','0','1','2025-12-18 18:20:08','2025-12-18 18:20:08');
INSERT INTO `item_master` VALUES ('57','Lunch Box Kitkat','17','6','0','170','96','1','2025-12-18 18:21:19','2025-12-18 18:21:19');
INSERT INTO `item_master` VALUES ('58','Lunch Box Subway','17','6','0','155','90','1','2025-12-18 18:22:19','2025-12-18 18:22:19');
INSERT INTO `item_master` VALUES ('59','Lunch Box Subway Special','17','6','0','165','90','1','2025-12-18 18:22:54','2026-01-11 23:07:18');
INSERT INTO `item_master` VALUES ('60','Chaba Gool Pure','18','12','0','480','36','1','2025-12-18 18:32:14','2025-12-18 18:32:14');
INSERT INTO `item_master` VALUES ('61','Chaba Gool Semi','18','12','0','260','36','1','2025-12-18 18:35:18','2025-12-18 18:35:18');
INSERT INTO `item_master` VALUES ('62','Chaba Afghan IML 2/P','18','12','0','175','100','1','2025-12-18 18:45:03','2025-12-18 18:45:03');
INSERT INTO `item_master` VALUES ('63','Chaba Afghan Semi 3/P','18','12','0','140','120','1','2025-12-18 18:46:20','2025-12-18 18:46:20');
INSERT INTO `item_master` VALUES ('64','Prime Chaba Pure','18','12','0','500','36','1','2025-12-18 18:50:22','2025-12-18 18:50:22');
INSERT INTO `item_master` VALUES ('65','Prime Chaba Semi','18','12','0','300','36','1','2025-12-18 18:58:02','2025-12-18 18:58:02');
INSERT INTO `item_master` VALUES ('66','Jar No. 3','19','6','0','39','360','1','2025-12-18 20:17:10','2025-12-18 20:17:10');
INSERT INTO `item_master` VALUES ('67','Jar No. 4','19','6','0','59','300','1','2025-12-18 20:20:26','2025-12-18 20:20:26');
INSERT INTO `item_master` VALUES ('68','Jar No. 5','19','6','0','83','192','1','2025-12-18 20:21:43','2025-12-18 20:21:43');
INSERT INTO `item_master` VALUES ('69','Jar No. 6','19','6','0','116','144','1','2025-12-18 20:24:25','2025-12-18 20:24:25');
INSERT INTO `item_master` VALUES ('70','Jar No. 7','19','6','0','158','90','1','2025-12-18 20:25:37','2025-12-18 20:25:37');
INSERT INTO `item_master` VALUES ('71','Jar No. 8','19','6','0','237','72','1','2025-12-18 20:26:48','2025-12-18 20:26:48');
INSERT INTO `item_master` VALUES ('72','Sig 0W-20','20','13','1000','1500','1200','7','2025-12-19 16:33:41','2025-12-19 16:35:25');
INSERT INTO `item_master` VALUES ('73','Soap Dish','21','6','','360','36','1','2026-01-03 16:25:49','2026-01-03 16:25:49');
INSERT INTO `item_master` VALUES ('74','Bowl Set 5/P','22','6','','420','0','1','2026-01-03 16:32:00','2026-01-03 16:32:00');
INSERT INTO `item_master` VALUES ('75','Bowl Set 3/P','22','6','','340','48','1','2026-01-03 16:34:00','2026-01-03 16:34:00');
INSERT INTO `item_master` VALUES ('76','Karhi Bowl 3/P','22','6','','220','60','1','2026-01-03 17:32:20','2026-01-03 17:32:20');
INSERT INTO `item_master` VALUES ('77','Karhi Bowl 2/P','22','6','','220','64','1','2026-01-03 17:33:50','2026-01-03 17:33:50');
INSERT INTO `item_master` VALUES ('78','Atta Bowl 1/P','22','6','','160','72','1','2026-01-03 17:34:52','2026-01-03 17:34:52');
INSERT INTO `item_master` VALUES ('79','Multi Purpose Rack 3/P','23','6','','150','64','1','2026-01-03 17:44:34','2026-01-03 17:44:34');
INSERT INTO `item_master` VALUES ('80','Office Rack','23','6','0','150','90','1','2026-01-03 17:45:40','2026-01-03 17:45:40');
INSERT INTO `item_master` VALUES ('81','Fruit Rack 3/P','23','12','','145','60','1','2026-01-03 17:50:09','2026-01-03 17:50:09');
INSERT INTO `item_master` VALUES ('82','3 Liter Semi Riyal','24','11','','65','100','1','2026-01-03 17:55:10','2026-01-03 17:55:10');
INSERT INTO `item_master` VALUES ('83','6 Liter Semi Riyal','24','11','','80','72','1','2026-01-03 17:56:48','2026-01-03 17:56:48');
INSERT INTO `item_master` VALUES ('84','Piyala','24','11','','65','100','1','2026-01-03 17:58:12','2026-01-03 17:58:12');
INSERT INTO `item_master` VALUES ('85','Piyala IML','24','11','','82','100','1','2026-01-03 18:00:44','2026-01-03 18:00:44');
INSERT INTO `item_master` VALUES ('86','Chaba Gool Semi Riyal','24','12','','65','200','1','2026-01-03 18:01:34','2026-01-03 18:01:34');
INSERT INTO `item_master` VALUES ('87','Gool Rack Silver Riyal 2/P','24','12','','75','100','1','2026-01-03 18:03:37','2026-01-03 18:03:37');
INSERT INTO `item_master` VALUES ('88','Choras Rack Silver Riyal 2/P','24','12','','85','99','1','2026-01-03 18:05:08','2026-01-03 18:05:08');
INSERT INTO `item_master` VALUES ('89','Corner Rack 3/P','23','6','','160','60','1','2026-01-03 18:06:01','2026-01-03 18:06:01');
INSERT INTO `item_master` VALUES ('90','Chaba Afghan Semi Riyal 2/P','24','12','','75','200','1','2026-01-03 18:09:07','2026-01-03 18:09:07');
INSERT INTO `item_master` VALUES ('91','Chaaye Poni','24','6','','70','180','1','2026-01-03 18:19:43','2026-01-03 18:19:43');
INSERT INTO `item_master` VALUES ('92','Laundry','24','11','','80','72','1','2026-01-03 18:20:32','2026-01-03 18:20:32');
INSERT INTO `item_master` VALUES ('93','Baby Pot Semi','25','11','','130','60','1','2026-01-03 18:24:03','2026-01-03 18:24:03');
INSERT INTO `item_master` VALUES ('94','Laundry Silver/Brown','26','11','','160','50','1','2026-01-10 17:01:15','2026-01-10 17:01:15');
INSERT INTO `item_master` VALUES ('95','Chaaye Poni New','24','6','0','65','180','1','2026-01-11 21:05:16','2026-01-11 21:05:16');
INSERT INTO `item_master` VALUES ('96','White Jug','24','12','','75','70','1','2026-01-11 21:53:18','2026-01-11 21:53:18');


DROP TABLE IF EXISTS `item_types`;
CREATE TABLE `item_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `item_types` VALUES ('1','','Shampoo','2025-09-17 18:33:21','2025-09-17 18:33:21','2');
INSERT INTO `item_types` VALUES ('5','fp','Shampo','2025-10-15 08:35:53','2025-10-15 08:38:30','7');
INSERT INTO `item_types` VALUES ('6','rp','ShampoRAW','2025-10-15 10:16:16','2025-10-15 10:16:16','7');
INSERT INTO `item_types` VALUES ('10','','Buckets','2025-10-25 18:54:20','2025-10-25 18:54:20','1');
INSERT INTO `item_types` VALUES ('13','','laminations','2025-11-10 21:36:03','2025-11-10 21:36:10','8');
INSERT INTO `item_types` VALUES ('15','','Bath Mug','2025-12-14 18:17:29','2025-12-14 18:17:29','1');
INSERT INTO `item_types` VALUES ('16','','Jug','2025-12-17 19:34:46','2025-12-17 19:34:46','1');
INSERT INTO `item_types` VALUES ('17','','Lunch Box','2025-12-17 19:51:58','2025-12-17 19:51:58','1');
INSERT INTO `item_types` VALUES ('18','','Chaba','2025-12-18 18:28:10','2025-12-18 18:28:10','1');
INSERT INTO `item_types` VALUES ('19','','Jar','2025-12-18 20:16:10','2025-12-18 20:16:10','1');
INSERT INTO `item_types` VALUES ('20','','Engine Oil','2025-12-19 16:22:54','2025-12-19 16:22:54','7');
INSERT INTO `item_types` VALUES ('21','','Soap','2026-01-03 16:22:58','2026-01-03 16:22:58','1');
INSERT INTO `item_types` VALUES ('22','','Bowl','2026-01-03 16:30:08','2026-01-03 16:30:08','1');
INSERT INTO `item_types` VALUES ('23','','Rack','2026-01-03 17:38:08','2026-01-03 17:38:08','1');
INSERT INTO `item_types` VALUES ('24','','Riyal','2026-01-03 17:42:35','2026-01-03 17:42:35','1');
INSERT INTO `item_types` VALUES ('25','','Baby Pot','2026-01-03 18:21:15','2026-01-03 18:21:15','1');
INSERT INTO `item_types` VALUES ('26','','Laundry','2026-01-03 18:22:14','2026-01-03 18:23:08','1');


DROP TABLE IF EXISTS `level1s`;
CREATE TABLE `level1s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level1s` VALUES ('2','Current Assets','01','3','2025-09-17 18:49:15','2025-09-17 18:49:15','2');
INSERT INTO `level1s` VALUES ('3','Current Assets','01','3','2025-09-18 00:40:07','2025-11-08 00:44:53','1');
INSERT INTO `level1s` VALUES ('4','Direct Expense','01','5','2025-09-18 00:55:45','2025-09-18 00:55:45','1');
INSERT INTO `level1s` VALUES ('5','Current Liabilities','01','2','2025-09-18 01:09:06','2025-09-18 01:09:06','1');
INSERT INTO `level1s` VALUES ('6','Current Revenue','01','4','2025-09-18 12:33:46','2025-09-18 12:33:46','1');
INSERT INTO `level1s` VALUES ('7','Current Assets','01','3','2025-09-20 14:32:26','2025-09-20 14:32:26','7');
INSERT INTO `level1s` VALUES ('8','Current Liabilities','01','2','2025-09-20 14:32:38','2025-09-20 14:32:38','7');
INSERT INTO `level1s` VALUES ('9','Capital','01','1','2025-09-22 01:03:53','2025-10-25 18:32:57','1');
INSERT INTO `level1s` VALUES ('11','Direct Expense','01','5','2025-10-15 12:12:20','2025-10-15 12:12:20','7');
INSERT INTO `level1s` VALUES ('12','Current Asset','01','3','2025-11-10 14:06:48','2025-11-10 14:09:09','8');
INSERT INTO `level1s` VALUES ('13','Long-Term Liabilities','01','2','2025-11-10 14:07:06','2025-11-10 14:07:06','8');
INSERT INTO `level1s` VALUES ('14','Sales Revenue','01','4','2025-11-10 14:07:21','2025-11-10 14:07:21','8');
INSERT INTO `level1s` VALUES ('15','Branch Revenue','01','4','2025-12-19 16:19:17','2025-12-19 16:19:17','7');


DROP TABLE IF EXISTS `level2s`;
CREATE TABLE `level2s` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level2_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level1_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `level2s` VALUES ('2','Bank Accounts','001','2','2025-09-17 18:50:09','2025-09-17 18:50:09','2');
INSERT INTO `level2s` VALUES ('3','Bank Accounts','001','3','2025-09-18 00:53:57','2025-09-18 00:53:57','1');
INSERT INTO `level2s` VALUES ('4','Cash Accounts','002','3','2025-09-18 00:54:07','2025-09-18 00:54:07','1');
INSERT INTO `level2s` VALUES ('5','Purchase Debit Level','001','4','2025-09-18 00:56:18','2025-09-18 00:56:18','1');
INSERT INTO `level2s` VALUES ('6','Suppliers','001','5','2025-09-18 01:09:20','2025-09-18 01:09:20','1');
INSERT INTO `level2s` VALUES ('7','Sale Credit Accunts','001','6','2025-09-18 12:34:10','2025-09-22 10:44:03','1');
INSERT INTO `level2s` VALUES ('8','Customer','002','5','2025-09-18 16:21:49','2025-09-18 16:21:49','1');
INSERT INTO `level2s` VALUES ('9','Caiptal Account','001','9','2025-09-22 01:05:14','2025-10-25 18:33:23','1');
INSERT INTO `level2s` VALUES ('11','Employees','003','5','2025-10-01 14:43:39','2025-10-01 14:43:39','1');
INSERT INTO `level2s` VALUES ('12','Customers','001','7','2025-10-15 12:10:40','2025-10-15 12:10:59','7');
INSERT INTO `level2s` VALUES ('13','Supplier','002','8','2025-10-15 12:10:51','2025-10-15 12:10:51','7');
INSERT INTO `level2s` VALUES ('14','Bank Accounts','002','7','2025-10-15 12:11:30','2025-10-15 12:11:30','7');
INSERT INTO `level2s` VALUES ('15','Cash Accounts','003','7','2025-10-15 12:11:44','2025-10-15 12:11:44','7');
INSERT INTO `level2s` VALUES ('16','Purchase Accounts','001','11','2025-10-15 12:12:39','2025-10-15 12:12:39','7');
INSERT INTO `level2s` VALUES ('17','Expense','002','11','2025-10-18 07:09:16','2025-10-18 07:09:16','7');
INSERT INTO `level2s` VALUES ('18','Cash & Banks','001','12','2025-11-10 14:09:33','2025-11-10 21:23:02','8');
INSERT INTO `level2s` VALUES ('19','Inventory','002','12','2025-11-10 14:09:50','2025-11-10 14:09:50','8');
INSERT INTO `level2s` VALUES ('22','Stock Account','004','7','2025-12-19 16:18:40','2025-12-19 16:18:40','7');
INSERT INTO `level2s` VALUES ('23','Revenue from Sales','001','15','2025-12-19 16:19:33','2025-12-19 16:19:33','7');


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1','2019_12_14_000001_create_personal_access_tokens_table','1');
INSERT INTO `migrations` VALUES ('2','2025_09_18_120600_create_purchase_return_masters_table','2');
INSERT INTO `migrations` VALUES ('3','2025_09_18_120750_create_purchase_return_invoices_table','2');
INSERT INTO `migrations` VALUES ('4','2025_09_18_134602_create_customers_table','3');
INSERT INTO `migrations` VALUES ('5','2025_09_18_135718_create_sale_invoice_table','4');
INSERT INTO `migrations` VALUES ('6','2025_09_18_140058_create_sale_invoice_return_table','4');
INSERT INTO `migrations` VALUES ('7','2025_09_19_172738_create_sale_return_masters_table','5');
INSERT INTO `migrations` VALUES ('8','2025_09_19_184055_create_sale_return_invoices_table','5');
INSERT INTO `migrations` VALUES ('9','2025_09_20_155910_add_cid_to_item_logs_table','6');
INSERT INTO `migrations` VALUES ('10','2025_10_15_133111_add_item_type_to_item_type_table','7');
INSERT INTO `migrations` VALUES ('11','2025_10_15_151806_add_col_to_item_masters_table','8');
INSERT INTO `migrations` VALUES ('16','2025_10_15_152737_create_production_master_table','9');
INSERT INTO `migrations` VALUES ('17','2025_10_15_153012_create_production_detail_table','9');
INSERT INTO `migrations` VALUES ('20','2025_10_15_170406_create_consumption_masters_table','10');
INSERT INTO `migrations` VALUES ('21','2025_10_15_170412_create_consumption_details_table','10');
INSERT INTO `migrations` VALUES ('22','2025_10_16_003713_create_stock_adj_master_table','11');
INSERT INTO `migrations` VALUES ('23','2025_10_16_003734_create_stock_adj_table','11');
INSERT INTO `migrations` VALUES ('24','2025_10_16_005456_add_col_open_qty_to_item_masters_table','12');
INSERT INTO `migrations` VALUES ('27','2025_10_16_123138_create_production_consumed_table','13');
INSERT INTO `migrations` VALUES ('28','2025_10_17_191353_update_col_supplier_table','14');
INSERT INTO `migrations` VALUES ('29','2025_10_18_102053_add_col_to_production_master_table','15');
INSERT INTO `migrations` VALUES ('30','2025_10_18_115508_create_expense_detail_table','16');
INSERT INTO `migrations` VALUES ('31','2025_10_18_115646_create_expense_masters_table','16');
INSERT INTO `migrations` VALUES ('32','2025_10_22_011511_create_store_table','17');
INSERT INTO `migrations` VALUES ('34','2025_10_22_012808_create_item_master_table','18');
INSERT INTO `migrations` VALUES ('35','2025_10_22_013455_item_detail_table','19');
INSERT INTO `migrations` VALUES ('36','2025_10_22_023123_add_col_crt_qty_to_item_detail_table','20');
INSERT INTO `migrations` VALUES ('37','2025_10_22_125703_create_sale_invoices_table','21');
INSERT INTO `migrations` VALUES ('38','2025_10_22_125729_create_sale_invoice_items_table','22');
INSERT INTO `migrations` VALUES ('39','2025_10_22_130403_add_col_to_sale_invoice_items_table','23');
INSERT INTO `migrations` VALUES ('40','2025_10_22_130431_add_col_to_sale_invoices_table','23');
INSERT INTO `migrations` VALUES ('41','2025_10_22_140206_add_col_to_sale_invoices_table','24');
INSERT INTO `migrations` VALUES ('42','2025_10_22_140302_add_col_to_sale_invoice_items_table','25');
INSERT INTO `migrations` VALUES ('43','2025_10_22_170145_drop_col_to_sale_invoice_items_table','26');
INSERT INTO `migrations` VALUES ('44','2025_10_22_185204_add_col_to_sale_invoice_items_table','27');
INSERT INTO `migrations` VALUES ('45','2025_10_22_185548_drop_col_to_sale_invoice_items_table','28');
INSERT INTO `migrations` VALUES ('46','2025_10_22_192840_add_col_to_sale_invoice_table','29');
INSERT INTO `migrations` VALUES ('47','2025_10_22_200851_create_purchase_invoice_table','30');
INSERT INTO `migrations` VALUES ('48','2025_10_22_201052_create_purchase_invoice_item_table','31');
INSERT INTO `migrations` VALUES ('49','2025_10_23_000629_create_sale_return_invoice_table','32');
INSERT INTO `migrations` VALUES ('50','2025_10_23_000716_create_sale_return_invoice_item_table','32');
INSERT INTO `migrations` VALUES ('51','2025_10_23_015807_create_purchase_return_invoice_table','33');
INSERT INTO `migrations` VALUES ('52','2025_10_23_015816_create_purchase_return_invoice_item_table','33');
INSERT INTO `migrations` VALUES ('53','2025_10_23_170510_create_opening_stocks_table','34');
INSERT INTO `migrations` VALUES ('54','2025_10_23_181824_create_stock_adjustment_table','35');
INSERT INTO `migrations` VALUES ('55','2025_10_23_183745_add_col_to_sale_return_details_table','35');
INSERT INTO `migrations` VALUES ('56','2025_10_23_183950_add_col_to_purchase_invoice_details_table','35');
INSERT INTO `migrations` VALUES ('57','2025_10_23_184021_add_col_to_purchase_return_details_table','35');
INSERT INTO `migrations` VALUES ('58','2025_10_24_121456_add_p_qty_to_sale_invoice_details','36');
INSERT INTO `migrations` VALUES ('59','2025_10_24_121534_add_p_qty_to_purchase_invoice_details','36');
INSERT INTO `migrations` VALUES ('60','2025_10_24_121613_add_p_qty_to_purchase_return_details','36');
INSERT INTO `migrations` VALUES ('61','2025_10_24_121620_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('62','2025_10_24_125612_add_p_qty_to_sale_return_details','36');
INSERT INTO `migrations` VALUES ('63','2025_10_24_144509_add_p_qty_to_opening_stocks_table','36');
INSERT INTO `migrations` VALUES ('64','2025_10_24_144607_add_p_qty_to_stock_adjustment_table','36');
INSERT INTO `migrations` VALUES ('65','2025_11_05_011214_add_col_to_purchase_invoice_masters_table','37');
INSERT INTO `migrations` VALUES ('66','2025_11_05_011427_add_col_to_sale_invoices_masters_table','37');
INSERT INTO `migrations` VALUES ('67','2026_01_06_123922_add_col_to_sale_invoice_detail_table','38');


DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `module` VALUES ('1','Level1','','');
INSERT INTO `module` VALUES ('2','Level2','','');
INSERT INTO `module` VALUES ('3','Chart Of Account','','');
INSERT INTO `module` VALUES ('4','Cash Payment','','');
INSERT INTO `module` VALUES ('5','Cash Receipt','','');
INSERT INTO `module` VALUES ('6','Bank Payment','','');
INSERT INTO `module` VALUES ('7','Bank Receipt','','');
INSERT INTO `module` VALUES ('8','Journal Voucher','','');
INSERT INTO `module` VALUES ('9','Opening Balance','','');
INSERT INTO `module` VALUES ('10','Ledger','','');
INSERT INTO `module` VALUES ('11','Cash Book','','');
INSERT INTO `module` VALUES ('12','Payables','','');
INSERT INTO `module` VALUES ('13','Recieveable','','');
INSERT INTO `module` VALUES ('14','Trial Balance','','');
INSERT INTO `module` VALUES ('15','Purchase Invoice','','');
INSERT INTO `module` VALUES ('16','Purchase Return Invoice','','');
INSERT INTO `module` VALUES ('17','Supplier','','');
INSERT INTO `module` VALUES ('18','Sale Invoice','','');
INSERT INTO `module` VALUES ('19','Sale Return Invoice','','');
INSERT INTO `module` VALUES ('20','Customer','','');
INSERT INTO `module` VALUES ('21','Item Category','','');
INSERT INTO `module` VALUES ('22','Units','','');
INSERT INTO `module` VALUES ('23','Store','','');
INSERT INTO `module` VALUES ('24','Item Registration','','');
INSERT INTO `module` VALUES ('25','Stock Adjustment','','');
INSERT INTO `module` VALUES ('26','Stock Report','','');
INSERT INTO `module` VALUES ('27','ERP Parameters','','');
INSERT INTO `module` VALUES ('28','Item Registration Log','','');
INSERT INTO `module` VALUES ('29','App Module','','');
INSERT INTO `module` VALUES ('30','View Company','','');
INSERT INTO `module` VALUES ('36','Store Wise Report','2025-10-05 22:18:19','2025-10-05 22:18:19');
INSERT INTO `module` VALUES ('37','Brand Name','','');
INSERT INTO `module` VALUES ('39','Opening Stock','','');


DROP TABLE IF EXISTS `opening_stocks`;
CREATE TABLE `opening_stocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `opening_stocks` VALUES ('2','7','9','22','3','2025-10-27','1.00','0.00','50000.00','100.00','50000.00','','2025-10-27 19:23:27','2025-10-27 19:23:27','250');
INSERT INTO `opening_stocks` VALUES ('4','7','72','97','7','2025-12-19','100.00','6.00','12000.00','1000.00','1206000.00','','2025-12-19 16:45:33','2025-12-19 16:45:33','12');
INSERT INTO `opening_stocks` VALUES ('5','7','72','98','7','2025-12-19','50.00','2.00','16000.00','1000.00','802000.00','','2025-12-19 16:48:39','2025-12-19 16:48:39','4');


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_details`;
CREATE TABLE `purchase_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_invoice_masters`;
CREATE TABLE `purchase_invoice_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `purchase_return_details`;
CREATE TABLE `purchase_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_details` VALUES ('11','1','1','11','1','7','24','0.00','0.00','0.00','1.00','83.00','83.00','0.00','83.00','2025-11-10 23:14:24','2025-11-10 23:14:24','2025-11-10','108');


DROP TABLE IF EXISTS `purchase_return_masters`;
CREATE TABLE `purchase_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `supplier_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_masters` VALUES ('11','1','2025-11-10','7','','0.00','0.00','0.00','83.00','-3358.00','1','2025-11-10 23:14:24','2025-11-10 23:14:24');


DROP TABLE IF EXISTS `purchase_returns`;
CREATE TABLE `purchase_returns` (
  `id` bigint unsigned NOT NULL,
  `vorcher_no` int NOT NULL,
  `width` float NOT NULL,
  `lenght` float NOT NULL,
  `grammage` float NOT NULL,
  `qty` float NOT NULL,
  `rate` float NOT NULL,
  `total_wt` float NOT NULL,
  `amount` float NOT NULL,
  `item_code` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `freight` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `rights`;
CREATE TABLE `rights` (
  `id` int NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `app_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add` tinyint(1) DEFAULT '0',
  `del` tinyint(1) DEFAULT '0',
  `edit` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_invoice_details`;
CREATE TABLE `sale_invoice_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=411 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoice_details` VALUES ('51','1','3','9','21','100.00','200.00','20000.00','12.00','20000.00','240000.00','0.00','260000.00','2025-11-05 02:02:24','2025-11-05 02:02:24','7','11','2025-10-28','120');
INSERT INTO `sale_invoice_details` VALUES ('54','2','3','9','21','0.00','200.00','0.00','10.00','20000.00','200000.00','0.00','200000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','11','2025-11-05','120');
INSERT INTO `sale_invoice_details` VALUES ('57','1','4','14','33','11.00','123.00','1353.00','1.00','12.00','12.00','1.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','13','2025-11-10','12');
INSERT INTO `sale_invoice_details` VALUES ('65','3','3','9','21','0.00','200.00','0.00','1.00','20000.00','20000.00','0.00','20000.00','2025-12-19 16:21:31','2025-12-19 16:21:31','7','11','2025-12-19','120');
INSERT INTO `sale_invoice_details` VALUES ('72','1','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-03 16:53:15','2026-01-03 16:53:15','1','92','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('73','1','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-03 16:53:15','2026-01-03 16:53:15','1','92','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('74','2','6','87','113','0.00','75.00','0.00','5.00','7500.00','37500.00','0.00','37500.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('75','2','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('76','2','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('77','2','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('78','2','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','63','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('79','3','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:52:31','2026-01-04 16:52:31','1','42','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('80','4','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('81','4','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('82','4','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('83','4','1','83','109','0.00','80.00','0.00','3.00','5760.00','17280.00','0.00','17280.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','53','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('84','5','2','40','62','0.00','345.00','0.00','2.00','10350.00','20700.00','10.00','18630.00','2026-01-04 17:02:32','2026-01-04 17:02:32','1','51','2026-01-03','30');
INSERT INTO `sale_invoice_details` VALUES ('85','6','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-03','90');
INSERT INTO `sale_invoice_details` VALUES ('86','6','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('87','6','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','64');
INSERT INTO `sale_invoice_details` VALUES ('88','6','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('89','6','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','10.00','11340.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','55','2026-01-01','180');
INSERT INTO `sale_invoice_details` VALUES ('97','9','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-04 17:29:31','2026-01-04 17:29:31','1','47','2026-01-03','35');
INSERT INTO `sale_invoice_details` VALUES ('98','10','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('99','10','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('100','10','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('101','10','6','86','112','0.00','65.00','0.00','1.00','13000.00','13000.00','0.00','13000.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','200');
INSERT INTO `sale_invoice_details` VALUES ('102','10','2','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('103','10','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('104','10','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('105','10','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','50','2026-01-03','72');
INSERT INTO `sale_invoice_details` VALUES ('106','8','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-03','64');
INSERT INTO `sale_invoice_details` VALUES ('107','8','6','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-03','30');
INSERT INTO `sale_invoice_details` VALUES ('108','8','6','42','64','0.00','470.00','0.00','1.00','16450.00','16450.00','10.00','14805.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-03','35');
INSERT INTO `sale_invoice_details` VALUES ('109','8','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('110','8','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('111','8','2','40','62','0.00','345.00','0.00','1.00','10350.00','10350.00','0.00','10350.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','65','2026-01-04','30');
INSERT INTO `sale_invoice_details` VALUES ('112','11','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:20:53','2026-01-04 20:20:53','1','60','2026-01-03','100');
INSERT INTO `sale_invoice_details` VALUES ('113','12','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','78','2026-01-04','100');
INSERT INTO `sale_invoice_details` VALUES ('114','12','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','78','2026-01-04','99');
INSERT INTO `sale_invoice_details` VALUES ('122','14','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-04 20:55:13','2026-01-04 20:55:13','1','46','2026-01-04','90');
INSERT INTO `sale_invoice_details` VALUES ('123','14','1','13','37','500.00','115.00','57500.00','0.00','13320.00','0.00','0.00','57500.00','2026-01-04 20:55:13','2026-01-04 20:55:13','1','46','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('124','13','6','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-04 20:57:12','2026-01-04 20:57:12','1','45','2026-01-04','40');
INSERT INTO `sale_invoice_details` VALUES ('129','16','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('130','16','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','72');
INSERT INTO `sale_invoice_details` VALUES ('131','16','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-06 19:41:52','2026-01-06 19:41:52','1','109','2026-01-04','108');
INSERT INTO `sale_invoice_details` VALUES ('132','15','6','61','83','0.00','260.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-06 19:58:41','2026-01-06 19:58:41','1','114','2026-01-04','36');
INSERT INTO `sale_invoice_details` VALUES ('137','17','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('138','17','1','82','108','0.00','65.00','0.00','1.00','6500.00','6500.00','0.00','6500.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','100');
INSERT INTO `sale_invoice_details` VALUES ('139','17','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-07 19:00:24','2026-01-07 19:00:24','1','29','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('140','18','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 19:09:15','2026-01-07 19:09:15','1','30','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('141','18','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 19:09:15','2026-01-07 19:09:15','1','30','2026-01-05','30');
INSERT INTO `sale_invoice_details` VALUES ('142','19','1','51','73','0.00','175.00','0.00','1.00','10500.00','10500.00','10.00','9450.00','2026-01-07 19:22:41','2026-01-07 19:22:41','1','100','2026-01-01','60');
INSERT INTO `sale_invoice_details` VALUES ('148','21','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 19:49:07','2026-01-07 19:49:07','1','25','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('149','21','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','10.00','9525.60','2026-01-07 19:49:07','2026-01-07 19:49:07','1','25','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('150','22','1','17','39','0.00','147.00','0.00','1.00','10584.00','10584.00','0.00','10584.00','2026-01-07 19:59:43','2026-01-07 19:59:43','1','17','2026-01-07','72');
INSERT INTO `sale_invoice_details` VALUES ('151','23','2','25','47','0.00','270.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-07 20:03:38','2026-01-07 20:03:38','1','19','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('152','24','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('153','24','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('154','24','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('155','24','1','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-07 21:34:13','2026-01-07 21:34:13','1','18','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('156','25','2','19','41','0.00','238.00','0.00','1.00','9520.00','9520.00','10.00','8568.00','2026-01-07 21:37:45','2026-01-07 21:37:45','1','31','2026-01-01','40');
INSERT INTO `sale_invoice_details` VALUES ('161','26','6','68','90','0.00','83.00','0.00','2.00','15936.00','31872.00','10.00','28684.80','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','192');
INSERT INTO `sale_invoice_details` VALUES ('162','26','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','144');
INSERT INTO `sale_invoice_details` VALUES ('163','26','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','90');
INSERT INTO `sale_invoice_details` VALUES ('164','26','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-07 21:41:45','2026-01-07 21:41:45','1','21','2026-01-01','72');
INSERT INTO `sale_invoice_details` VALUES ('165','27','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 21:47:07','2026-01-07 21:47:07','1','16','2025-12-25','90');
INSERT INTO `sale_invoice_details` VALUES ('166','20','1','61','83','0.00','260.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','36');
INSERT INTO `sale_invoice_details` VALUES ('167','20','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('168','20','1','47','69','0.00','312.00','0.00','1.00','9360.00','9360.00','10.00','8424.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','30');
INSERT INTO `sale_invoice_details` VALUES ('169','20','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','108');
INSERT INTO `sale_invoice_details` VALUES ('170','20','1','11','35','0.00','83.00','0.00','1.00','8964.00','8964.00','10.00','8067.60','2026-01-07 21:53:20','2026-01-07 21:53:20','1','15','2026-01-01','108');
INSERT INTO `sale_invoice_details` VALUES ('171','28','2','21','43','0.00','200.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('172','28','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('173','28','2','25','47','0.00','270.00','0.00','1.00','10800.00','10800.00','10.00','9720.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('174','28','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('175','28','6','66','88','0.00','39.00','0.00','1.00','14040.00','14040.00','10.00','12636.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','360');
INSERT INTO `sale_invoice_details` VALUES ('176','28','2','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('177','28','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','144');
INSERT INTO `sale_invoice_details` VALUES ('178','28','2','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-07 21:59:38','2026-01-07 21:59:38','1','101','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('179','29','2','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-07 22:05:05','2026-01-07 22:05:05','1','96','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('180','30','1','20','42','0.00','135.00','0.00','2.00','5400.00','10800.00','10.00','9720.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('181','30','2','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('182','30','2','28','50','0.00','235.00','0.00','2.00','8225.00','16450.00','10.00','14805.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('183','30','2','34','56','0.00','320.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','30');
INSERT INTO `sale_invoice_details` VALUES ('184','30','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('185','30','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('186','30','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','110','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('187','31','1','47','69','0.00','312.00','0.00','2.00','9360.00','18720.00','10.00','16848.00','2026-01-08 20:30:16','2026-01-08 20:30:16','1','87','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('188','31','1','61','83','50.00','260.00','13000.00','0.00','9360.00','0.00','10.00','11700.00','2026-01-08 20:30:16','2026-01-08 20:30:16','1','87','2026-01-08','36');
INSERT INTO `sale_invoice_details` VALUES ('189','32','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','7.00','25110.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','90');
INSERT INTO `sale_invoice_details` VALUES ('190','32','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','64');
INSERT INTO `sale_invoice_details` VALUES ('191','32','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','7.00','8928.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('192','32','2','23','45','0.00','325.00','0.00','2.00','13000.00','26000.00','7.00','24180.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('193','32','6','94','120','0.00','145.00','0.00','2.00','7250.00','14500.00','0.00','14500.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','50');
INSERT INTO `sale_invoice_details` VALUES ('194','32','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','7.00','8091.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','111','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('195','33','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','134','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('196','33','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','134','2026-01-03','99');
INSERT INTO `sale_invoice_details` VALUES ('206','35','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('207','35','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('208','35','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','60');
INSERT INTO `sale_invoice_details` VALUES ('209','35','6','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('210','35','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('211','35','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','64');
INSERT INTO `sale_invoice_details` VALUES ('212','35','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('213','35','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','72','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('214','36','1','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('215','36','6','24','42','0.00','175.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('216','36','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','44','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('217','37','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('218','37','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('219','37','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('220','37','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','51','2026-01-10','100');
INSERT INTO `sale_invoice_details` VALUES ('221','38','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','90');
INSERT INTO `sale_invoice_details` VALUES ('222','38','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('223','38','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('224','38','2','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('225','38','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-11 21:31:39','2026-01-11 21:31:39','1','134','2026-01-05','192');
INSERT INTO `sale_invoice_details` VALUES ('235','39','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('236','39','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('237','39','1','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','90');
INSERT INTO `sale_invoice_details` VALUES ('238','39','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','72');
INSERT INTO `sale_invoice_details` VALUES ('239','39','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-05','64');
INSERT INTO `sale_invoice_details` VALUES ('240','39','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-06','192');
INSERT INTO `sale_invoice_details` VALUES ('241','39','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('242','39','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','90');
INSERT INTO `sale_invoice_details` VALUES ('243','39','6','79','105','0.00','150.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','64');
INSERT INTO `sale_invoice_details` VALUES ('244','39','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','53','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('262','41','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 22:21:51','2026-01-11 22:21:51','1','68','2026-01-05','40');
INSERT INTO `sale_invoice_details` VALUES ('263','42','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-05','99');
INSERT INTO `sale_invoice_details` VALUES ('264','42','6','90','116','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('265','42','1','83','109','0.00','80.00','0.00','2.00','5760.00','11520.00','0.00','11520.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','72');
INSERT INTO `sale_invoice_details` VALUES ('266','42','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','100');
INSERT INTO `sale_invoice_details` VALUES ('267','42','6','88','114','0.00','85.00','0.00','1.00','8415.00','8415.00','0.00','8415.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','50','2026-01-09','99');
INSERT INTO `sale_invoice_details` VALUES ('268','43','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','57','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('269','43','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','57','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('276','45','2','42','64','0.00','470.00','0.00','1.00','16450.00','16450.00','10.00','14805.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('277','45','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('278','45','2','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('279','45','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('280','45','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('281','45','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('282','45','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('283','45','6','64','86','0.00','500.00','0.00','2.00','18000.00','36000.00','10.00','32400.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','36');
INSERT INTO `sale_invoice_details` VALUES ('284','45','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','90');
INSERT INTO `sale_invoice_details` VALUES ('285','45','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('286','45','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('287','45','2','29','51','0.00','255.00','0.00','1.00','8925.00','8925.00','10.00','8032.50','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('288','45','1','11','35','0.00','83.00','0.00','1.00','8964.00','8964.00','10.00','8067.60','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','108');
INSERT INTO `sale_invoice_details` VALUES ('289','45','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 22:51:27','2026-01-11 22:51:27','1','65','2026-01-10','100');
INSERT INTO `sale_invoice_details` VALUES ('290','46','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 22:55:45','2026-01-11 22:55:45','1','67','2026-01-06','99');
INSERT INTO `sale_invoice_details` VALUES ('291','44','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('292','44','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('293','44','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('294','44','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('295','44','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('296','44','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','63','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('297','47','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('298','47','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('299','47','6','88','114','0.00','85.00','0.00','2.00','8415.00','16830.00','0.00','16830.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','47','2026-01-11','99');
INSERT INTO `sale_invoice_details` VALUES ('300','48','6','80','106','0.00','150.00','0.00','2.00','13500.00','27000.00','10.00','24300.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','77','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('301','48','2','59','123','0.00','165.00','0.00','1.00','14850.00','14850.00','10.00','13365.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','77','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('315','50','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('316','50','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('317','50','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-11 23:23:47','2026-01-11 23:23:47','1','82','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('318','51','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-11 23:30:31','2026-01-11 23:30:31','1','70','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('319','52','6','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','136','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('320','52','2','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','136','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('322','54','1','83','109','0.00','80.00','0.00','1.00','5760.00','5760.00','0.00','5760.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('323','54','1','83','109','0.00','80.00','0.00','3.00','5760.00','17280.00','0.00','17280.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('324','54','1','94','120','0.00','160.00','0.00','5.00','8000.00','40000.00','10.00','36000.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','50');
INSERT INTO `sale_invoice_details` VALUES ('325','54','1','24','46','0.00','175.00','0.00','5.00','7000.00','35000.00','10.00','31500.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('326','54','6','63','85','0.00','140.00','0.00','2.00','16800.00','33600.00','10.00','30240.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','120');
INSERT INTO `sale_invoice_details` VALUES ('327','54','6','81','107','0.00','145.00','0.00','3.00','8700.00','26100.00','10.00','23490.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','60');
INSERT INTO `sale_invoice_details` VALUES ('328','54','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','59','2026-01-10','90');
INSERT INTO `sale_invoice_details` VALUES ('329','55','2','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('330','55','6','27','49','0.00','410.00','0.00','1.00','14350.00','14350.00','10.00','12915.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('331','55','2','39','61','0.00','560.00','0.00','1.00','16800.00','16800.00','10.00','15120.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','30');
INSERT INTO `sale_invoice_details` VALUES ('332','55','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','72');
INSERT INTO `sale_invoice_details` VALUES ('333','55','1','62','84','0.00','175.00','0.00','1.00','17500.00','17500.00','10.00','15750.00','2026-01-11 23:45:14','2026-01-11 23:45:14','1','83','2026-01-07','100');
INSERT INTO `sale_invoice_details` VALUES ('340','57','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-11 23:54:27','2026-01-11 23:54:27','1','78','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('345','59','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','108');
INSERT INTO `sale_invoice_details` VALUES ('346','59','1','13','37','0.00','185.00','0.00','1.00','13320.00','13320.00','10.00','11988.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('347','59','1','46','68','0.00','510.00','0.00','1.00','15300.00','15300.00','10.00','13770.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-08','30');
INSERT INTO `sale_invoice_details` VALUES ('348','59','6','90','116','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','12','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('349','60','1','16','38','0.00','99.00','0.00','1.00','7128.00','7128.00','10.00','6415.20','2026-01-12 00:03:06','2026-01-12 00:03:06','1','48','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('351','61','6','81','107','0.00','145.00','0.00','2.00','8700.00','17400.00','10.00','15660.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('352','61','6','79','105','0.00','150.00','0.00','2.00','9600.00','19200.00','10.00','17280.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','64');
INSERT INTO `sale_invoice_details` VALUES ('353','61','6','89','115','0.00','160.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','60');
INSERT INTO `sale_invoice_details` VALUES ('354','61','6','80','106','0.00','150.00','0.00','3.00','13500.00','40500.00','0.00','40500.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','52','2026-01-08','90');
INSERT INTO `sale_invoice_details` VALUES ('355','62','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('356','62','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('357','62','2','43','65','0.00','280.00','0.00','1.00','9800.00','9800.00','10.00','8820.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','35');
INSERT INTO `sale_invoice_details` VALUES ('358','62','2','20','42','0.00','135.00','0.00','1.00','5400.00','5400.00','10.00','4860.00','2026-01-12 00:09:16','2026-01-12 00:09:16','1','45','2026-01-10','40');
INSERT INTO `sale_invoice_details` VALUES ('359','63','6','64','86','0.00','500.00','0.00','2.00','18000.00','36000.00','10.00','32400.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('360','63','1','79','105','0.00','150.00','0.00','3.00','9600.00','28800.00','10.00','25920.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('361','63','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','90');
INSERT INTO `sale_invoice_details` VALUES ('362','63','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','42','2026-01-11','60');
INSERT INTO `sale_invoice_details` VALUES ('363','64','6','87','113','0.00','75.00','0.00','3.00','7500.00','22500.00','0.00','22500.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('364','64','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('365','64','2','65','87','0.00','300.00','0.00','3.00','10800.00','32400.00','10.00','29160.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('366','64','6','64','86','0.00','500.00','0.00','1.00','18000.00','18000.00','10.00','16200.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','36');
INSERT INTO `sale_invoice_details` VALUES ('367','64','6','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','135','2026-01-11','70');
INSERT INTO `sale_invoice_details` VALUES ('368','65','6','81','107','0.00','115.00','0.00','5.00','6900.00','34500.00','0.00','34500.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('369','65','1','80','106','0.00','120.00','0.00','3.00','10800.00','32400.00','0.00','32400.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('370','65','6','79','105','0.00','120.00','0.00','5.00','7680.00','38400.00','0.00','38400.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','69','2026-01-11','64');
INSERT INTO `sale_invoice_details` VALUES ('371','40','2','95','121','0.00','65.00','0.00','2.00','11700.00','23400.00','0.00','23400.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','180');
INSERT INTO `sale_invoice_details` VALUES ('372','40','1','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','70');
INSERT INTO `sale_invoice_details` VALUES ('373','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','72');
INSERT INTO `sale_invoice_details` VALUES ('374','40','6','87','113','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-05','100');
INSERT INTO `sale_invoice_details` VALUES ('375','40','6','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('376','40','2','77','103','0.00','220.00','0.00','1.00','14080.00','14080.00','10.00','12672.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('377','40','2','76','102','0.00','220.00','0.00','1.00','13200.00','13200.00','10.00','11880.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','60');
INSERT INTO `sale_invoice_details` VALUES ('378','40','2','96','122','0.00','75.00','0.00','1.00','5250.00','5250.00','0.00','5250.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','70');
INSERT INTO `sale_invoice_details` VALUES ('379','40','6','90','116','0.00','75.00','0.00','2.00','7500.00','15000.00','0.00','15000.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('380','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-07','72');
INSERT INTO `sale_invoice_details` VALUES ('381','40','1','83','109','0.00','80.00','0.00','5.00','5760.00','28800.00','0.00','28800.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('382','40','1','96','122','0.00','75.00','0.00','2.00','5250.00','10500.00','0.00','10500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-08','70');
INSERT INTO `sale_invoice_details` VALUES ('383','40','1','83','109','0.00','80.00','0.00','10.00','5760.00','57600.00','0.00','57600.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','72');
INSERT INTO `sale_invoice_details` VALUES ('384','40','6','94','120','0.00','160.00','0.00','1.00','8000.00','8000.00','10.00','7200.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','50');
INSERT INTO `sale_invoice_details` VALUES ('385','40','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','100');
INSERT INTO `sale_invoice_details` VALUES ('386','40','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','192');
INSERT INTO `sale_invoice_details` VALUES ('387','40','6','69','91','0.00','116.00','0.00','1.00','16704.00','16704.00','10.00','15033.60','2026-01-12 11:27:12','2026-01-12 11:27:12','1','60','2026-01-11','144');
INSERT INTO `sale_invoice_details` VALUES ('388','49','6','80','106','0.00','150.00','0.00','1.00','13500.00','13500.00','10.00','12150.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('389','49','6','70','92','0.00','158.00','0.00','1.00','14220.00','14220.00','10.00','12798.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','90');
INSERT INTO `sale_invoice_details` VALUES ('390','49','6','71','93','0.00','237.00','0.00','1.00','17064.00','17064.00','10.00','15357.60','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','72');
INSERT INTO `sale_invoice_details` VALUES ('391','49','6','68','90','0.00','83.00','0.00','1.00','15936.00','15936.00','10.00','14342.40','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','192');
INSERT INTO `sale_invoice_details` VALUES ('392','49','6','67','89','0.00','59.00','0.00','1.00','17700.00','17700.00','10.00','15930.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','300');
INSERT INTO `sale_invoice_details` VALUES ('393','49','1','91','117','0.00','70.00','0.00','1.00','12600.00','12600.00','0.00','12600.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('394','49','6','95','121','0.00','65.00','0.00','1.00','11700.00','11700.00','0.00','11700.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','180');
INSERT INTO `sale_invoice_details` VALUES ('395','49','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','64');
INSERT INTO `sale_invoice_details` VALUES ('396','49','6','87','113','0.00','75.00','0.00','1.00','7500.00','7500.00','0.00','7500.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','100');
INSERT INTO `sale_invoice_details` VALUES ('397','49','6','23','45','0.00','325.00','0.00','1.00','13000.00','13000.00','10.00','11700.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','40');
INSERT INTO `sale_invoice_details` VALUES ('398','49','6','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','35');
INSERT INTO `sale_invoice_details` VALUES ('399','49','1','10','26','0.00','115.00','0.00','1.00','12420.00','12420.00','10.00','11178.00','2026-01-12 11:28:09','2026-01-12 11:28:09','1','76','2026-01-06','108');
INSERT INTO `sale_invoice_details` VALUES ('400','56','6','94','120','0.00','160.00','0.00','2.00','8000.00','16000.00','10.00','14400.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','50');
INSERT INTO `sale_invoice_details` VALUES ('401','56','2','28','50','0.00','235.00','0.00','1.00','8225.00','8225.00','10.00','7402.50','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','35');
INSERT INTO `sale_invoice_details` VALUES ('402','56','2','24','46','0.00','175.00','0.00','1.00','7000.00','7000.00','10.00','6300.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-07','40');
INSERT INTO `sale_invoice_details` VALUES ('403','56','6','89','115','0.00','160.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-09','60');
INSERT INTO `sale_invoice_details` VALUES ('404','56','2','28','50','0.00','235.00','0.00','2.00','8225.00','16450.00','10.00','14805.00','2026-01-12 11:28:59','2026-01-12 11:28:59','1','46','2026-01-09','35');
INSERT INTO `sale_invoice_details` VALUES ('405','58','1','71','93','0.00','237.00','0.00','3.00','17064.00','51192.00','10.00','46072.80','2026-01-12 11:29:24','2026-01-12 11:29:24','1','58','2026-01-08','72');
INSERT INTO `sale_invoice_details` VALUES ('406','58','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 11:29:24','2026-01-12 11:29:24','1','58','2026-01-10','64');
INSERT INTO `sale_invoice_details` VALUES ('407','66','6','81','107','0.00','145.00','0.00','1.00','8700.00','8700.00','10.00','7830.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','139','2026-01-12','60');
INSERT INTO `sale_invoice_details` VALUES ('408','66','6','79','105','0.00','150.00','0.00','1.00','9600.00','9600.00','10.00','8640.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','139','2026-01-12','64');
INSERT INTO `sale_invoice_details` VALUES ('409','67','6','24','46','0.00','175.00','0.00','3.00','7000.00','21000.00','10.00','18900.00','2026-01-12 20:21:18','2026-01-12 20:21:18','1','130','2026-01-12','40');
INSERT INTO `sale_invoice_details` VALUES ('410','67','1','16','38','0.00','99.00','0.00','2.00','7128.00','14256.00','10.00','12830.40','2026-01-12 20:21:18','2026-01-12 20:21:18','1','130','2026-01-12','72');


DROP TABLE IF EXISTS `sale_invoices_masters`;
CREATE TABLE `sale_invoices_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) DEFAULT NULL,
  `grand_crt_total` decimal(16,2) DEFAULT NULL,
  `grand_discount` decimal(16,2) DEFAULT NULL,
  `grand_total` decimal(16,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_balance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_amount` decimal(16,2) DEFAULT NULL,
  `received_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_invoices_masters` VALUES ('26','1','2025-10-28','11','','','','0.00','260000.00','2025-10-28 19:43:09','2025-11-05 02:02:24','7','0','1000','','');
INSERT INTO `sale_invoices_masters` VALUES ('33','2','2025-11-05','11','','','','0.00','202000.00','2025-11-05 03:00:46','2025-11-05 03:00:46','7','261000','2000','','');
INSERT INTO `sale_invoices_masters` VALUES ('36','1','2025-11-10','13','red','','','0.00','1351.35','2025-11-10 21:58:15','2025-11-10 21:58:15','8','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('41','3','2025-12-19','11','','','','','20000.00','2025-12-19 16:21:31','2025-12-19 16:21:31','7','463000','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('46','1','2026-01-03','92','','','','','19130.40','2026-01-03 16:53:15','2026-01-03 16:53:15','1','22106','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('47','2','2026-01-04','63','','','','','74760.00','2026-01-04 16:47:08','2026-01-04 16:47:08','1','114304','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('48','3','2026-01-04','42','','','','','7830.00','2026-01-04 16:52:31','2026-01-04 16:52:31','1','459343','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('49','4','2026-01-04','53','','','','','45900.00','2026-01-04 16:58:51','2026-01-04 16:58:51','1','605118','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('50','5','2026-01-04','51','','','','','18630.00','2026-01-04 17:02:32','2026-01-04 17:02:32','1','197168','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('51','6','2026-01-04','55','','','','','48600.00','2026-01-04 17:07:51','2026-01-04 17:07:51','1','85143','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('54','9','2026-01-04','47','','','','','12915.00','2026-01-04 17:29:31','2026-01-04 17:29:31','1','332903','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('55','10','2026-01-04','50','','','','','83785.00','2026-01-04 20:10:46','2026-01-04 20:10:46','1','156022','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('56','8','2026-01-04','65','','','','0.00','64830.00','2026-01-04 20:14:57','2026-01-04 20:14:57','1','110752','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('57','11','2026-01-04','60','','','','','7500.00','2026-01-04 20:20:53','2026-01-04 20:20:53','1','1072290','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('58','12','2026-01-04','78','','','','','15915.00','2026-01-04 20:27:16','2026-01-04 20:27:16','1','88668','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('63','14','2026-01-04','46','','','','0.38','69380.20','2026-01-04 20:55:13','2026-01-04 20:55:13','1','689487','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('64','13','2026-01-04','45','','','','0.00','6300.00','2026-01-04 20:57:12','2026-01-04 20:57:12','1','347332','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('68','16','2026-01-06','109','','','','2.00','32037.77','2026-01-06 19:41:52','2026-01-06 19:41:52','1','5612','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('69','15','2026-01-06','114','','','','0.00','16848.00','2026-01-06 19:58:41','2026-01-06 19:58:41','1','39600','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('72','17','2026-01-07','29','','','','2.00','19364.80','2026-01-07 19:00:24','2026-01-07 19:00:24','1','128670','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('73','18','2026-01-07','30','','','','2.00','16511.04','2026-01-07 19:09:15','2026-01-07 19:09:15','1','55','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('74','19','2026-01-01','100','','','','2.00','9261.00','2026-01-07 19:22:41','2026-01-07 19:22:41','1','71213','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('76','21','2026-01-07','25','','','','2.00','21242.09','2026-01-07 19:49:07','2026-01-07 19:49:07','1','110515','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('77','22','2026-01-07','17','','','','2.00','10372.32','2026-01-07 19:59:43','2026-01-07 19:59:43','1','144862','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('78','23','2026-01-07','19','','','','','9720.00','2026-01-07 20:03:38','2026-01-07 20:03:38','1','140979','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('79','24','2026-01-07','18','','','','','48423.60','2026-01-07 21:34:13','2026-01-07 21:34:13','1','154701','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('80','25','2026-01-01','31','','','','','8568.00','2026-01-07 21:37:45','2026-01-07 21:37:45','1','287647','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('82','26','2026-01-07','21','','','','2.00','70436.52','2026-01-07 21:41:45','2026-01-07 21:41:45','1','1453069','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('83','27','2026-01-07','16','','','','2.00','11907.00','2026-01-07 21:47:07','2026-01-07 21:47:07','1','31471','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('84','20','2026-01-07','15','','','','2.00','48866.33','2026-01-07 21:53:20','2026-01-07 21:53:20','1','469253','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('85','28','2026-01-07','101','','','','2.00','90681.95','2026-01-07 21:59:38','2026-01-07 21:59:38','1','141050','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('86','29','2026-01-06','96','','','','2.00','30870.00','2026-01-07 22:05:05','2026-01-07 22:05:05','1','139963','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('87','30','2026-01-07','110','','','','','111375.00','2026-01-07 22:09:34','2026-01-07 22:09:34','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('88','31','2026-01-08','87','','','','','28548.00','2026-01-08 20:30:16','2026-01-08 20:30:16','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('89','32','2026-01-10','111','','','','','89737.00','2026-01-10 17:09:46','2026-01-10 17:09:46','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('90','33','2026-01-03','134','','','','','15915.00','2026-01-11 18:59:02','2026-01-11 18:59:02','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('93','35','2026-01-11','72','','','','0.00','92475.00','2026-01-11 21:14:32','2026-01-11 21:14:32','1','137363','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('94','36','2026-01-11','44','','','','','21420.00','2026-01-11 21:22:25','2026-01-11 21:22:25','1','172654','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('95','37','2026-01-11','51','','','','','40500.00','2026-01-11 21:27:23','2026-01-11 21:27:23','1','175798','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('96','38','2026-01-11','134','','','','','58292.40','2026-01-11 21:31:39','2026-01-11 21:31:39','1','28638','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('98','39','2026-01-11','53','','','','0.00','165618.00','2026-01-11 21:42:12','2026-01-11 21:42:12','1','651018','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('100','41','2026-01-11','68','','','','','6300.00','2026-01-11 22:21:51','2026-01-11 22:21:51','1','90181','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('101','42','2026-01-11','50','','','','','66765.00','2026-01-11 22:31:11','2026-01-11 22:31:11','1','189807','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('102','43','2026-01-11','57','','','','','24300.00','2026-01-11 22:35:04','2026-01-11 22:35:04','1','41461','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('105','45','2026-01-11','65','','','','','157685.10','2026-01-11 22:51:27','2026-01-11 22:51:27','1','125582','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('106','46','2026-01-11','67','','','','','16830.00','2026-01-11 22:55:45','2026-01-11 22:55:45','1','39575','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('107','44','2026-01-11','63','','','','0.00','78210.00','2026-01-11 22:57:34','2026-01-11 22:57:34','1','129064','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('108','47','2026-01-11','47','','','','','43530.00','2026-01-11 23:01:38','2026-01-11 23:01:38','1','285818','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('109','48','2026-01-11','77','','','','','37665.00','2026-01-11 23:10:39','2026-01-11 23:10:39','1','33566','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('111','50','2026-01-11','82','','','','','40305.60','2026-01-11 23:23:47','2026-01-11 23:23:47','1','172039','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('112','51','2026-01-11','70','','','','','7500.00','2026-01-11 23:30:31','2026-01-11 23:30:31','1','43020','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('113','52','2026-01-11','136','','','','','24300.00','2026-01-11 23:32:31','2026-01-11 23:32:31','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('115','54','2026-01-11','59','','','','','157068.00','2026-01-11 23:41:33','2026-01-11 23:41:33','1','778626','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('116','55','2026-01-11','83','','','','','70842.60','2026-01-11 23:45:14','2026-01-11 23:45:14','1','176957','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('119','57','2026-01-11','78','','','','','17280.00','2026-01-11 23:54:27','2026-01-11 23:54:27','1','104583','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('123','59','2026-01-11','12','','','','0.00','44436.00','2026-01-12 00:00:40','2026-01-12 00:00:40','1','607451','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('124','60','2026-01-12','48','','','','','6415.20','2026-01-12 00:03:06','2026-01-12 00:03:06','1','82662','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('126','61','2026-01-12','52','','','','0.00','99360.00','2026-01-12 00:05:58','2026-01-12 00:05:58','1','67307','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('127','62','2026-01-12','45','Alam Chowk','','','','27382.50','2026-01-12 00:09:16','2026-01-12 00:09:16','1','313632','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('128','63','2026-01-12','42','','','','','78300.00','2026-01-12 00:12:34','2026-01-12 00:12:34','1','417173','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('129','64','2026-01-12','135','','','','','87000.00','2026-01-12 00:16:04','2026-01-12 00:16:04','1','46303','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('130','65','2026-01-11','69','','','','','105300.00','2026-01-12 00:25:02','2026-01-12 00:25:02','1','204100','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('131','40','2026-01-11','60','','','','0.00','308208.00','2026-01-12 11:27:12','2026-01-12 11:27:12','1','779790','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('132','49','2026-01-06','76','','','','0.00','141298.50','2026-01-12 11:28:09','2026-01-12 11:28:09','1','467418','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('133','56','2026-01-11','46','','','','2.00','50516.55','2026-01-12 11:28:59','2026-01-12 11:28:59','1','658867.2','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('134','58','2026-01-11','58','','','','0.00','54712.80','2026-01-12 11:29:24','2026-01-12 11:29:24','1','527697','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('135','66','2026-01-12','139','','','','','16470.00','2026-01-12 18:41:05','2026-01-12 18:41:05','1','0','0','','');
INSERT INTO `sale_invoices_masters` VALUES ('136','67','2026-01-12','130','','','','','31730.40','2026-01-12 20:21:18','2026-01-12 20:21:18','1','0','0','','');


DROP TABLE IF EXISTS `sale_return_details`;
CREATE TABLE `sale_return_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_invoice_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_return_masters`;
CREATE TABLE `sale_return_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `grand_pcs_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_crt_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `previous_balance` decimal(16,2) NOT NULL DEFAULT '0.00',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_return_invoice_invoice_no_unique` (`invoice_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `sale_type`;
CREATE TABLE `sale_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_type` VALUES ('1','Taxable','2','2025-09-17 18:40:38','2025-09-17 18:40:38');
INSERT INTO `sale_type` VALUES ('3','Taxable','1','2025-09-22 10:34:37','2025-09-22 10:34:37');
INSERT INTO `sale_type` VALUES ('5','Exempt','1','2025-09-23 17:24:32','2025-09-23 17:24:32');
INSERT INTO `sale_type` VALUES ('7','Exempt','7','2025-10-15 10:20:19','2025-10-15 10:20:19');


DROP TABLE IF EXISTS `stock_adj_details`;
CREATE TABLE `stock_adj_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adj_details` VALUES ('2','1','7','-100','100','0','7','2025-10-17 21:12:41','2025-10-17 21:12:41');
INSERT INTO `stock_adj_details` VALUES ('3','2','7','-20','100','0','7','2025-10-17 21:13:05','2025-10-17 21:13:05');


DROP TABLE IF EXISTS `stock_adj_masters`;
CREATE TABLE `stock_adj_masters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_no` bigint unsigned NOT NULL,
  `v_date` date NOT NULL,
  `prepared_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `stock_adjustment`;
CREATE TABLE `stock_adjustment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cid` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `packing_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `stock_date` date DEFAULT NULL,
  `qty_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `qty_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_crt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `rate_pcs` decimal(16,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `p_qty` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_adjustment` VALUES ('5','7','9','22','3','2025-10-27','-1.00','100.00','50000.00','100.00','-40000.00','','2025-10-27 19:25:13','2025-10-27 19:25:13','250');


DROP TABLE IF EXISTS `stock_qty`;
;

INSERT INTO `stock_qty` VALUES ('51','1','2025-10-28','9','0','0','0','1540','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('54','2','2025-11-05','9','0','0','0','1200','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('57','1','2025-11-10','14','0','0','0','23','0','0','12','4','8','SALE');
INSERT INTO `stock_qty` VALUES ('65','3','2025-12-19','9','0','0','0','120','0','0','120','3','7','SALE');
INSERT INTO `stock_qty` VALUES ('72','1','2026-01-01','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('73','1','2026-01-01','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('74','2','2026-01-01','87','0','0','0','500','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('75','2','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('76','2','2026-01-01','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('77','2','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('78','2','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('79','3','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('80','4','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('81','4','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('82','4','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('83','4','2026-01-03','83','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('84','5','2026-01-03','40','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('85','6','2026-01-03','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('86','6','2026-01-01','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('87','6','2026-01-01','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('88','6','2026-01-01','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('89','6','2026-01-01','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('97','9','2026-01-03','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('98','10','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('99','10','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('100','10','2026-01-03','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('101','10','2026-01-03','86','0','0','0','200','0','0','200','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('102','10','2026-01-03','83','0','0','0','144','0','0','72','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('103','10','2026-01-03','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('104','10','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('105','10','2026-01-03','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('106','8','2026-01-03','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('107','8','2026-01-03','39','0','0','0','30','0','0','30','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('108','8','2026-01-03','42','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('109','8','2026-01-03','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('110','8','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('111','8','2026-01-04','40','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('112','11','2026-01-03','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('113','12','2026-01-04','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('114','12','2026-01-04','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('122','14','2026-01-04','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('123','14','2026-01-04','13','0','0','0','500','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('124','13','2026-01-04','24','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('129','16','2026-01-04','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('130','16','2026-01-04','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('131','16','2026-01-04','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('132','15','2026-01-04','61','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('137','17','2026-01-01','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('138','17','2026-01-01','82','0','0','0','100','0','0','100','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('139','17','2026-01-01','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('140','18','2026-01-01','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('141','18','2026-01-05','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('142','19','2026-01-01','51','0','0','0','60','0','0','60','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('148','21','2026-01-01','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('149','21','2026-01-01','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('150','22','2026-01-07','17','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('151','23','2026-01-01','25','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('152','24','2026-01-07','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('153','24','2026-01-01','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('154','24','2026-01-01','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('155','24','2026-01-01','19','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('156','25','2026-01-01','19','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('161','26','2026-01-01','68','0','0','0','384','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('162','26','2026-01-01','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('163','26','2026-01-01','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('164','26','2026-01-01','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('165','27','2025-12-25','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('166','20','2026-01-01','61','0','0','0','36','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('167','20','2026-01-01','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('168','20','2026-01-01','47','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('169','20','2026-01-01','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('170','20','2026-01-01','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('171','28','2026-01-06','21','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('172','28','2026-01-06','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('173','28','2026-01-06','25','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('174','28','2026-01-06','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('175','28','2026-01-06','66','0','0','0','360','0','0','360','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('176','28','2026-01-06','67','0','0','0','300','0','0','300','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('177','28','2026-01-06','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('178','28','2026-01-06','70','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('179','29','2026-01-06','24','0','0','0','200','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('180','30','2026-01-06','20','0','0','0','80','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('181','30','2026-01-06','24','0','0','0','200','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('182','30','2026-01-06','28','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('183','30','2026-01-06','34','0','0','0','60','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('184','30','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('185','30','2026-01-06','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('186','30','2026-01-06','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('187','31','2026-01-08','47','0','0','0','60','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('188','31','2026-01-08','61','0','0','0','50','0','0','36','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('189','32','2026-01-10','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('190','32','2026-01-10','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('191','32','2026-01-10','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('192','32','2026-01-10','23','0','0','0','80','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('193','32','2026-01-10','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('194','32','2026-01-10','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('195','33','2026-01-11','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('196','33','2026-01-03','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('206','35','2026-01-05','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('207','35','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('208','35','2026-01-05','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('209','35','2026-01-05','62','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('210','35','2026-01-05','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('211','35','2026-01-05','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('212','35','2026-01-11','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('213','35','2026-01-05','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('214','36','2026-01-05','20','0','0','0','40','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('215','36','2026-01-05','24','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('216','36','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('217','37','2026-01-05','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('218','37','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('219','37','2026-01-10','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('220','37','2026-01-10','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('221','38','2026-01-05','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('222','38','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('223','38','2026-01-05','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('224','38','2026-01-05','91','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('225','38','2026-01-05','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('235','39','2026-01-05','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('236','39','2026-01-05','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('237','39','2026-01-05','70','0','0','0','90','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('238','39','2026-01-05','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('239','39','2026-01-05','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('240','39','2026-01-06','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('241','39','2026-01-07','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('242','39','2026-01-08','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('243','39','2026-01-08','79','0','0','0','192','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('244','39','2026-01-08','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('262','41','2026-01-05','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('263','42','2026-01-05','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('264','42','2026-01-05','90','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('265','42','2026-01-09','83','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('266','42','2026-01-09','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('267','42','2026-01-09','88','0','0','0','99','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('268','43','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('269','43','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('276','45','2026-01-06','42','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('277','45','2026-01-06','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('278','45','2026-01-06','27','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('279','45','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('280','45','2026-01-07','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('281','45','2026-01-07','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('282','45','2026-01-07','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('283','45','2026-01-07','64','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('284','45','2026-01-07','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('285','45','2026-01-07','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('286','45','2026-01-10','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('287','45','2026-01-10','29','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('288','45','2026-01-10','11','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('289','45','2026-01-10','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('290','46','2026-01-06','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('291','44','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('292','44','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('293','44','2026-01-06','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('294','44','2026-01-11','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('295','44','2026-01-11','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('296','44','2026-01-11','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('297','47','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('298','47','2026-01-11','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('299','47','2026-01-11','88','0','0','0','198','0','0','99','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('300','48','2026-01-06','80','0','0','0','180','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('301','48','2026-01-06','59','0','0','0','90','0','0','90','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('315','50','2026-01-06','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('316','50','2026-01-06','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('317','50','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('318','51','2026-01-06','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('319','52','2026-01-06','91','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('320','52','2026-01-06','95','0','0','0','180','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('322','54','2026-01-06','83','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('323','54','2026-01-08','83','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('324','54','2026-01-10','94','0','0','0','250','0','0','50','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('325','54','2026-01-10','24','0','0','0','200','0','0','40','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('326','54','2026-01-10','63','0','0','0','240','0','0','120','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('327','54','2026-01-10','81','0','0','0','180','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('328','54','2026-01-10','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('329','55','2026-01-07','23','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('330','55','2026-01-07','27','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('331','55','2026-01-07','39','0','0','0','30','0','0','30','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('332','55','2026-01-07','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('333','55','2026-01-07','62','0','0','0','100','0','0','100','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('340','57','2026-01-06','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('345','59','2026-01-08','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('346','59','2026-01-08','13','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('347','59','2026-01-08','46','0','0','0','30','0','0','30','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('348','59','2026-01-11','90','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('349','60','2026-01-08','16','0','0','0','72','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('351','61','2026-01-08','81','0','0','0','120','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('352','61','2026-01-08','79','0','0','0','128','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('353','61','2026-01-08','89','0','0','0','180','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('354','61','2026-01-08','80','0','0','0','270','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('355','62','2026-01-10','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('356','62','2026-01-10','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('357','62','2026-01-10','43','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('358','62','2026-01-10','20','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('359','63','2026-01-11','64','0','0','0','72','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('360','63','2026-01-11','79','0','0','0','192','0','0','64','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('361','63','2026-01-11','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('362','63','2026-01-11','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('363','64','2026-01-11','87','0','0','0','300','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('364','64','2026-01-11','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('365','64','2026-01-11','65','0','0','0','108','0','0','36','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('366','64','2026-01-11','64','0','0','0','36','0','0','36','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('367','64','2026-01-11','96','0','0','0','140','0','0','70','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('368','65','2026-01-06','81','0','0','0','300','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('369','65','2026-01-06','80','0','0','0','270','0','0','90','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('370','65','2026-01-11','79','0','0','0','320','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('371','40','2026-01-05','95','0','0','0','360','0','0','180','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('372','40','2026-01-05','96','0','0','0','140','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('373','40','2026-01-05','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('374','40','2026-01-05','87','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('375','40','2026-01-06','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('376','40','2026-01-06','77','0','0','0','64','0','0','64','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('377','40','2026-01-06','76','0','0','0','60','0','0','60','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('378','40','2026-01-06','96','0','0','0','70','0','0','70','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('379','40','2026-01-06','90','0','0','0','200','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('380','40','2026-01-07','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('381','40','2026-01-08','83','0','0','0','360','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('382','40','2026-01-08','96','0','0','0','140','0','0','70','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('383','40','2026-01-11','83','0','0','0','720','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('384','40','2026-01-11','94','0','0','0','50','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('385','40','2026-01-11','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('386','40','2026-01-11','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('387','40','2026-01-11','69','0','0','0','144','0','0','144','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('388','49','2026-01-06','80','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('389','49','2026-01-06','70','0','0','0','90','0','0','90','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('390','49','2026-01-06','71','0','0','0','72','0','0','72','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('391','49','2026-01-06','68','0','0','0','192','0','0','192','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('392','49','2026-01-06','67','0','0','0','300','0','0','300','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('393','49','2026-01-06','91','0','0','0','180','0','0','180','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('394','49','2026-01-06','95','0','0','0','180','0','0','180','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('395','49','2026-01-06','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('396','49','2026-01-06','87','0','0','0','100','0','0','100','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('397','49','2026-01-06','23','0','0','0','40','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('398','49','2026-01-06','28','0','0','0','35','0','0','35','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('399','49','2026-01-06','10','0','0','0','108','0','0','108','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('400','56','2026-01-07','94','0','0','0','100','0','0','50','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('401','56','2026-01-07','28','0','0','0','35','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('402','56','2026-01-07','24','0','0','0','40','0','0','40','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('403','56','2026-01-09','89','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('404','56','2026-01-09','28','0','0','0','70','0','0','35','2','1','SALE');
INSERT INTO `stock_qty` VALUES ('405','58','2026-01-08','71','0','0','0','216','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('406','58','2026-01-10','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('407','66','2026-01-12','81','0','0','0','60','0','0','60','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('408','66','2026-01-12','79','0','0','0','64','0','0','64','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('409','67','2026-01-12','24','0','0','0','120','0','0','40','6','1','SALE');
INSERT INTO `stock_qty` VALUES ('410','67','2026-01-12','16','0','0','0','144','0','0','72','1','1','SALE');
INSERT INTO `stock_qty` VALUES ('11','1','2025-11-10','11','0','0','108','0','0','0','108','1','1','PURCHASE_RETURN');
INSERT INTO `stock_qty` VALUES ('2','1','2025-10-27','9','250','0','0','0','0','0','250','3','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('4','1','2025-12-19','72','1206','0','0','0','0','0','12','7','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('5','1','2025-12-19','72','202','0','0','0','0','0','4','7','7','OPENING_STOCK');
INSERT INTO `stock_qty` VALUES ('5','5','2025-10-27','9','0','0','0','0','0','-150','250','3','7','STOCK_ADJUSTMENT');


DROP TABLE IF EXISTS `store`;
CREATE TABLE `store` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store` VALUES ('1','Unit 1(1st Floor)','1','2025-10-21 20:22:12','2025-10-25 18:53:26');
INSERT INTO `store` VALUES ('2','Unit 1(2nd Floor)','1','2025-10-25 18:53:56','2025-10-25 18:53:56');
INSERT INTO `store` VALUES ('3','Tester','7','2025-10-27 19:12:18','2025-10-27 19:12:18');
INSERT INTO `store` VALUES ('4','Zenobias','8','2025-11-10 21:35:42','2025-11-10 21:35:51');
INSERT INTO `store` VALUES ('5','cache','8','2025-11-10 21:36:24','2025-11-10 21:36:24');
INSERT INTO `store` VALUES ('6','Unit 2(1st Floor)','1','2025-12-07 11:28:36','2025-12-07 11:28:53');
INSERT INTO `store` VALUES ('7','Gujranwala Store','7','2025-12-19 16:22:39','2025-12-19 16:22:39');


DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `supplier` VALUES ('3','Gujranwala','Gujranwala','30000-00000-0','03377777000','testuser@gmail.com','12121213','13','2025-09-22 18:55:12','2025-09-22 18:55:26','1','testuser');
INSERT INTO `supplier` VALUES ('4','DONE','DOBNE','1829182918','19289182198','faizan@gmail.com','112112','18','2025-10-17 12:25:24','2025-10-17 12:25:24','7','DONE');
INSERT INTO `supplier` VALUES ('7','Grw','','','123','','','30','2025-11-07 00:20:07','2025-11-07 00:20:07','1','Supplier ABC');
INSERT INTO `supplier` VALUES ('8','Gujranwala','house 25/433 , Kashmir colony, Rahwali,Pakistan','','03251568863','','','34','2025-11-10 21:35:11','2025-11-10 21:35:20','8','Wali Baig');


DROP TABLE IF EXISTS `trn_dtl`;
CREATE TABLE `trn_dtl` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `v_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `v_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preparedby` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `cash_id` bigint unsigned DEFAULT NULL,
  `r_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pre_bal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=468 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trn_dtl` VALUES ('152','SIN','1','2025-10-28','','261000.00','0','','Admin PremierTax','28','','1','','','7','2025-10-28 19:43:09','2025-11-05 02:01:18');
INSERT INTO `trn_dtl` VALUES ('156','SIN','2','2025-11-05','','202000.00','0','','Admin PremierTax','28','','2','','','7','2025-11-05 02:02:59','2025-11-05 02:05:38');
INSERT INTO `trn_dtl` VALUES ('160','BRV','1','2025-11-06','','0','63000.00','N','Admin','6','2','','','','1','2025-11-07 00:45:38','2025-11-07 00:45:38');
INSERT INTO `trn_dtl` VALUES ('188','SIN','1','2025-11-10','','1351.35','0','','Demo Wali','35','','1','','','8','2025-11-10 21:58:15','2025-11-10 21:58:15');
INSERT INTO `trn_dtl` VALUES ('190','PRN','1','2025-11-10','','83.00','0','','Admin','30','9','1','','','1','2025-11-10 23:14:24','2025-11-10 23:14:24');
INSERT INTO `trn_dtl` VALUES ('197','SIN','3','2025-12-19','','20000.00','0','','Admin PremierTax','28','156','3','','','7','2025-12-19 16:21:31','2025-12-19 16:21:31');
INSERT INTO `trn_dtl` VALUES ('202','OB','1','2026-01-01','','20917.8','0','N','Admin','101','','','','','1','2026-01-01 19:41:04','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('203','OB','1','2026-01-01','','0','20917.8','N','Admin','9','','','','','1','2026-01-01 19:41:04','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('204','OB','1','2026-01-01','','499253','0','N','Admin','37','','','','','1','2026-01-01 19:45:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('205','OB','1','2026-01-01','','0','499253','N','Admin','9','','','','','1','2026-01-01 19:45:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('206','OB','1','2026-01-01','','31471','0','N','Admin','38','','','','','1','2026-01-01 19:45:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('207','OB','1','2026-01-01','','0','31471','N','Admin','9','','','','','1','2026-01-01 19:45:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('208','OB','1','2026-01-01','','164862','0','N','Admin','39','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('209','OB','1','2026-01-01','','0','164862','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('210','OB','1','2026-01-01','','184701','0','N','Admin','40','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('211','OB','1','2026-01-01','','0','184701','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('212','OB','1','2026-01-01','','160979','0','N','Admin','41','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('213','OB','1','2026-01-01','','0','160979','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('214','OB','1','2026-01-01','','779710','0','N','Admin','42','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('215','OB','1','2026-01-01','','0','779710','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('216','OB','1','2026-01-01','','1453069','0','N','Admin','43','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('217','OB','1','2026-01-01','','0','1453069','N','Admin','9','','','','','1','2026-01-01 19:48:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('218','OB','1','2026-01-01','','1250635','0','N','Admin','44','','','','','1','2026-01-01 20:07:56','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('219','OB','1','2026-01-01','','0','1250635','N','Admin','9','','','','','1','2026-01-01 20:07:56','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('220','OB','1','2026-01-01','','161041','0','N','Admin','45','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('221','OB','1','2026-01-01','','0','161041','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('222','OB','1','2026-01-01','','46399','0','N','Admin','46','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('223','OB','1','2026-01-01','','0','46399','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('224','OB','1','2026-01-01','','117515','0','N','Admin','47','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('225','OB','1','2026-01-01','','0','117515','N','Admin','9','','','','','1','2026-01-01 20:22:21','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('226','OB','1','2026-01-01','','22106','0','N','Admin','114','','','','','1','2026-01-03 16:39:04','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('227','OB','1','2026-01-01','','0','22106','N','Admin','9','','','','','1','2026-01-03 16:39:04','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('228','SIN','1','2026-01-03','','19130.40','0','','Admin','114','2','1','','','1','2026-01-03 16:53:15','2026-01-03 16:53:15');
INSERT INTO `trn_dtl` VALUES ('229','OB','1','2026-01-01','','114304','0','N','Admin','85','','','','','1','2026-01-04 16:41:23','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('230','OB','1','2026-01-01','','0','114304','N','Admin','9','','','','','1','2026-01-04 16:41:23','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('231','SIN','2','2026-01-04','','74760.00','0','','Admin','85','2','2','','','1','2026-01-04 16:47:08','2026-01-04 16:47:08');
INSERT INTO `trn_dtl` VALUES ('232','OB','1','2026-01-01','','459343','0','N','Admin','64','','','','','1','2026-01-04 16:51:34','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('233','OB','1','2026-01-01','','0','459343','N','Admin','9','','','','','1','2026-01-04 16:51:34','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('234','SIN','3','2026-01-04','','7830.00','0','','Admin','64','2','3','','','1','2026-01-04 16:52:31','2026-01-04 16:52:31');
INSERT INTO `trn_dtl` VALUES ('235','OB','1','2026-01-01','','605118','0','N','Admin','75','','','','','1','2026-01-04 16:54:17','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('236','OB','1','2026-01-01','','0','605118','N','Admin','9','','','','','1','2026-01-04 16:54:17','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('237','SIN','4','2026-01-04','','45900.00','0','','Admin','75','2','4','','','1','2026-01-04 16:58:51','2026-01-04 16:58:51');
INSERT INTO `trn_dtl` VALUES ('238','OB','1','2026-01-01','','197168','0','N','Admin','73','','','','','1','2026-01-04 17:00:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('239','OB','1','2026-01-01','','0','197168','N','Admin','9','','','','','1','2026-01-04 17:00:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('240','SIN','5','2026-01-04','','18630.00','0','','Admin','73','2','5','','','1','2026-01-04 17:02:32','2026-01-04 17:02:32');
INSERT INTO `trn_dtl` VALUES ('241','OB','1','2026-01-01','','85143','0','N','Admin','77','','','','','1','2026-01-04 17:04:37','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('242','OB','1','2026-01-01','','0','85143','N','Admin','9','','','','','1','2026-01-04 17:04:37','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('243','SIN','6','2026-01-04','','48600.00','0','','Admin','77','2','6','','','1','2026-01-04 17:07:51','2026-01-04 17:07:51');
INSERT INTO `trn_dtl` VALUES ('247','OB','1','2026-01-01','','110752','0','N','Admin','87','','','','','1','2026-01-04 17:20:41','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('248','OB','1','2026-01-01','','0','110752','N','Admin','9','','','','','1','2026-01-04 17:20:41','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('249','SIN','8','2026-01-04','','64830.00','0','','Admin','87','2','8','','','1','2026-01-04 17:25:35','2026-01-04 20:14:57');
INSERT INTO `trn_dtl` VALUES ('250','OB','1','2026-01-01','','332903','0','N','Admin','69','','','','','1','2026-01-04 17:28:34','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('251','OB','1','2026-01-01','','0','332903','N','Admin','9','','','','','1','2026-01-04 17:28:34','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('252','SIN','9','2026-01-04','','12915.00','0','','Admin','69','2','9','','','1','2026-01-04 17:29:31','2026-01-04 17:29:31');
INSERT INTO `trn_dtl` VALUES ('253','OB','1','2026-01-01','','206022','0','N','Admin','72','','','','','1','2026-01-04 17:45:26','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('254','OB','1','2026-01-01','','0','206022','N','Admin','9','','','','','1','2026-01-04 17:45:26','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('256','CRV','1','2026-01-03','','0','50000.00','N','Admin','72','157','','','','1','2026-01-04 20:06:11','2026-01-04 20:06:11');
INSERT INTO `trn_dtl` VALUES ('257','SIN','10','2026-01-04','','83785.00','0','','Admin','72','2','10','','','1','2026-01-04 20:10:46','2026-01-04 20:10:46');
INSERT INTO `trn_dtl` VALUES ('258','OB','1','2026-01-01','','1072290','0','N','Admin','82','','','','','1','2026-01-04 20:19:01','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('259','OB','1','2026-01-01','','0','1072290','N','Admin','9','','','','','1','2026-01-04 20:19:01','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('260','SIN','10','2026-01-04','','7500.00','0','','Admin','82','2','11','','','1','2026-01-04 20:20:53','2026-01-04 20:20:53');
INSERT INTO `trn_dtl` VALUES ('261','OB','1','2026-01-01','','88668','0','N','Admin','100','','','','','1','2026-01-04 20:23:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('262','OB','1','2026-01-01','','0','88668','N','Admin','9','','','','','1','2026-01-04 20:23:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('263','OB','1','2026-01-01','','347332','0','N','Admin','67','','','','','1','2026-01-04 20:24:37','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('264','OB','1','2026-01-01','','0','347332','N','Admin','9','','','','','1','2026-01-04 20:24:37','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('265','SIN','10','2026-01-04','','15915.00','0','','Admin','100','2','12','','','1','2026-01-04 20:27:16','2026-01-04 20:27:16');
INSERT INTO `trn_dtl` VALUES ('266','SIN','10','2026-01-04','','6300.00','0','','Admin','67','2','13','','','1','2026-01-04 20:28:36','2026-01-04 20:57:12');
INSERT INTO `trn_dtl` VALUES ('267','OB','1','2026-01-01','','689487','0','N','Admin','68','','','','','1','2026-01-04 20:29:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('268','OB','1','2026-01-01','','0','689487','N','Admin','9','','','','','1','2026-01-04 20:29:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('269','SIN','10','2026-01-04','','69380.20','0','','Admin','68','2','14','','','1','2026-01-04 20:30:34','2026-01-04 20:55:13');
INSERT INTO `trn_dtl` VALUES ('270','OB','1','2026-01-01','','149620','0','N','Admin','48','','','','','1','2026-01-05 16:38:36','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('271','OB','1','2026-01-01','','0','149620','N','Admin','9','','','','','1','2026-01-05 16:38:36','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('272','OB','1','2026-01-01','','39600','0','N','Admin','136','','','','','1','2026-01-06 18:40:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('273','OB','1','2026-01-01','','0','39600','N','Admin','9','','','','','1','2026-01-06 18:40:15','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('274','SIN','10','2026-01-06','','16848.00','0','','Admin','136','2','15','','','1','2026-01-06 18:42:24','2026-01-06 19:58:41');
INSERT INTO `trn_dtl` VALUES ('275','OB','1','2026-01-01','','5612','0','N','Admin','131','','','','','1','2026-01-06 19:12:45','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('276','OB','1','2026-01-01','','0','5612','N','Admin','9','','','','','1','2026-01-06 19:12:45','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('277','SIN','10','2026-01-06','','32037.77','0','','Admin','131','2','16','','','1','2026-01-06 19:40:49','2026-01-06 19:41:52');
INSERT INTO `trn_dtl` VALUES ('280','OB','1','2026-01-01','','189033','0','N','Admin','49','','','','','1','2026-01-07 18:30:16','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('281','OB','1','2026-01-01','','0','189033','N','Admin','9','','','','','1','2026-01-07 18:30:16','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('282','OB','1','2026-01-01','','65561','0','N','Admin','50','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('283','OB','1','2026-01-01','','0','65561','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('284','OB','1','2026-01-01','','143670','0','N','Admin','51','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('285','OB','1','2026-01-01','','0','143670','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('286','OB','1','2026-01-01','','307647','0','N','Admin','53','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('287','OB','1','2026-01-01','','0','307647','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('288','OB','1','2026-01-01','','22755','0','N','Admin','52','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('289','OB','1','2026-01-01','','0','22755','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('290','OB','1','2026-01-01','','84977','0','N','Admin','54','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('291','OB','1','2026-01-01','','0','84977','N','Admin','9','','','','','1','2026-01-07 18:33:08','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('292','OB','1','2026-01-01','','325980','0','N','Admin','56','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('293','OB','1','2026-01-01','','0','325980','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('294','OB','1','2026-01-01','','25696','0','N','Admin','57','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('295','OB','1','2026-01-01','','0','25696','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('296','OB','1','2026-01-01','','208699','0','N','Admin','58','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('297','OB','1','2026-01-01','','0','208699','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('298','OB','1','2026-01-01','','60839','0','N','Admin','59','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('299','OB','1','2026-01-01','','0','60839','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('300','OB','1','2026-01-01','','102801','0','N','Admin','130','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('301','OB','1','2026-01-01','','0','102801','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('302','OB','1','2026-01-01','','71213','0','N','Admin','122','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('303','OB','1','2026-01-01','','0','71213','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('304','OB','1','2026-01-01','','161050','0','N','Admin','123','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('305','OB','1','2026-01-01','','0','161050','N','Admin','9','','','','','1','2026-01-07 18:38:43','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('307','CRV','2','2026-01-01','','0','20000.00','N','Admin','41','157','','','','1','2026-01-07 18:42:03','2026-01-07 18:42:03');
INSERT INTO `trn_dtl` VALUES ('308','CRV','3','2026-01-01','','0','30000.00','N','Admin','40','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('309','CRV','3','2026-01-01','','0','23000.00','N','Admin','42','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('310','CRV','3','2026-01-01','Meezan Bank','0','23000.00','N','Admin','44','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('311','CRV','3','2026-01-01','','0','7000.00','N','Admin','47','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('312','CRV','3','2026-01-01','','0','20000.00','N','Admin','46','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('313','CRV','3','2026-01-01','','0','15000.00','N','Admin','51','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('314','CRV','3','2026-01-01','','0','21000.00','N','Admin','59','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('315','CRV','3','2026-01-01','','0','30000.00','N','Admin','37','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('316','CRV','3','2026-01-01','Meezan','0','20000.00','N','Admin','53','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('317','CRV','3','2026-01-01','HBL','0','35000.00','N','Admin','58','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('318','CRV','3','2026-01-01','Meezan','0','22700.00','N','Admin','52','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('319','CRV','3','2026-01-01','Meezan Bank','0','20000.00','N','Admin','39','157','','','','1','2026-01-07 18:50:14','2026-01-07 18:50:14');
INSERT INTO `trn_dtl` VALUES ('321','SIN','17','2026-01-07','','19364.80','0','','Admin','51','2','17','','','1','2026-01-07 19:00:24','2026-01-07 19:00:24');
INSERT INTO `trn_dtl` VALUES ('322','SIN','10','2026-01-07','','16511.04','0','','Admin','52','2','18','','','1','2026-01-07 19:09:15','2026-01-07 19:09:15');
INSERT INTO `trn_dtl` VALUES ('323','SIN','10','2026-01-01','','9261.00','0','','Admin','122','2','19','','','1','2026-01-07 19:22:41','2026-01-07 19:22:41');
INSERT INTO `trn_dtl` VALUES ('325','SIN','10','2026-01-07','','21242.09','0','','Admin','47','2','21','','','1','2026-01-07 19:49:07','2026-01-07 19:49:07');
INSERT INTO `trn_dtl` VALUES ('326','SIN','10','2026-01-07','','10372.32','0','','Admin','39','2','22','','','1','2026-01-07 19:59:43','2026-01-07 19:59:43');
INSERT INTO `trn_dtl` VALUES ('327','SIN','10','2026-01-07','','9720.00','0','','Admin','41','2','23','','','1','2026-01-07 20:03:38','2026-01-07 20:03:38');
INSERT INTO `trn_dtl` VALUES ('328','SIN','10','2026-01-07','','48423.60','0','','Admin','40','2','24','','','1','2026-01-07 21:34:13','2026-01-07 21:34:13');
INSERT INTO `trn_dtl` VALUES ('329','SIN','10','2026-01-01','','8568.00','0','','Admin','53','2','25','','','1','2026-01-07 21:37:45','2026-01-07 21:37:45');
INSERT INTO `trn_dtl` VALUES ('331','SIN','26','2026-01-07','','70436.52','0','','Admin','43','2','26','','','1','2026-01-07 21:41:45','2026-01-07 21:41:45');
INSERT INTO `trn_dtl` VALUES ('332','SIN','10','2026-01-07','','11907.00','0','','Admin','38','2','27','','','1','2026-01-07 21:47:07','2026-01-07 21:47:07');
INSERT INTO `trn_dtl` VALUES ('333','SIN','20','2026-01-07','','48866.33','0','','Admin','37','2','20','','','1','2026-01-07 21:53:20','2026-01-07 21:53:20');
INSERT INTO `trn_dtl` VALUES ('334','CRV','4','2026-01-06','','0','20000.00','N','Admin','123','157','','','','1','2026-01-07 21:55:32','2026-01-07 21:55:32');
INSERT INTO `trn_dtl` VALUES ('335','SIN','10','2026-01-07','','90681.95','0','','Admin','123','2','28','','','1','2026-01-07 21:59:38','2026-01-07 21:59:38');
INSERT INTO `trn_dtl` VALUES ('336','OB','1','2026-01-01','','139963','0','N','Admin','118','','','','','1','2026-01-07 22:04:00','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('337','OB','1','2026-01-01','','0','139963','N','Admin','9','','','','','1','2026-01-07 22:04:00','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('338','SIN','10','2026-01-06','','30870.00','0','','Admin','118','2','29','','','1','2026-01-07 22:05:05','2026-01-07 22:05:05');
INSERT INTO `trn_dtl` VALUES ('339','SIN','10','2026-01-07','','111375.00','0','','Admin','132','2','30','','','1','2026-01-07 22:09:34','2026-01-07 22:09:34');
INSERT INTO `trn_dtl` VALUES ('340','OB','1','2026-01-01','','240680','0','N','Admin','124','','','','','1','2026-01-08 19:46:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('341','OB','1','2026-01-01','','0','240680','N','Admin','9','','','','','1','2026-01-08 19:46:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('342','OB','1','2026-01-01','','8348','0','N','Admin','65','','','','','1','2026-01-08 19:46:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('343','OB','1','2026-01-01','','0','8348','N','Admin','9','','','','','1','2026-01-08 19:46:33','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('344','OB','1','2026-01-01','','172654','0','N','Admin','66','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('345','OB','1','2026-01-01','','0','172654','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('346','OB','1','2026-01-01','','82662','0','N','Admin','70','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('347','OB','1','2026-01-01','','0','82662','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('348','OB','1','2026-01-01','','126441','0','N','Admin','71','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('349','OB','1','2026-01-01','','0','126441','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('350','OB','1','2026-01-01','','126307','0','N','Admin','74','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('351','OB','1','2026-01-01','','0','126307','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('352','OB','1','2026-01-01','','85590','0','N','Admin','78','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('353','OB','1','2026-01-01','','0','85590','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('354','OB','1','2026-01-01','','979451','0','N','Admin','29','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('355','OB','1','2026-01-01','','0','979451','N','Admin','9','','','','','1','2026-01-08 20:02:58','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('356','OB','1','2026-01-01','','71461','0','N','Admin','79','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('357','OB','1','2026-01-01','','0','71461','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('358','OB','1','2026-01-01','','517418','0','N','Admin','98','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('359','OB','1','2026-01-01','','0','517418','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('360','OB','1','2026-01-01','','172039','0','N','Admin','104','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('361','OB','1','2026-01-01','','0','172039','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('362','OB','1','2026-01-01','','201957','0','N','Admin','105','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('363','OB','1','2026-01-01','','0','201957','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('364','OB','1','2026-01-01','','627697','0','N','Admin','80','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('365','OB','1','2026-01-01','','0','627697','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('366','OB','1','2026-01-01','','838626','0','N','Admin','81','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('367','OB','1','2026-01-01','','0','838626','N','Admin','9','','','','','1','2026-01-08 20:23:42','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('368','SIN','10','2026-01-08','','28548.00','0','','Admin','109','2','31','','','1','2026-01-08 20:30:16','2026-01-08 20:30:16');
INSERT INTO `trn_dtl` VALUES ('369','SIN','10','2026-01-10','','89737.00','0','','Admin','133','2','32','','','1','2026-01-10 17:09:46','2026-01-10 17:09:46');
INSERT INTO `trn_dtl` VALUES ('373','CRV','5','2026-01-05','','0','50000.00','N','Admin','64','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('374','CRV','5','2026-01-05','','0','50000.00','N','Admin','87','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('375','CRV','5','2026-01-05','','0','30000.00','N','Admin','94','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('376','CRV','5','2026-01-05','','0','40000.00','N','Admin','67','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('377','CRV','5','2026-01-05','','0','15000.00','N','Admin','92','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('378','CRV','5','2026-01-05','','0','100000.00','N','Admin','68','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('380','CRV','5','2026-01-05','','0','60000.00','N','Admin','69','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('381','CRV','5','2026-01-05','','0','20000.00','N','Admin','73','157','','','','1','2026-01-11 18:54:01','2026-01-11 18:54:01');
INSERT INTO `trn_dtl` VALUES ('382','SIN','10','2026-01-03','','15915.00','0','','Admin','158','2','33','','','1','2026-01-11 18:59:02','2026-01-11 18:59:02');
INSERT INTO `trn_dtl` VALUES ('383','OB','1','2026-01-01','','40723','0','N','Admin','158','','','','','1','2026-01-11 19:00:12','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('384','OB','1','2026-01-01','','0','40723','N','Admin','9','','','','','1','2026-01-11 19:00:12','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('385','CRV','6','2026-01-01','','0','15000.00','N','Admin','158','157','','','','1','2026-01-11 19:01:03','2026-01-11 19:01:03');
INSERT INTO `trn_dtl` VALUES ('386','CRV','7','2026-01-11','','0','89500.00','N','Admin','133','157','','','','1','2026-01-11 19:20:21','2026-01-11 19:20:21');
INSERT INTO `trn_dtl` VALUES ('387','CRV','8','2026-01-05','','0','20000.00','N','Admin','73','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('388','CRV','8','2026-01-05','','0','13000.00','N','Admin','158','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('389','CRV','8','2026-01-05','','0','30000.00','N','Admin','71','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('390','CRV','8','2026-01-05','','0','30000.00','N','Admin','79','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('391','CRV','8','2026-01-05','','0','60000.00','N','Admin','81','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('392','CRV','8','2026-01-05','','0','100000.00','N','Admin','80','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('393','CRV','8','2026-01-05','','0','50000.00','N','Admin','72','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('394','CRV','8','2026-01-05','','0','50000.00','N','Admin','98','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('395','CRV','8','2026-01-05','','0','25000.00','N','Admin','105','157','','','','1','2026-01-11 20:40:40','2026-01-11 20:40:40');
INSERT INTO `trn_dtl` VALUES ('396','CRV','9','2026-01-07','','0','20000.00','N','Admin','89','157','','','','1','2026-01-11 20:42:02','2026-01-11 20:42:02');
INSERT INTO `trn_dtl` VALUES ('397','CRV','9','2026-01-07','','0','100000.00','N','Admin','29','157','','','','1','2026-01-11 20:42:02','2026-01-11 20:42:02');
INSERT INTO `trn_dtl` VALUES ('398','OB','1','2026-01-01','','96303','0','N','Admin','159','','','','','1','2026-01-11 20:50:30','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('399','OB','1','2026-01-01','','0','96303','N','Admin','9','','','','','1','2026-01-11 20:50:30','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('400','CRV','10','2026-01-11','','0','50000.00','N','Admin','159','157','','','','1','2026-01-11 20:54:31','2026-01-11 20:54:31');
INSERT INTO `trn_dtl` VALUES ('401','CRV','10','2026-01-11','','0','30000.00','N','Admin','85','157','','','','1','2026-01-11 20:54:31','2026-01-11 20:54:31');
INSERT INTO `trn_dtl` VALUES ('402','CRV','11','2026-01-04','','0','150000.00','N','Admin','82','157','','','','1','2026-01-11 20:54:52','2026-01-11 20:54:52');
INSERT INTO `trn_dtl` VALUES ('403','CRV','10','2026-01-11','','0','150000','N','Admin','82','157','','','','1','2026-01-11 20:56:04','2026-01-11 20:56:04');
INSERT INTO `trn_dtl` VALUES ('404','CRV','11','2026-01-08','','0','30000.00','N','Admin','85','157','','','','1','2026-01-11 20:56:43','2026-01-11 20:56:43');
INSERT INTO `trn_dtl` VALUES ('405','CRV','11','2026-01-08','','0','59000.00','N','Admin','74','157','','','','1','2026-01-11 20:56:43','2026-01-11 20:56:43');
INSERT INTO `trn_dtl` VALUES ('408','OB','1','2026-01-01','','167363','0','N','Admin','94','','','','','1','2026-01-11 21:13:51','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('409','OB','1','2026-01-01','','0','167363','N','Admin','9','','','','','1','2026-01-11 21:13:51','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('410','SIN','35','2026-01-11','','92475.00','0','','Admin','94','2','35','','','1','2026-01-11 21:14:32','2026-01-11 21:14:32');
INSERT INTO `trn_dtl` VALUES ('411','SIN','10','2026-01-11','','21420.00','0','','Admin','66','2','36','','','1','2026-01-11 21:22:25','2026-01-11 21:22:25');
INSERT INTO `trn_dtl` VALUES ('412','SIN','10','2026-01-11','','40500.00','0','','Admin','73','2','37','','','1','2026-01-11 21:27:23','2026-01-11 21:27:23');
INSERT INTO `trn_dtl` VALUES ('413','SIN','10','2026-01-11','','58292.40','0','','Admin','158','2','38','','','1','2026-01-11 21:31:39','2026-01-11 21:31:39');
INSERT INTO `trn_dtl` VALUES ('415','SIN','39','2026-01-11','','165618.00','0','','Admin','75','2','39','','','1','2026-01-11 21:42:12','2026-01-11 21:42:12');
INSERT INTO `trn_dtl` VALUES ('417','OB','1','2026-01-01','','90181','0','N','Admin','90','','','','','1','2026-01-11 22:20:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('418','OB','1','2026-01-01','','0','90181','N','Admin','9','','','','','1','2026-01-11 22:20:57','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('419','SIN','10','2026-01-11','','6300.00','0','','Admin','90','2','41','','','1','2026-01-11 22:21:51','2026-01-11 22:21:51');
INSERT INTO `trn_dtl` VALUES ('420','SIN','10','2026-01-11','','66765.00','0','','Admin','72','2','42','','','1','2026-01-11 22:31:11','2026-01-11 22:31:11');
INSERT INTO `trn_dtl` VALUES ('421','SIN','10','2026-01-11','','24300.00','0','','Admin','79','2','43','','','1','2026-01-11 22:35:04','2026-01-11 22:35:04');
INSERT INTO `trn_dtl` VALUES ('424','SIN','10','2026-01-11','','157685.10','0','','Admin','87','2','45','','','1','2026-01-11 22:51:27','2026-01-11 22:51:27');
INSERT INTO `trn_dtl` VALUES ('425','OB','1','2026-01-01','','59575','0','N','Admin','89','','','','','1','2026-01-11 22:54:46','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('426','OB','1','2026-01-01','','0','59575','N','Admin','9','','','','','1','2026-01-11 22:54:46','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('427','SIN','10','2026-01-11','','16830.00','0','','Admin','89','2','46','','','1','2026-01-11 22:55:45','2026-01-11 22:55:45');
INSERT INTO `trn_dtl` VALUES ('428','SIN','44','2026-01-11','','78210.00','0','','Admin','85','2','44','','','1','2026-01-11 22:57:34','2026-01-11 22:57:34');
INSERT INTO `trn_dtl` VALUES ('429','SIN','10','2026-01-11','','43530.00','0','','Admin','69','2','47','','','1','2026-01-11 23:01:38','2026-01-11 23:01:38');
INSERT INTO `trn_dtl` VALUES ('430','CRV','12','2026-01-11','','0','20000.00','N','Admin','99','157','','','','1','2026-01-11 23:04:45','2026-01-11 23:04:45');
INSERT INTO `trn_dtl` VALUES ('431','OB','1','2026-01-01','','53566','0','N','Admin','99','','','','','1','2026-01-11 23:09:53','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('432','OB','1','2026-01-01','','0','53566','N','Admin','9','','','','','1','2026-01-11 23:09:53','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('433','SIN','10','2026-01-11','','37665.00','0','','Admin','99','2','48','','','1','2026-01-11 23:10:39','2026-01-11 23:10:39');
INSERT INTO `trn_dtl` VALUES ('435','SIN','10','2026-01-11','','40305.60','0','','Admin','104','2','50','','','1','2026-01-11 23:23:47','2026-01-11 23:23:47');
INSERT INTO `trn_dtl` VALUES ('436','OB','1','2026-01-01','','58020','0','N','Admin','92','','','','','1','2026-01-11 23:29:28','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('437','OB','1','2026-01-01','','0','58020','N','Admin','9','','','','','1','2026-01-11 23:29:28','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('438','SIN','10','2026-01-11','','7500.00','0','','Admin','92','2','51','','','1','2026-01-11 23:30:31','2026-01-11 23:30:31');
INSERT INTO `trn_dtl` VALUES ('439','SIN','10','2026-01-11','','24300.00','0','','Admin','160','2','52','','','1','2026-01-11 23:32:31','2026-01-11 23:32:31');
INSERT INTO `trn_dtl` VALUES ('442','SIN','10','2026-01-11','','157068.00','0','','Admin','81','2','54','','','1','2026-01-11 23:41:33','2026-01-11 23:41:33');
INSERT INTO `trn_dtl` VALUES ('443','SIN','10','2026-01-11','','70842.60','0','','Admin','105','2','55','','','1','2026-01-11 23:45:14','2026-01-11 23:45:14');
INSERT INTO `trn_dtl` VALUES ('446','SIN','10','2026-01-11','','17280.00','0','','Admin','100','2','57','','','1','2026-01-11 23:54:27','2026-01-11 23:54:27');
INSERT INTO `trn_dtl` VALUES ('449','CRV','13','2026-01-11','','0','272000.00','N','Admin','29','157','','','','1','2026-01-11 23:58:56','2026-01-11 23:58:56');
INSERT INTO `trn_dtl` VALUES ('451','SIN','59','2026-01-11','','44436.00','0','','Admin','29','2','59','','','1','2026-01-12 00:00:40','2026-01-12 00:00:40');
INSERT INTO `trn_dtl` VALUES ('452','SIN','10','2026-01-12','','6415.20','0','','Admin','70','2','60','','','1','2026-01-12 00:03:06','2026-01-12 00:03:06');
INSERT INTO `trn_dtl` VALUES ('454','SIN','61','2026-01-12','','99360.00','0','','Admin','74','2','61','','','1','2026-01-12 00:05:58','2026-01-12 00:05:58');
INSERT INTO `trn_dtl` VALUES ('455','SIN','10','2026-01-12','','27382.50','0','','Admin','67','2','62','','','1','2026-01-12 00:09:16','2026-01-12 00:09:16');
INSERT INTO `trn_dtl` VALUES ('456','SIN','10','2026-01-12','','78300.00','0','','Admin','64','2','63','','','1','2026-01-12 00:12:34','2026-01-12 00:12:34');
INSERT INTO `trn_dtl` VALUES ('457','SIN','10','2026-01-12','','87000.00','0','','Admin','159','2','64','','','1','2026-01-12 00:16:04','2026-01-12 00:16:04');
INSERT INTO `trn_dtl` VALUES ('458','CRV','14','2026-01-01','2% Breakage 2025','0','54095.00','N','Admin','83','157','','','','1','2026-01-12 00:19:50','2026-01-12 00:19:50');
INSERT INTO `trn_dtl` VALUES ('459','OB','1','2026-01-01','','204100','0','N','Admin','91','','','','','1','2026-01-12 00:21:32','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('460','OB','1','2026-01-01','','0','204100','N','Admin','9','','','','','1','2026-01-12 00:21:32','2026-01-12 00:21:32');
INSERT INTO `trn_dtl` VALUES ('461','SIN','10','2026-01-11','','105300.00','0','','Admin','91','2','65','','','1','2026-01-12 00:25:02','2026-01-12 00:25:02');
INSERT INTO `trn_dtl` VALUES ('462','SIN','40','2026-01-11','','308208.00','0','','Admin','82','2','40','','','1','2026-01-12 11:27:12','2026-01-12 11:27:12');
INSERT INTO `trn_dtl` VALUES ('463','SIN','49','2026-01-06','','141298.50','0','','Admin','98','2','49','','','1','2026-01-12 11:28:09','2026-01-12 11:28:09');
INSERT INTO `trn_dtl` VALUES ('464','SIN','56','2026-01-11','','50516.55','0','','Admin','68','2','56','','','1','2026-01-12 11:28:59','2026-01-12 11:28:59');
INSERT INTO `trn_dtl` VALUES ('465','SIN','58','2026-01-11','','54712.80','0','','Admin','80','2','58','','','1','2026-01-12 11:29:24','2026-01-12 11:29:24');
INSERT INTO `trn_dtl` VALUES ('466','SIN','10','2026-01-12','','16470.00','0','','Admin','163','2','66','','','1','2026-01-12 18:41:05','2026-01-12 18:41:05');
INSERT INTO `trn_dtl` VALUES ('467','SIN','10','2026-01-12','','31730.40','0','','Admin','152','2','67','','','1','2026-01-12 20:21:18','2026-01-12 20:21:18');


DROP TABLE IF EXISTS `trn_dtl_views`;
;

INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','28','','261000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','28','','202000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','6','','0','63000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','35','','1351.35','0','8','account');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','30','','83.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('197','3','SIN','2025-12-19','28','','20000.00','0','7','account');
INSERT INTO `trn_dtl_views` VALUES ('202','1','OB','2026-01-01','101','','20917.8','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('203','1','OB','2026-01-01','9','','0','20917.8','1','account');
INSERT INTO `trn_dtl_views` VALUES ('204','1','OB','2026-01-01','37','','499253','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('205','1','OB','2026-01-01','9','','0','499253','1','account');
INSERT INTO `trn_dtl_views` VALUES ('206','1','OB','2026-01-01','38','','31471','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('207','1','OB','2026-01-01','9','','0','31471','1','account');
INSERT INTO `trn_dtl_views` VALUES ('208','1','OB','2026-01-01','39','','164862','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('209','1','OB','2026-01-01','9','','0','164862','1','account');
INSERT INTO `trn_dtl_views` VALUES ('210','1','OB','2026-01-01','40','','184701','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('211','1','OB','2026-01-01','9','','0','184701','1','account');
INSERT INTO `trn_dtl_views` VALUES ('212','1','OB','2026-01-01','41','','160979','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('213','1','OB','2026-01-01','9','','0','160979','1','account');
INSERT INTO `trn_dtl_views` VALUES ('214','1','OB','2026-01-01','42','','779710','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('215','1','OB','2026-01-01','9','','0','779710','1','account');
INSERT INTO `trn_dtl_views` VALUES ('216','1','OB','2026-01-01','43','','1453069','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('217','1','OB','2026-01-01','9','','0','1453069','1','account');
INSERT INTO `trn_dtl_views` VALUES ('218','1','OB','2026-01-01','44','','1250635','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('219','1','OB','2026-01-01','9','','0','1250635','1','account');
INSERT INTO `trn_dtl_views` VALUES ('220','1','OB','2026-01-01','45','','161041','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('221','1','OB','2026-01-01','9','','0','161041','1','account');
INSERT INTO `trn_dtl_views` VALUES ('222','1','OB','2026-01-01','46','','46399','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('223','1','OB','2026-01-01','9','','0','46399','1','account');
INSERT INTO `trn_dtl_views` VALUES ('224','1','OB','2026-01-01','47','','117515','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('225','1','OB','2026-01-01','9','','0','117515','1','account');
INSERT INTO `trn_dtl_views` VALUES ('226','1','OB','2026-01-01','114','','22106','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('227','1','OB','2026-01-01','9','','0','22106','1','account');
INSERT INTO `trn_dtl_views` VALUES ('228','1','SIN','2026-01-03','114','','19130.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('229','1','OB','2026-01-01','85','','114304','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('230','1','OB','2026-01-01','9','','0','114304','1','account');
INSERT INTO `trn_dtl_views` VALUES ('231','2','SIN','2026-01-04','85','','74760.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('232','1','OB','2026-01-01','64','','459343','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('233','1','OB','2026-01-01','9','','0','459343','1','account');
INSERT INTO `trn_dtl_views` VALUES ('234','3','SIN','2026-01-04','64','','7830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('235','1','OB','2026-01-01','75','','605118','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('236','1','OB','2026-01-01','9','','0','605118','1','account');
INSERT INTO `trn_dtl_views` VALUES ('237','4','SIN','2026-01-04','75','','45900.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('238','1','OB','2026-01-01','73','','197168','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('239','1','OB','2026-01-01','9','','0','197168','1','account');
INSERT INTO `trn_dtl_views` VALUES ('240','5','SIN','2026-01-04','73','','18630.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('241','1','OB','2026-01-01','77','','85143','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('242','1','OB','2026-01-01','9','','0','85143','1','account');
INSERT INTO `trn_dtl_views` VALUES ('243','6','SIN','2026-01-04','77','','48600.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('247','1','OB','2026-01-01','87','','110752','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('248','1','OB','2026-01-01','9','','0','110752','1','account');
INSERT INTO `trn_dtl_views` VALUES ('249','8','SIN','2026-01-04','87','','64830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('250','1','OB','2026-01-01','69','','332903','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('251','1','OB','2026-01-01','9','','0','332903','1','account');
INSERT INTO `trn_dtl_views` VALUES ('252','9','SIN','2026-01-04','69','','12915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('253','1','OB','2026-01-01','72','','206022','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('254','1','OB','2026-01-01','9','','0','206022','1','account');
INSERT INTO `trn_dtl_views` VALUES ('256','1','CRV','2026-01-03','72','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('257','10','SIN','2026-01-04','72','','83785.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('258','1','OB','2026-01-01','82','','1072290','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('259','1','OB','2026-01-01','9','','0','1072290','1','account');
INSERT INTO `trn_dtl_views` VALUES ('260','10','SIN','2026-01-04','82','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('261','1','OB','2026-01-01','100','','88668','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('262','1','OB','2026-01-01','9','','0','88668','1','account');
INSERT INTO `trn_dtl_views` VALUES ('263','1','OB','2026-01-01','67','','347332','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('264','1','OB','2026-01-01','9','','0','347332','1','account');
INSERT INTO `trn_dtl_views` VALUES ('265','10','SIN','2026-01-04','100','','15915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('266','10','SIN','2026-01-04','67','','6300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('267','1','OB','2026-01-01','68','','689487','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('268','1','OB','2026-01-01','9','','0','689487','1','account');
INSERT INTO `trn_dtl_views` VALUES ('269','10','SIN','2026-01-04','68','','69380.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('270','1','OB','2026-01-01','48','','149620','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('271','1','OB','2026-01-01','9','','0','149620','1','account');
INSERT INTO `trn_dtl_views` VALUES ('272','1','OB','2026-01-01','136','','39600','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('273','1','OB','2026-01-01','9','','0','39600','1','account');
INSERT INTO `trn_dtl_views` VALUES ('274','10','SIN','2026-01-06','136','','16848.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('275','1','OB','2026-01-01','131','','5612','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('276','1','OB','2026-01-01','9','','0','5612','1','account');
INSERT INTO `trn_dtl_views` VALUES ('277','10','SIN','2026-01-06','131','','32037.77','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('280','1','OB','2026-01-01','49','','189033','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('281','1','OB','2026-01-01','9','','0','189033','1','account');
INSERT INTO `trn_dtl_views` VALUES ('282','1','OB','2026-01-01','50','','65561','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('283','1','OB','2026-01-01','9','','0','65561','1','account');
INSERT INTO `trn_dtl_views` VALUES ('284','1','OB','2026-01-01','51','','143670','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('285','1','OB','2026-01-01','9','','0','143670','1','account');
INSERT INTO `trn_dtl_views` VALUES ('286','1','OB','2026-01-01','53','','307647','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('287','1','OB','2026-01-01','9','','0','307647','1','account');
INSERT INTO `trn_dtl_views` VALUES ('288','1','OB','2026-01-01','52','','22755','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('289','1','OB','2026-01-01','9','','0','22755','1','account');
INSERT INTO `trn_dtl_views` VALUES ('290','1','OB','2026-01-01','54','','84977','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('291','1','OB','2026-01-01','9','','0','84977','1','account');
INSERT INTO `trn_dtl_views` VALUES ('292','1','OB','2026-01-01','56','','325980','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('293','1','OB','2026-01-01','9','','0','325980','1','account');
INSERT INTO `trn_dtl_views` VALUES ('294','1','OB','2026-01-01','57','','25696','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('295','1','OB','2026-01-01','9','','0','25696','1','account');
INSERT INTO `trn_dtl_views` VALUES ('296','1','OB','2026-01-01','58','','208699','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('297','1','OB','2026-01-01','9','','0','208699','1','account');
INSERT INTO `trn_dtl_views` VALUES ('298','1','OB','2026-01-01','59','','60839','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('299','1','OB','2026-01-01','9','','0','60839','1','account');
INSERT INTO `trn_dtl_views` VALUES ('300','1','OB','2026-01-01','130','','102801','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('301','1','OB','2026-01-01','9','','0','102801','1','account');
INSERT INTO `trn_dtl_views` VALUES ('302','1','OB','2026-01-01','122','','71213','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('303','1','OB','2026-01-01','9','','0','71213','1','account');
INSERT INTO `trn_dtl_views` VALUES ('304','1','OB','2026-01-01','123','','161050','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('305','1','OB','2026-01-01','9','','0','161050','1','account');
INSERT INTO `trn_dtl_views` VALUES ('307','2','CRV','2026-01-01','41','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('308','3','CRV','2026-01-01','40','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('309','3','CRV','2026-01-01','42','','0','23000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('310','3','CRV','2026-01-01','44','Meezan Bank','0','23000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('311','3','CRV','2026-01-01','47','','0','7000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('312','3','CRV','2026-01-01','46','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('313','3','CRV','2026-01-01','51','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('314','3','CRV','2026-01-01','59','','0','21000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('315','3','CRV','2026-01-01','37','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('316','3','CRV','2026-01-01','53','Meezan','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('317','3','CRV','2026-01-01','58','HBL','0','35000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('318','3','CRV','2026-01-01','52','Meezan','0','22700.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('319','3','CRV','2026-01-01','39','Meezan Bank','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('321','17','SIN','2026-01-07','51','','19364.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('322','10','SIN','2026-01-07','52','','16511.04','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('323','10','SIN','2026-01-01','122','','9261.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('325','10','SIN','2026-01-07','47','','21242.09','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('326','10','SIN','2026-01-07','39','','10372.32','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('327','10','SIN','2026-01-07','41','','9720.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('328','10','SIN','2026-01-07','40','','48423.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('329','10','SIN','2026-01-01','53','','8568.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('331','26','SIN','2026-01-07','43','','70436.52','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('332','10','SIN','2026-01-07','38','','11907.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('333','20','SIN','2026-01-07','37','','48866.33','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('334','4','CRV','2026-01-06','123','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('335','10','SIN','2026-01-07','123','','90681.95','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('336','1','OB','2026-01-01','118','','139963','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('337','1','OB','2026-01-01','9','','0','139963','1','account');
INSERT INTO `trn_dtl_views` VALUES ('338','10','SIN','2026-01-06','118','','30870.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('339','10','SIN','2026-01-07','132','','111375.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('340','1','OB','2026-01-01','124','','240680','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('341','1','OB','2026-01-01','9','','0','240680','1','account');
INSERT INTO `trn_dtl_views` VALUES ('342','1','OB','2026-01-01','65','','8348','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('343','1','OB','2026-01-01','9','','0','8348','1','account');
INSERT INTO `trn_dtl_views` VALUES ('344','1','OB','2026-01-01','66','','172654','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('345','1','OB','2026-01-01','9','','0','172654','1','account');
INSERT INTO `trn_dtl_views` VALUES ('346','1','OB','2026-01-01','70','','82662','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('347','1','OB','2026-01-01','9','','0','82662','1','account');
INSERT INTO `trn_dtl_views` VALUES ('348','1','OB','2026-01-01','71','','126441','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('349','1','OB','2026-01-01','9','','0','126441','1','account');
INSERT INTO `trn_dtl_views` VALUES ('350','1','OB','2026-01-01','74','','126307','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('351','1','OB','2026-01-01','9','','0','126307','1','account');
INSERT INTO `trn_dtl_views` VALUES ('352','1','OB','2026-01-01','78','','85590','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('353','1','OB','2026-01-01','9','','0','85590','1','account');
INSERT INTO `trn_dtl_views` VALUES ('354','1','OB','2026-01-01','29','','979451','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('355','1','OB','2026-01-01','9','','0','979451','1','account');
INSERT INTO `trn_dtl_views` VALUES ('356','1','OB','2026-01-01','79','','71461','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('357','1','OB','2026-01-01','9','','0','71461','1','account');
INSERT INTO `trn_dtl_views` VALUES ('358','1','OB','2026-01-01','98','','517418','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('359','1','OB','2026-01-01','9','','0','517418','1','account');
INSERT INTO `trn_dtl_views` VALUES ('360','1','OB','2026-01-01','104','','172039','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('361','1','OB','2026-01-01','9','','0','172039','1','account');
INSERT INTO `trn_dtl_views` VALUES ('362','1','OB','2026-01-01','105','','201957','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('363','1','OB','2026-01-01','9','','0','201957','1','account');
INSERT INTO `trn_dtl_views` VALUES ('364','1','OB','2026-01-01','80','','627697','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('365','1','OB','2026-01-01','9','','0','627697','1','account');
INSERT INTO `trn_dtl_views` VALUES ('366','1','OB','2026-01-01','81','','838626','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('367','1','OB','2026-01-01','9','','0','838626','1','account');
INSERT INTO `trn_dtl_views` VALUES ('368','10','SIN','2026-01-08','109','','28548.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('369','10','SIN','2026-01-10','133','','89737.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('373','5','CRV','2026-01-05','64','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('374','5','CRV','2026-01-05','87','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('375','5','CRV','2026-01-05','94','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('376','5','CRV','2026-01-05','67','','0','40000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('377','5','CRV','2026-01-05','92','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('378','5','CRV','2026-01-05','68','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('380','5','CRV','2026-01-05','69','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('381','5','CRV','2026-01-05','73','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('382','10','SIN','2026-01-03','158','','15915.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('383','1','OB','2026-01-01','158','','40723','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('384','1','OB','2026-01-01','9','','0','40723','1','account');
INSERT INTO `trn_dtl_views` VALUES ('385','6','CRV','2026-01-01','158','','0','15000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('386','7','CRV','2026-01-11','133','','0','89500.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('387','8','CRV','2026-01-05','73','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('388','8','CRV','2026-01-05','158','','0','13000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('389','8','CRV','2026-01-05','71','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('390','8','CRV','2026-01-05','79','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('391','8','CRV','2026-01-05','81','','0','60000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('392','8','CRV','2026-01-05','80','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('393','8','CRV','2026-01-05','72','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('394','8','CRV','2026-01-05','98','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('395','8','CRV','2026-01-05','105','','0','25000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('396','9','CRV','2026-01-07','89','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('397','9','CRV','2026-01-07','29','','0','100000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('398','1','OB','2026-01-01','159','','96303','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('399','1','OB','2026-01-01','9','','0','96303','1','account');
INSERT INTO `trn_dtl_views` VALUES ('400','10','CRV','2026-01-11','159','','0','50000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('401','10','CRV','2026-01-11','85','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('402','11','CRV','2026-01-04','82','','0','150000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('403','10','CRV','2026-01-11','82','','0','150000','1','account');
INSERT INTO `trn_dtl_views` VALUES ('404','11','CRV','2026-01-08','85','','0','30000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('405','11','CRV','2026-01-08','74','','0','59000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('408','1','OB','2026-01-01','94','','167363','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('409','1','OB','2026-01-01','9','','0','167363','1','account');
INSERT INTO `trn_dtl_views` VALUES ('410','35','SIN','2026-01-11','94','','92475.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('411','10','SIN','2026-01-11','66','','21420.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('412','10','SIN','2026-01-11','73','','40500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('413','10','SIN','2026-01-11','158','','58292.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('415','39','SIN','2026-01-11','75','','165618.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('417','1','OB','2026-01-01','90','','90181','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('418','1','OB','2026-01-01','9','','0','90181','1','account');
INSERT INTO `trn_dtl_views` VALUES ('419','10','SIN','2026-01-11','90','','6300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('420','10','SIN','2026-01-11','72','','66765.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('421','10','SIN','2026-01-11','79','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('424','10','SIN','2026-01-11','87','','157685.10','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('425','1','OB','2026-01-01','89','','59575','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('426','1','OB','2026-01-01','9','','0','59575','1','account');
INSERT INTO `trn_dtl_views` VALUES ('427','10','SIN','2026-01-11','89','','16830.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('428','44','SIN','2026-01-11','85','','78210.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('429','10','SIN','2026-01-11','69','','43530.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('430','12','CRV','2026-01-11','99','','0','20000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('431','1','OB','2026-01-01','99','','53566','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('432','1','OB','2026-01-01','9','','0','53566','1','account');
INSERT INTO `trn_dtl_views` VALUES ('433','10','SIN','2026-01-11','99','','37665.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('435','10','SIN','2026-01-11','104','','40305.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('436','1','OB','2026-01-01','92','','58020','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('437','1','OB','2026-01-01','9','','0','58020','1','account');
INSERT INTO `trn_dtl_views` VALUES ('438','10','SIN','2026-01-11','92','','7500.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('439','10','SIN','2026-01-11','160','','24300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('442','10','SIN','2026-01-11','81','','157068.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('443','10','SIN','2026-01-11','105','','70842.60','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('446','10','SIN','2026-01-11','100','','17280.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('449','13','CRV','2026-01-11','29','','0','272000.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('451','59','SIN','2026-01-11','29','','44436.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('452','10','SIN','2026-01-12','70','','6415.20','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('454','61','SIN','2026-01-12','74','','99360.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('455','10','SIN','2026-01-12','67','','27382.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('456','10','SIN','2026-01-12','64','','78300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('457','10','SIN','2026-01-12','159','','87000.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('458','14','CRV','2026-01-01','83','2% Breakage 2025','0','54095.00','1','account');
INSERT INTO `trn_dtl_views` VALUES ('459','1','OB','2026-01-01','91','','204100','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('460','1','OB','2026-01-01','9','','0','204100','1','account');
INSERT INTO `trn_dtl_views` VALUES ('461','10','SIN','2026-01-11','91','','105300.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('462','40','SIN','2026-01-11','82','','308208.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('463','49','SIN','2026-01-06','98','','141298.50','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('464','56','SIN','2026-01-11','68','','50516.55','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('465','58','SIN','2026-01-11','80','','54712.80','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('466','10','SIN','2026-01-12','163','','16470.00','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('467','10','SIN','2026-01-12','152','','31730.40','0','1','account');
INSERT INTO `trn_dtl_views` VALUES ('152','1','SIN','2025-10-28','','','0','261000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('156','2','SIN','2025-11-05','','','0','202000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('160','1','BRV','2025-11-06','2','','63000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('188','1','SIN','2025-11-10','','','0','1351.35','8','cash');
INSERT INTO `trn_dtl_views` VALUES ('190','1','PRN','2025-11-10','9','','0','83.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('197','3','SIN','2025-12-19','156','','0','20000.00','7','cash');
INSERT INTO `trn_dtl_views` VALUES ('202','1','OB','2026-01-01','','','0','20917.8','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('203','1','OB','2026-01-01','','','20917.8','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('204','1','OB','2026-01-01','','','0','499253','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('205','1','OB','2026-01-01','','','499253','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('206','1','OB','2026-01-01','','','0','31471','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('207','1','OB','2026-01-01','','','31471','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('208','1','OB','2026-01-01','','','0','164862','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('209','1','OB','2026-01-01','','','164862','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('210','1','OB','2026-01-01','','','0','184701','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('211','1','OB','2026-01-01','','','184701','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('212','1','OB','2026-01-01','','','0','160979','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('213','1','OB','2026-01-01','','','160979','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('214','1','OB','2026-01-01','','','0','779710','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('215','1','OB','2026-01-01','','','779710','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('216','1','OB','2026-01-01','','','0','1453069','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('217','1','OB','2026-01-01','','','1453069','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('218','1','OB','2026-01-01','','','0','1250635','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('219','1','OB','2026-01-01','','','1250635','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('220','1','OB','2026-01-01','','','0','161041','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('221','1','OB','2026-01-01','','','161041','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('222','1','OB','2026-01-01','','','0','46399','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('223','1','OB','2026-01-01','','','46399','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('224','1','OB','2026-01-01','','','0','117515','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('225','1','OB','2026-01-01','','','117515','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('226','1','OB','2026-01-01','','','0','22106','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('227','1','OB','2026-01-01','','','22106','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('228','1','SIN','2026-01-03','2','','0','19130.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('229','1','OB','2026-01-01','','','0','114304','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('230','1','OB','2026-01-01','','','114304','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('231','2','SIN','2026-01-04','2','','0','74760.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('232','1','OB','2026-01-01','','','0','459343','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('233','1','OB','2026-01-01','','','459343','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('234','3','SIN','2026-01-04','2','','0','7830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('235','1','OB','2026-01-01','','','0','605118','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('236','1','OB','2026-01-01','','','605118','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('237','4','SIN','2026-01-04','2','','0','45900.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('238','1','OB','2026-01-01','','','0','197168','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('239','1','OB','2026-01-01','','','197168','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('240','5','SIN','2026-01-04','2','','0','18630.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('241','1','OB','2026-01-01','','','0','85143','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('242','1','OB','2026-01-01','','','85143','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('243','6','SIN','2026-01-04','2','','0','48600.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('247','1','OB','2026-01-01','','','0','110752','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('248','1','OB','2026-01-01','','','110752','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('249','8','SIN','2026-01-04','2','','0','64830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('250','1','OB','2026-01-01','','','0','332903','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('251','1','OB','2026-01-01','','','332903','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('252','9','SIN','2026-01-04','2','','0','12915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('253','1','OB','2026-01-01','','','0','206022','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('254','1','OB','2026-01-01','','','206022','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('256','1','CRV','2026-01-03','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('257','10','SIN','2026-01-04','2','','0','83785.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('258','1','OB','2026-01-01','','','0','1072290','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('259','1','OB','2026-01-01','','','1072290','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('260','10','SIN','2026-01-04','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('261','1','OB','2026-01-01','','','0','88668','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('262','1','OB','2026-01-01','','','88668','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('263','1','OB','2026-01-01','','','0','347332','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('264','1','OB','2026-01-01','','','347332','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('265','10','SIN','2026-01-04','2','','0','15915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('266','10','SIN','2026-01-04','2','','0','6300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('267','1','OB','2026-01-01','','','0','689487','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('268','1','OB','2026-01-01','','','689487','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('269','10','SIN','2026-01-04','2','','0','69380.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('270','1','OB','2026-01-01','','','0','149620','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('271','1','OB','2026-01-01','','','149620','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('272','1','OB','2026-01-01','','','0','39600','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('273','1','OB','2026-01-01','','','39600','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('274','10','SIN','2026-01-06','2','','0','16848.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('275','1','OB','2026-01-01','','','0','5612','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('276','1','OB','2026-01-01','','','5612','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('277','10','SIN','2026-01-06','2','','0','32037.77','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('280','1','OB','2026-01-01','','','0','189033','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('281','1','OB','2026-01-01','','','189033','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('282','1','OB','2026-01-01','','','0','65561','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('283','1','OB','2026-01-01','','','65561','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('284','1','OB','2026-01-01','','','0','143670','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('285','1','OB','2026-01-01','','','143670','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('286','1','OB','2026-01-01','','','0','307647','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('287','1','OB','2026-01-01','','','307647','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('288','1','OB','2026-01-01','','','0','22755','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('289','1','OB','2026-01-01','','','22755','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('290','1','OB','2026-01-01','','','0','84977','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('291','1','OB','2026-01-01','','','84977','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('292','1','OB','2026-01-01','','','0','325980','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('293','1','OB','2026-01-01','','','325980','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('294','1','OB','2026-01-01','','','0','25696','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('295','1','OB','2026-01-01','','','25696','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('296','1','OB','2026-01-01','','','0','208699','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('297','1','OB','2026-01-01','','','208699','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('298','1','OB','2026-01-01','','','0','60839','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('299','1','OB','2026-01-01','','','60839','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('300','1','OB','2026-01-01','','','0','102801','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('301','1','OB','2026-01-01','','','102801','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('302','1','OB','2026-01-01','','','0','71213','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('303','1','OB','2026-01-01','','','71213','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('304','1','OB','2026-01-01','','','0','161050','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('305','1','OB','2026-01-01','','','161050','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('307','2','CRV','2026-01-01','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('308','3','CRV','2026-01-01','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('309','3','CRV','2026-01-01','157','','23000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('310','3','CRV','2026-01-01','157','Meezan Bank','23000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('311','3','CRV','2026-01-01','157','','7000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('312','3','CRV','2026-01-01','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('313','3','CRV','2026-01-01','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('314','3','CRV','2026-01-01','157','','21000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('315','3','CRV','2026-01-01','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('316','3','CRV','2026-01-01','157','Meezan','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('317','3','CRV','2026-01-01','157','HBL','35000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('318','3','CRV','2026-01-01','157','Meezan','22700.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('319','3','CRV','2026-01-01','157','Meezan Bank','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('321','17','SIN','2026-01-07','2','','0','19364.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('322','10','SIN','2026-01-07','2','','0','16511.04','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('323','10','SIN','2026-01-01','2','','0','9261.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('325','10','SIN','2026-01-07','2','','0','21242.09','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('326','10','SIN','2026-01-07','2','','0','10372.32','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('327','10','SIN','2026-01-07','2','','0','9720.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('328','10','SIN','2026-01-07','2','','0','48423.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('329','10','SIN','2026-01-01','2','','0','8568.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('331','26','SIN','2026-01-07','2','','0','70436.52','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('332','10','SIN','2026-01-07','2','','0','11907.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('333','20','SIN','2026-01-07','2','','0','48866.33','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('334','4','CRV','2026-01-06','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('335','10','SIN','2026-01-07','2','','0','90681.95','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('336','1','OB','2026-01-01','','','0','139963','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('337','1','OB','2026-01-01','','','139963','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('338','10','SIN','2026-01-06','2','','0','30870.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('339','10','SIN','2026-01-07','2','','0','111375.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('340','1','OB','2026-01-01','','','0','240680','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('341','1','OB','2026-01-01','','','240680','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('342','1','OB','2026-01-01','','','0','8348','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('343','1','OB','2026-01-01','','','8348','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('344','1','OB','2026-01-01','','','0','172654','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('345','1','OB','2026-01-01','','','172654','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('346','1','OB','2026-01-01','','','0','82662','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('347','1','OB','2026-01-01','','','82662','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('348','1','OB','2026-01-01','','','0','126441','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('349','1','OB','2026-01-01','','','126441','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('350','1','OB','2026-01-01','','','0','126307','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('351','1','OB','2026-01-01','','','126307','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('352','1','OB','2026-01-01','','','0','85590','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('353','1','OB','2026-01-01','','','85590','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('354','1','OB','2026-01-01','','','0','979451','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('355','1','OB','2026-01-01','','','979451','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('356','1','OB','2026-01-01','','','0','71461','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('357','1','OB','2026-01-01','','','71461','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('358','1','OB','2026-01-01','','','0','517418','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('359','1','OB','2026-01-01','','','517418','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('360','1','OB','2026-01-01','','','0','172039','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('361','1','OB','2026-01-01','','','172039','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('362','1','OB','2026-01-01','','','0','201957','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('363','1','OB','2026-01-01','','','201957','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('364','1','OB','2026-01-01','','','0','627697','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('365','1','OB','2026-01-01','','','627697','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('366','1','OB','2026-01-01','','','0','838626','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('367','1','OB','2026-01-01','','','838626','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('368','10','SIN','2026-01-08','2','','0','28548.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('369','10','SIN','2026-01-10','2','','0','89737.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('373','5','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('374','5','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('375','5','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('376','5','CRV','2026-01-05','157','','40000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('377','5','CRV','2026-01-05','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('378','5','CRV','2026-01-05','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('380','5','CRV','2026-01-05','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('381','5','CRV','2026-01-05','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('382','10','SIN','2026-01-03','2','','0','15915.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('383','1','OB','2026-01-01','','','0','40723','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('384','1','OB','2026-01-01','','','40723','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('385','6','CRV','2026-01-01','157','','15000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('386','7','CRV','2026-01-11','157','','89500.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('387','8','CRV','2026-01-05','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('388','8','CRV','2026-01-05','157','','13000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('389','8','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('390','8','CRV','2026-01-05','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('391','8','CRV','2026-01-05','157','','60000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('392','8','CRV','2026-01-05','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('393','8','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('394','8','CRV','2026-01-05','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('395','8','CRV','2026-01-05','157','','25000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('396','9','CRV','2026-01-07','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('397','9','CRV','2026-01-07','157','','100000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('398','1','OB','2026-01-01','','','0','96303','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('399','1','OB','2026-01-01','','','96303','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('400','10','CRV','2026-01-11','157','','50000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('401','10','CRV','2026-01-11','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('402','11','CRV','2026-01-04','157','','150000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('403','10','CRV','2026-01-11','157','','150000','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('404','11','CRV','2026-01-08','157','','30000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('405','11','CRV','2026-01-08','157','','59000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('408','1','OB','2026-01-01','','','0','167363','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('409','1','OB','2026-01-01','','','167363','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('410','35','SIN','2026-01-11','2','','0','92475.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('411','10','SIN','2026-01-11','2','','0','21420.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('412','10','SIN','2026-01-11','2','','0','40500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('413','10','SIN','2026-01-11','2','','0','58292.40','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('415','39','SIN','2026-01-11','2','','0','165618.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('417','1','OB','2026-01-01','','','0','90181','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('418','1','OB','2026-01-01','','','90181','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('419','10','SIN','2026-01-11','2','','0','6300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('420','10','SIN','2026-01-11','2','','0','66765.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('421','10','SIN','2026-01-11','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('424','10','SIN','2026-01-11','2','','0','157685.10','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('425','1','OB','2026-01-01','','','0','59575','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('426','1','OB','2026-01-01','','','59575','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('427','10','SIN','2026-01-11','2','','0','16830.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('428','44','SIN','2026-01-11','2','','0','78210.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('429','10','SIN','2026-01-11','2','','0','43530.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('430','12','CRV','2026-01-11','157','','20000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('431','1','OB','2026-01-01','','','0','53566','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('432','1','OB','2026-01-01','','','53566','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('433','10','SIN','2026-01-11','2','','0','37665.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('435','10','SIN','2026-01-11','2','','0','40305.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('436','1','OB','2026-01-01','','','0','58020','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('437','1','OB','2026-01-01','','','58020','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('438','10','SIN','2026-01-11','2','','0','7500.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('439','10','SIN','2026-01-11','2','','0','24300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('442','10','SIN','2026-01-11','2','','0','157068.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('443','10','SIN','2026-01-11','2','','0','70842.60','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('446','10','SIN','2026-01-11','2','','0','17280.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('449','13','CRV','2026-01-11','157','','272000.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('451','59','SIN','2026-01-11','2','','0','44436.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('452','10','SIN','2026-01-12','2','','0','6415.20','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('454','61','SIN','2026-01-12','2','','0','99360.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('455','10','SIN','2026-01-12','2','','0','27382.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('456','10','SIN','2026-01-12','2','','0','78300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('457','10','SIN','2026-01-12','2','','0','87000.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('458','14','CRV','2026-01-01','157','2% Breakage 2025','54095.00','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('459','1','OB','2026-01-01','','','0','204100','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('460','1','OB','2026-01-01','','','204100','0','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('461','10','SIN','2026-01-11','2','','0','105300.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('462','40','SIN','2026-01-11','2','','0','308208.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('463','49','SIN','2026-01-06','2','','0','141298.50','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('464','56','SIN','2026-01-11','2','','0','50516.55','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('465','58','SIN','2026-01-11','2','','0','54712.80','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('466','10','SIN','2026-01-12','2','','0','16470.00','1','cash');
INSERT INTO `trn_dtl_views` VALUES ('467','10','SIN','2026-01-12','2','','0','31730.40','1','cash');


DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `units` VALUES ('6','Carton','1','2025-10-25 18:57:46','2025-10-25 18:57:46');
INSERT INTO `units` VALUES ('8','KG','7','2025-10-27 19:18:50','2025-10-27 19:18:50');
INSERT INTO `units` VALUES ('9','mm','8','2025-11-10 21:38:21','2025-11-10 21:38:21');
INSERT INTO `units` VALUES ('11','Bundle','1','2025-12-11 18:27:16','2025-12-11 18:27:16');
INSERT INTO `units` VALUES ('12','Bora','1','2025-12-11 18:27:52','2025-12-11 18:27:52');
INSERT INTO `units` VALUES ('13','PCS','7','2025-12-19 16:23:06','2025-12-19 16:23:06');


DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE `user_permission` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint unsigned NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `cid` bigint unsigned NOT NULL,
  `read` int NOT NULL,
  `write` int NOT NULL,
  `update` int NOT NULL,
  `delete` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_permission` VALUES ('1','134','1','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('2','134','2','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('3','134','3','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('4','134','4','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('5','134','5','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('6','134','6','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('7','134','7','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('8','134','8','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('9','134','9','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('10','134','10','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('11','134','11','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('12','134','12','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('13','134','13','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('14','134','14','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('15','134','15','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('16','134','16','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('17','134','17','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('18','134','18','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('19','134','19','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('20','134','20','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('21','134','21','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('22','134','22','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('23','134','23','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('24','134','24','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('25','134','25','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('26','134','26','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('27','134','27','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('28','134','28','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('29','134','29','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('30','134','30','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('31','134','31','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('32','134','32','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('33','134','33','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('34','134','34','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('35','134','35','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('36','134','36','1','1','1','1','1','2025-10-06 03:20:34','2025-10-06 03:20:34');
INSERT INTO `user_permission` VALUES ('37','135','1','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('38','135','2','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('39','135','3','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('40','135','4','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('41','135','5','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('42','135','6','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('43','135','7','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('44','135','8','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('45','135','9','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('46','135','10','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('47','135','11','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('48','135','12','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('49','135','13','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('50','135','14','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('51','135','15','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('52','135','16','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('53','135','17','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('54','135','18','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('55','135','19','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('56','135','20','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('57','135','21','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('58','135','22','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('59','135','23','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('60','135','24','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('61','135','25','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('62','135','26','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('63','135','27','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('64','135','28','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('65','135','29','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('66','135','30','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('67','135','31','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('68','135','32','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('69','135','33','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('70','135','34','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('71','135','35','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('72','135','36','8','1','1','1','1','2025-10-06 13:25:33','2025-10-06 13:25:33');
INSERT INTO `user_permission` VALUES ('145','137','1','9','1','0','0','0','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('146','137','2','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('147','137','3','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('148','137','4','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('149','137','5','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('150','137','6','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('151','137','7','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('152','137','8','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('153','137','9','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('154','137','10','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('155','137','11','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('156','137','12','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('157','137','13','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('158','137','14','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('159','137','15','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('160','137','16','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('161','137','17','9','1','1','1','1','2025-10-07 17:37:44','2025-10-07 17:37:44');
INSERT INTO `user_permission` VALUES ('162','137','18','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('163','137','19','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('164','137','20','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('165','137','21','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('166','137','22','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('167','137','23','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('168','137','24','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('169','137','25','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('170','137','26','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('171','137','27','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('172','137','28','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('173','137','29','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('174','137','30','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('175','137','31','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('176','137','32','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('177','137','33','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('178','137','34','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('179','137','35','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('180','137','36','9','1','1','1','1','2025-10-07 17:37:45','2025-10-07 17:37:45');
INSERT INTO `user_permission` VALUES ('334','143','32','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('335','143','34','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('336','143','35','10','1','1','0','0','2025-10-09 23:19:47','2025-10-09 23:19:47');
INSERT INTO `user_permission` VALUES ('367','139','1','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('368','139','2','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('369','139','3','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('370','139','4','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('371','139','5','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('372','139','6','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('373','139','7','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('374','139','8','1','1','1','1','1','2025-10-10 00:08:26','2025-10-10 00:08:26');
INSERT INTO `user_permission` VALUES ('375','139','9','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('376','139','10','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('377','139','11','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('378','139','12','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('379','139','13','1','1','1','1','1','2025-10-10 00:08:27','2025-10-10 00:08:27');
INSERT INTO `user_permission` VALUES ('380','139','14','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('381','139','15','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('382','139','16','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('383','139','17','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('384','139','18','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('385','139','19','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('386','139','20','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('387','139','21','1','1','1','1','1','2025-10-10 00:08:28','2025-10-10 00:08:28');
INSERT INTO `user_permission` VALUES ('388','139','22','1','1','1','1','1','2025-10-10 00:08:31','2025-10-10 00:08:31');
INSERT INTO `user_permission` VALUES ('389','139','23','1','1','1','1','1','2025-10-10 00:08:32','2025-10-10 00:08:32');
INSERT INTO `user_permission` VALUES ('390','139','24','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('391','139','25','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('392','139','26','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('393','139','27','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('394','139','28','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('395','139','29','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('396','139','30','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('397','139','31','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('398','139','32','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('399','139','33','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('400','139','34','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('401','139','35','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('402','139','36','1','1','1','1','1','2025-10-10 00:08:34','2025-10-10 00:08:34');
INSERT INTO `user_permission` VALUES ('403','145','1','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('404','145','2','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('405','145','3','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('406','145','4','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('407','145','5','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('408','145','6','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('409','145','7','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('410','145','8','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('411','145','9','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('412','145','10','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('413','145','11','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('414','145','12','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('415','145','13','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('416','145','14','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('417','145','15','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('418','145','16','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('419','145','17','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('420','145','18','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('421','145','19','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('422','145','20','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('423','145','21','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('424','145','22','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('425','145','23','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('426','145','24','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('427','145','25','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('428','145','26','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('429','145','27','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('430','145','28','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('431','145','29','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('432','145','30','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('433','145','31','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('434','145','32','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('435','145','33','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('436','145','34','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('437','145','36','11','1','1','1','1','2025-10-11 14:30:34','2025-10-11 14:30:34');
INSERT INTO `user_permission` VALUES ('488','141','1','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('489','141','2','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('490','141','3','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('491','141','4','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('492','141','5','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('493','141','6','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('494','141','7','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('495','141','8','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('496','141','9','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('497','141','10','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('498','141','11','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('499','141','12','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('500','141','13','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('501','141','14','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('502','141','15','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('503','141','16','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('504','141','17','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('505','141','18','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('506','141','19','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('507','141','20','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('508','141','21','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('509','141','22','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('510','141','23','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('511','141','24','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('512','141','25','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('513','141','26','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('514','141','27','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('515','141','28','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('516','141','29','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('517','141','30','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('518','141','31','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('519','141','32','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('520','141','33','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('521','141','34','10','1','1','0','0','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('522','141','36','10','1','1','1','1','2025-10-13 13:58:27','2025-10-13 13:58:27');
INSERT INTO `user_permission` VALUES ('523','146','1','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('524','146','2','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('525','146','3','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('526','146','4','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('527','146','5','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('528','146','6','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('529','146','7','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('530','146','8','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('531','146','9','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('532','146','10','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('533','146','11','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('534','146','12','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('535','146','13','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('536','146','14','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('537','146','15','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('538','146','16','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('539','146','17','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('540','146','18','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('541','146','19','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('542','146','20','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('543','146','21','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('544','146','22','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('545','146','23','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('546','146','24','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('547','146','25','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('548','146','26','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('549','146','27','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('550','146','28','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('551','146','29','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('552','146','30','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('553','146','31','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('554','146','32','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('555','146','33','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('556','146','34','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('557','146','36','12','1','1','1','1','2025-10-15 22:20:06','2025-10-15 22:20:06');
INSERT INTO `user_permission` VALUES ('558','142','1','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('559','142','2','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('560','142','3','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('561','142','4','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('562','142','5','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('563','142','6','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('564','142','7','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('565','142','8','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('566','142','9','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('567','142','10','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('568','142','11','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('569','142','12','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('570','142','13','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('571','142','14','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('572','142','15','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('573','142','16','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('574','142','17','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('575','142','18','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('576','142','19','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('577','142','20','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('578','142','21','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('579','142','22','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('580','142','23','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('581','142','24','10','1','1','0','0','2025-11-04 00:16:25','2025-11-04 00:16:25');
INSERT INTO `user_permission` VALUES ('582','142','25','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('583','142','26','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('584','142','27','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('585','142','28','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('586','142','29','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('587','142','30','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('588','142','31','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('589','142','32','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('590','142','33','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('591','142','34','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('592','142','36','10','1','1','0','0','2025-11-04 00:16:26','2025-11-04 00:16:26');
INSERT INTO `user_permission` VALUES ('594','1','1','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('595','1','2','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('596','1','3','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('597','1','4','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('598','1','5','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('599','1','6','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('600','1','7','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('601','1','8','1','1','1','1','1','2025-11-06 02:00:05','2025-11-16 01:40:15');
INSERT INTO `user_permission` VALUES ('602','1','9','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('603','1','10','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('604','1','11','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('605','1','12','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('606','1','13','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('607','1','14','1','1','1','0','0','2025-11-06 02:00:05','2025-11-06 02:00:05');
INSERT INTO `user_permission` VALUES ('608','1','15','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('609','1','16','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('610','1','17','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('611','1','18','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('612','1','19','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('613','1','20','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('614','1','21','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('615','1','22','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('616','1','24','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('617','1','25','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('618','1','26','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('619','1','36','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('620','1','37','1','1','1','0','0','2025-11-06 02:00:35','2025-11-06 02:00:35');
INSERT INTO `user_permission` VALUES ('621','135','1','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('622','135','2','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('623','135','3','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('624','135','4','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('625','135','5','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('626','135','6','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('627','135','7','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('628','135','8','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('629','135','9','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('630','135','10','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('631','135','11','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('632','135','12','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('633','135','13','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');
INSERT INTO `user_permission` VALUES ('634','135','14','7','1','0','0','0','2025-11-06 02:17:44','2025-11-06 02:17:44');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account` tinyint(1) DEFAULT NULL,
  `report` tinyint(1) DEFAULT NULL,
  `billing` tinyint(1) DEFAULT NULL,
  `delivery_challan` tinyint(1) DEFAULT NULL,
  `waste_sale` tinyint(1) DEFAULT NULL,
  `gate_pass` tinyint(1) DEFAULT NULL,
  `gate_ex` tinyint DEFAULT NULL,
  `purchase` tinyint(1) DEFAULT NULL,
  `inventory` tinyint(1) DEFAULT NULL,
  `product_registration` tinyint(1) DEFAULT NULL,
  `job_sheet` tinyint(1) DEFAULT NULL,
  `attendance_system` tinyint(1) DEFAULT NULL,
  `setup` tinyint(1) DEFAULT NULL,
  `setup_department` tinyint(1) DEFAULT NULL,
  `employee_department` tinyint(1) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `employee` tinyint(1) DEFAULT NULL,
  `wage_calculator` tinyint(1) DEFAULT NULL,
  `cid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1','1','Admin','superadmin@example.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','MEj9IGfgZcv3TujwqnzDuBtlMIhtP7AXNcMk2LgWDPD3kDYrX6MpaUaPfb0G','2024-11-11 02:00:37','2025-07-29 01:07:02','','0','1');
INSERT INTO `users` VALUES ('99','1','Demo account','demo@gmail.com','0','1','0','1','0','1','0','1','0','1','1','1','0','0','1','$2y$12$FVF5Odqw0BiIPEcm1awHo.2h.qgQib60BUHM0ytmI59FP1kD/Ouzq','','Nt2zwqK23VxGdKXuGvBdDMu6iM1lysVdpmtusAey2nxyB2vjZJ3yIkoCZSAx','2025-04-16 01:07:51','2025-08-02 20:10:32','0','0','2');
INSERT INTO `users` VALUES ('127','3','Super Admin','admin@gmail.com','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','FJx353IEpjCwOZhXXF0D98CnnzGQYIpJJx5kIit8u3JsNTyRYM30qjIKBVEu','2025-07-29 01:07:55','2025-08-02 12:43:06','0','0','6');
INSERT INTO `users` VALUES ('128','0','ADMIN','','','','','','','','','','','','','','','','','','','','','','','','6');
INSERT INTO `users` VALUES ('133','1','Admin PremierTax','testing@gmail.com','','','','','','','','','','','','','','','','$2y$12$J4hNtyuXj3ULv/5u3Kt5OekqdCaGwy3g5DVDs8oeia/zoBmsrJTLq','','UIR77Yuj4NQoq2nJzlPd6MqGc4Eilm6kHz55V42zrv3UJZrC822JDP6bNwZ1','2025-09-20 14:31:38','2025-09-20 14:31:38','','','7');
INSERT INTO `users` VALUES ('135','0','checker','checker@gmail.com','','','','','','','','','','','','','','','','$2y$12$mbsiJxMffgyecJbj2TyVv.IrA61beiGt9psdl0xKcRUVCdUDaw0Qi','','','2025-11-06 02:09:49','2025-11-06 02:09:49','','','7');
INSERT INTO `users` VALUES ('136','1','Demo Wali','demowali@softix.com','','','','','','','','','','','','','','','','$2y$12$yKx.otTBaI.BnE7Zb14BY.egFQXOGrIF5FcC5duha0qw9w5NIpZKS','','','2025-11-10 13:53:44','2025-11-10 13:53:44','','','8');
INSERT INTO `users` VALUES ('137','1','SHahaan','shahaanltd@gmail.com','','','','','','','','','','','','','','','','$2y$12$MSY/g6jjiuxzYazpisJ34e3wReNJgggT1OTiz86EF2egFjTLFyE0.','','','2025-12-03 18:06:08','2025-12-03 18:06:08','','','9');


DROP TABLE IF EXISTS `workspace`;
CREATE TABLE `workspace` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `logo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `workspace` VALUES ('1','MKPLASTIC','','2025-11-10 12:37:09','uploads/1762760229mk.png');
INSERT INTO `workspace` VALUES ('6','ADMIN','','','');
INSERT INTO `workspace` VALUES ('7','Premiertax','2025-09-20 14:29:16','2025-09-20 14:29:16','');
INSERT INTO `workspace` VALUES ('8','DEMO WALI','2025-11-10 13:53:22','2025-11-10 13:53:22','');
INSERT INTO `workspace` VALUES ('9','Shahaan Ltd','2025-12-03 17:49:18','2025-12-03 17:49:18','');


